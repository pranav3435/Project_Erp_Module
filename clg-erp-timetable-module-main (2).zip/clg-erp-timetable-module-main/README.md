# 🎓 College ERP System — Timetable & Academic Planning Module

> Built with **FastAPI + PostgreSQL + SQLAlchemy + Alembic**

---

## 📋 Table of Contents
- [About the Project](#about-the-project)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Database Tables](#database-tables)
- [Setup Instructions](#setup-instructions)
- [Running the Project](#running-the-project)
- [API Documentation](#api-documentation)
- [Seed Data](#seed-data)
- [Sharing API with Other Teams](#sharing-api-with-other-teams)

---

## 📌 About the Project

This module is part of a **College ERP System** and handles:
- Academic Planning (Departments, Programs, Classes, Faculty, Courses)
- Timetable Management (Scheduling lectures, practicals, labs)
- Fees Management (Class-wise fees and installments)
- Academic Calendar (Holidays, Exams, Events)

---

## 🛠️ Tech Stack

| Technology | Purpose |
|---|---|
| **Python 3.x** | Backend language |
| **FastAPI** | REST API framework |
| **PostgreSQL** | Database |
| **SQLAlchemy** | ORM (Object Relational Mapper) |
| **Alembic** | Database migrations |
| **Uvicorn** | ASGI server |
| **Pydantic** | Data validation |

---

## 📁 Project Structure

```
CLG ERP SYSTEM/
├── alembic/                    ← Database migration files
│   ├── versions/               ← Auto-generated migration files
│   └── env.py                  ← Alembic configuration
├── routers/                    ← All API route files
│   ├── __init__.py
│   ├── academic_calendar.py
│   ├── academic_year.py
│   ├── batch.py
│   ├── class_.py
│   ├── classroom.py
│   ├── classroom_occupancy.py
│   ├── course.py
│   ├── department.py
│   ├── division.py
│   ├── faculty.py
│   ├── faculty_timetable.py
│   ├── fees.py
│   ├── lab.py
│   ├── logs.py
│   ├── program.py
│   ├── section.py
│   ├── semester.py
│   ├── student_batch.py
│   ├── timetable.py
│   └── auth.py (coming soon - from Auth module team)
├── venv/                       ← Virtual environment (do not push to GitHub)
├── alembic.ini                 ← Alembic settings
├── database.py                 ← Database connection
├── main.py                     ← FastAPI app entry point
├── models.py                   ← SQLAlchemy models (all tables)
├── schemas.py                  ← Pydantic schemas
├── seed.py                     ← Initial data insertion
├── seed_courses.py             ← Courses/subjects data insertion
└── requirements.txt            ← Python dependencies
```

---

## 🗄️ Database Tables

| # | Table | Purpose |
|---|---|---|
| 1 | `academic_year` | Academic years (2024-25, 2025-26) |
| 2 | `department` | Departments (CS, Commerce, Animation) |
| 3 | `section` | UG / PG |
| 4 | `program` | B.Sc CS, B.Com, BBA, M.Sc etc. |
| 5 | `class` | FY, SY, TY for each program |
| 6 | `division` | Divisions A, B, C per class |
| 7 | `batch` | Batches for lab sessions |
| 8 | `faculty` | Faculty members |
| 9 | `course` | Subjects/courses per program |
| 10 | `semester` | Semesters I to VIII |
| 11 | `classroom` | Physical classrooms |
| 12 | `lab` | Laboratory rooms |
| 13 | `timetable` | Main timetable entries |
| 14 | `faculty_timetable` | Faculty-wise timetable view |
| 15 | `classroom_occupancy` | Room booking tracker |
| 16 | `academic_calendar` | Holidays, exams, events |
| 17 | `student_batch` | Student to batch mapping |
| 18 | `program_fees` | Class-wise fees |
| 19 | `fee_installment` | Installment plans |
| 20 | `logs` | User activity logs |
| 21 | `alembic_version` | Migration tracking |

---

## ⚙️ Setup Instructions

### Prerequisites
- Python 3.10+
- PostgreSQL installed and running
- Git

---

### Step 1 — Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/college-erp-timetable-module.git
cd college-erp-timetable-module
```

---

### Step 2 — Create Virtual Environment

```bash
python -m venv venv
```

**Activate virtual environment:**

Windows:
```bash
venv\Scripts\activate
```

Mac/Linux:
```bash
source venv/bin/activate
```

---

### Step 3 — Install Dependencies

```bash
pip install -r requirements.txt
```

---

### Step 4 — Create PostgreSQL Database

Open pgAdmin or psql and run:
```sql
CREATE DATABASE erp_system;
```

---

### Step 5 — Configure Database URL

Open `database.py` and update this line with your PostgreSQL credentials:
```python
DATABASE_URL = "postgresql://postgres:YOUR_PASSWORD@localhost:5432/erp_system"
```

Also update `alembic/env.py`:
```python
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:YOUR_PASSWORD@localhost:5432/erp_system")
```

---

### Step 6 — Run Database Migrations

```bash
alembic upgrade head
```

This will create all 21 tables in your database automatically! ✅

---

### Step 7 — Insert Seed Data

```bash
python seed.py
```

Then insert courses:
```bash
python seed_courses.py
```

---

## 🚀 Running the Project

```bash
uvicorn main:app --reload
```

Server will start at:
```
http://127.0.0.1:8000
```

---

## 📖 API Documentation

Once server is running, open in browser:

```
http://127.0.0.1:8000/docs
```

This opens **Swagger UI** — you can test all APIs directly from the browser!

---

## 🔗 Available API Endpoints

| Module | Base URL | Methods |
|---|---|---|
| Departments | `/departments` | GET, POST, PUT, DELETE |
| Academic Years | `/academic-years` | GET, POST, PUT, DELETE |
| Sections | `/sections` | GET, POST, PUT, DELETE |
| Programs | `/programs` | GET, POST, PUT, DELETE |
| Classes | `/classes` | GET, POST, PUT, DELETE |
| Divisions | `/divisions` | GET, POST, PUT, DELETE |
| Batches | `/batches` | GET, POST, PUT, DELETE |
| Faculty | `/faculty` | GET, POST, PUT, DELETE |
| Courses | `/courses` | GET, POST, PUT, DELETE |
| Semesters | `/semesters` | GET, POST, PUT, DELETE |
| Classrooms | `/classrooms` | GET, POST, PUT, DELETE |
| Labs | `/labs` | GET, POST, PUT, DELETE |
| Timetable | `/timetables` | GET, POST, PUT, DELETE |
| Academic Calendar | `/academic-calendar` | GET, POST, PUT, DELETE |
| Fees | `/fees` | GET, POST, PUT, DELETE |
| Fee Installments | `/fees/installments` | GET, POST, PUT, DELETE |
| Student Batch | `/student-batches` | GET, POST, DELETE |
| Logs | `/logs` | GET, POST, DELETE |

---

## 🌱 Seed Data

After running `seed.py` the following data will be inserted:

| Data | Count |
|---|---|
| Academic Years | 2 |
| Sections (UG/PG) | 2 |
| Departments | 3 (Computer Science, Commerce, Animation) |
| Faculty | 22 |
| Programs | 10 |
| Classes | 26 |
| Divisions | 47 |
| Classrooms | 22 |
| Labs | 8 |
| Semesters | 52 |
| Calendar Events | 10 |
| Program Fees (class-wise) | 26 |
| Installments | 70 |

After running `seed_courses.py`:

| Data | Count |
|---|---|
| Courses (SPPU NEP 2024 syllabus) | 300+ |

---

## 🌍 Sharing API with Other Teams (Ngrok)

To share your API with other module teams over the internet:

**Step 1 — Install Ngrok**
Download from: `https://ngrok.com/download`

**Step 2 — Setup authtoken**
```bash
ngrok config add-authtoken YOUR_TOKEN
```

**Step 3 — Start your server**
```bash
uvicorn main:app --reload
```

**Step 4 — In a new terminal, run ngrok**
```bash
ngrok http 8000
```

**Step 5 — Share the public URL with teammates**
```
https://abc123.ngrok-free.app/docs
```

> ⚠️ Note: Ngrok URL changes every time you restart. Your laptop must be ON and server must be running for teammates to access.

---

## 📦 Requirements

Generate requirements.txt:
```bash
pip freeze > requirements.txt
```

Key dependencies:
```
fastapi
uvicorn[standard]
sqlalchemy
alembic
psycopg2-binary
pydantic
python-dotenv
passlib[bcrypt]
python-jose[cryptography]
python-multipart
```

---

## 👩‍💻 Developer

**Module:** Timetable & Academic Planning
**University:** Savitribai Phule Pune University (SPPU)
**Syllabus:** NEP 2024

---

## 📝 Notes for Team Members

1. **Never push `venv/` folder** to GitHub
2. **Never push your password** — always update `database.py` locally
3. Always **activate venv** before running the project
4. Run `alembic upgrade head` after pulling new changes
5. Authentication is handled by the **Auth Module team** — integrate their token verification
6. Student data comes from the **Student Module team** — use `student_id` from their API

---

*Last Updated: April 2026*
