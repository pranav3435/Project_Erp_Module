"""build_all_tables

Revision ID: d03042f98706
Revises: 
Create Date: 2026-04-03 23:02:24.848189

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'd03042f98706'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. academic_year
    op.create_table('academic_year',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('academic_year', sa.String(length=20), nullable=False),
        sa.Column('start_date', sa.Date(), nullable=True),
        sa.Column('end_date', sa.Date(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('academic_year')
    )
    op.create_index(op.f('ix_academic_year_id'), 'academic_year', ['id'], unique=False)

    # 2. classroom
    op.create_table('classroom',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('room_number', sa.String(length=20), nullable=False),
        sa.Column('building', sa.String(length=50), nullable=True),
        sa.Column('capacity', sa.Integer(), nullable=True),
        sa.Column('room_type', sa.String(length=30), nullable=True),
        sa.Column('availability_status', sa.String(length=20), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('room_number')
    )
    op.create_index(op.f('ix_classroom_id'), 'classroom', ['id'], unique=False)

    # 3. section
    op.create_table('section',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('section_name', sa.String(length=50), nullable=False),
        sa.Column('abbreviation', sa.String(length=10), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_section_id'), 'section', ['id'], unique=False)

    # 4. logs
    op.create_table('logs',
        sa.Column('log_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('access_date_time', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('log_id')
    )
    op.create_index(op.f('ix_logs_log_id'), 'logs', ['log_id'], unique=False)
    op.create_index(op.f('ix_logs_user_id'), 'logs', ['user_id'], unique=False)

    # 5. department WITHOUT hod_id FK first (circular dependency fix)
    op.create_table('department',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('department_name', sa.String(length=100), nullable=False),
        sa.Column('department_description', sa.Text(), nullable=True),
        sa.Column('hod_id', sa.Integer(), nullable=True),  # FK added after faculty
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('department_name')
    )
    op.create_index(op.f('ix_department_id'), 'department', ['id'], unique=False)

    # 6. faculty (needs department)
    op.create_table('faculty',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('faculty_name', sa.String(length=150), nullable=False),
        sa.Column('email', sa.String(length=150), nullable=False),
        sa.Column('designation', sa.String(length=100), nullable=True),
        sa.Column('qualification', sa.String(length=150), nullable=True),
        sa.Column('mobile_no', sa.String(length=15), nullable=True),
        sa.Column('faculty_photo', sa.String(length=255), nullable=True),
        sa.Column('faculty_type', sa.String(length=50), nullable=True),
        sa.Column('department_id', sa.Integer(), nullable=True),
        sa.Column('time_slot', sa.String(length=100), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('email')
    )
    op.create_index(op.f('ix_faculty_id'), 'faculty', ['id'], unique=False)

    # 7. NOW add hod_id FK to department (faculty table exists now)
    op.create_foreign_key(
        'fk_department_hod_id',
        'department', 'faculty',
        ['hod_id'], ['id'],
        ondelete='SET NULL'
    )

    # 8. program (needs department + section)
    op.create_table('program',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('program_name', sa.String(length=150), nullable=False),
        sa.Column('department_id', sa.Integer(), nullable=False),
        sa.Column('section_id', sa.Integer(), nullable=True),
        sa.Column('program_duration', sa.Integer(), nullable=False),
        sa.Column('program_level', sa.String(length=10), nullable=True),
        sa.Column('sanction_intake', sa.Integer(), nullable=True),
        sa.Column('sanction_div', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['section_id'], ['section.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_program_id'), 'program', ['id'], unique=False)

    # 9. class (needs program + department)
    op.create_table('class',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('class_name', sa.String(length=100), nullable=False),
        sa.Column('program_id', sa.Integer(), nullable=False),
        sa.Column('department_id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['program_id'], ['program.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_class_id'), 'class', ['id'], unique=False)

    # 10. course (needs program + section + department)
    op.create_table('course',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('course_name', sa.String(length=150), nullable=False),
        sa.Column('course_type', sa.String(length=50), nullable=True),
        sa.Column('course_credit', sa.Integer(), nullable=True),
        sa.Column('course_hours', sa.Integer(), nullable=True),
        sa.Column('program_id', sa.Integer(), nullable=False),
        sa.Column('section_id', sa.Integer(), nullable=True),
        sa.Column('department_id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['program_id'], ['program.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['section_id'], ['section.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_course_id'), 'course', ['id'], unique=False)

    # 11. semester (needs program + academic_year)
    op.create_table('semester',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('semester_number', sa.String(length=5), nullable=False),
        sa.Column('program_id', sa.Integer(), nullable=True),
        sa.Column('max_semesters', sa.Integer(), nullable=True),
        sa.Column('academic_year', sa.String(length=20), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['academic_year'], ['academic_year.academic_year'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['program_id'], ['program.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_semester_id'), 'semester', ['id'], unique=False)

    # 12. academic_calendar (needs academic_year + semester)
    op.create_table('academic_calendar',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('academic_year', sa.String(length=20), nullable=True),
        sa.Column('semester_id', sa.Integer(), nullable=True),
        sa.Column('start_date', sa.Date(), nullable=True),
        sa.Column('end_date', sa.Date(), nullable=True),
        sa.Column('day_type', sa.String(length=20), nullable=True),
        sa.Column('event_name', sa.String(length=200), nullable=True),
        sa.Column('event_type', sa.String(length=50), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['academic_year'], ['academic_year.academic_year'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['semester_id'], ['semester.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_academic_calendar_id'), 'academic_calendar', ['id'], unique=False)

    # 13. division (needs class + program + section + department)
    op.create_table('division',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('div_name', sa.String(length=10), nullable=False),
        sa.Column('class_id', sa.Integer(), nullable=False),
        sa.Column('program_id', sa.Integer(), nullable=False),
        sa.Column('section_id', sa.Integer(), nullable=True),
        sa.Column('department_id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['class_id'], ['class.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['program_id'], ['program.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['section_id'], ['section.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('div_name', 'class_id', name='uq_division_name_class')
    )
    op.create_index(op.f('ix_division_id'), 'division', ['id'], unique=False)

    # 14. batch (needs program + section + class + division + department)
    op.create_table('batch',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('batch_name', sa.String(length=50), nullable=False),
        sa.Column('program_id', sa.Integer(), nullable=False),
        sa.Column('section_id', sa.Integer(), nullable=True),
        sa.Column('class_id', sa.Integer(), nullable=False),
        sa.Column('div_id', sa.Integer(), nullable=False),
        sa.Column('department_id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['class_id'], ['class.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['div_id'], ['division.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['program_id'], ['program.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['section_id'], ['section.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_batch_id'), 'batch', ['id'], unique=False)

    # 15. classroom_occupancy (needs classroom + semester + division)
    op.create_table('classroom_occupancy',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('day', sa.String(length=20), nullable=False),
        sa.Column('start_time', sa.Time(), nullable=False),
        sa.Column('end_time', sa.Time(), nullable=False),
        sa.Column('classroom_id', sa.Integer(), nullable=False),
        sa.Column('semester_id', sa.Integer(), nullable=True),
        sa.Column('division_id', sa.Integer(), nullable=True),
        sa.Column('academic_year', sa.String(length=20), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['classroom_id'], ['classroom.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['division_id'], ['division.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['semester_id'], ['semester.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_classroom_occupancy_id'), 'classroom_occupancy', ['id'], unique=False)

    # 16. lab (needs class + batch + course + department)
    op.create_table('lab',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('lab_number', sa.String(length=20), nullable=False),
        sa.Column('lab_name', sa.String(length=150), nullable=True),
        sa.Column('building', sa.String(length=50), nullable=True),
        sa.Column('capacity', sa.Integer(), nullable=True),
        sa.Column('availability_status', sa.String(length=20), nullable=True),
        sa.Column('day_of_week', sa.String(length=15), nullable=True),
        sa.Column('time_slot', sa.String(length=30), nullable=True),
        sa.Column('class_id', sa.Integer(), nullable=True),
        sa.Column('batch_id', sa.Integer(), nullable=True),
        sa.Column('course_id', sa.Integer(), nullable=True),
        sa.Column('department_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['batch_id'], ['batch.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['class_id'], ['class.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['course_id'], ['course.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['department_id'], ['department.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_lab_id'), 'lab', ['id'], unique=False)

    # 17. student_batch (needs batch)
    op.create_table('student_batch',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('student_id', sa.Integer(), nullable=False),
        sa.Column('batch_id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['batch_id'], ['batch.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('student_id', 'batch_id', name='uq_student_batch')
    )
    op.create_index(op.f('ix_student_batch_id'), 'student_batch', ['id'], unique=False)
    op.create_index(op.f('ix_student_batch_student_id'), 'student_batch', ['student_id'], unique=False)

    # 18. timetable (needs course + faculty + classroom + lab + semester + division)
    op.create_table('timetable',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('day', sa.String(length=20), nullable=False),
        sa.Column('start_time', sa.Time(), nullable=False),
        sa.Column('end_time', sa.Time(), nullable=False),
        sa.Column('sub_id', sa.Integer(), nullable=True),
        sa.Column('faculty_id', sa.Integer(), nullable=True),
        sa.Column('classroom_id', sa.Integer(), nullable=True),
        sa.Column('lab_id', sa.Integer(), nullable=True),
        sa.Column('semester_id', sa.Integer(), nullable=True),
        sa.Column('division_id', sa.Integer(), nullable=True),
        sa.Column('academic_year', sa.String(length=20), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['classroom_id'], ['classroom.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['division_id'], ['division.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['faculty_id'], ['faculty.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['lab_id'], ['lab.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['semester_id'], ['semester.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['sub_id'], ['course.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('classroom_id', 'day', 'start_time', 'academic_year', name='uq_classroom_slot'),
        sa.UniqueConstraint('faculty_id', 'day', 'start_time', 'academic_year', name='uq_faculty_slot')
    )
    op.create_index(op.f('ix_timetable_id'), 'timetable', ['id'], unique=False)

    # 19. faculty_timetable (needs timetable + faculty + course)
    op.create_table('faculty_timetable',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('timetable_id', sa.Integer(), nullable=True),
        sa.Column('faculty_id', sa.Integer(), nullable=True),
        sa.Column('day_of_week', sa.String(length=15), nullable=True),
        sa.Column('time_slot', sa.String(length=30), nullable=True),
        sa.Column('class_name', sa.String(length=60), nullable=True),
        sa.Column('course_id', sa.Integer(), nullable=True),
        sa.Column('session_type', sa.String(length=20), nullable=True),
        sa.Column('workload', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['course_id'], ['course.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['faculty_id'], ['faculty.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['timetable_id'], ['timetable.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_faculty_timetable_id'), 'faculty_timetable', ['id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_faculty_timetable_id'), table_name='faculty_timetable')
    op.drop_table('faculty_timetable')
    op.drop_index(op.f('ix_timetable_id'), table_name='timetable')
    op.drop_table('timetable')
    op.drop_index(op.f('ix_student_batch_student_id'), table_name='student_batch')
    op.drop_index(op.f('ix_student_batch_id'), table_name='student_batch')
    op.drop_table('student_batch')
    op.drop_index(op.f('ix_lab_id'), table_name='lab')
    op.drop_table('lab')
    op.drop_index(op.f('ix_classroom_occupancy_id'), table_name='classroom_occupancy')
    op.drop_table('classroom_occupancy')
    op.drop_index(op.f('ix_batch_id'), table_name='batch')
    op.drop_table('batch')
    op.drop_index(op.f('ix_division_id'), table_name='division')
    op.drop_table('division')
    op.drop_index(op.f('ix_academic_calendar_id'), table_name='academic_calendar')
    op.drop_table('academic_calendar')
    op.drop_index(op.f('ix_semester_id'), table_name='semester')
    op.drop_table('semester')
    op.drop_index(op.f('ix_course_id'), table_name='course')
    op.drop_table('course')
    op.drop_index(op.f('ix_class_id'), table_name='class')
    op.drop_table('class')
    op.drop_index(op.f('ix_batch_id'), table_name='batch')
    op.drop_index(op.f('ix_program_id'), table_name='program')
    op.drop_table('program')
    op.drop_constraint('fk_department_hod_id', 'department', type_='foreignkey')
    op.drop_index(op.f('ix_faculty_id'), table_name='faculty')
    op.drop_table('faculty')
    op.drop_index(op.f('ix_department_id'), table_name='department')
    op.drop_table('department')
    op.drop_index(op.f('ix_section_id'), table_name='section')
    op.drop_table('section')
    op.drop_index(op.f('ix_logs_user_id'), table_name='logs')
    op.drop_index(op.f('ix_logs_log_id'), table_name='logs')
    op.drop_table('logs')
    op.drop_index(op.f('ix_classroom_id'), table_name='classroom')
    op.drop_table('classroom')
    op.drop_index(op.f('ix_academic_year_id'), table_name='academic_year')
    op.drop_table('academic_year')