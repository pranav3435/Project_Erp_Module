# from database import engine
# from models import Base
from database import engine
from models import Base   # correct place

print("Creating tables...")
Base.metadata.create_all(bind=engine)
print("Done.")