# import pandas as pd
from sqlalchemy.orm import Session
from database import SessionLocal
import models
import os

def generate_professional_report():
    db: Session = SessionLocal()
    try:
        print("📊 Generating Project Report for Submission...")

        # 1. Summary Sheet Data
        summary_data = {
            "Module": ["Academic Years", "Sections", "Departments", "Programs", "Classes", "Faculty", "Classrooms", "Labs", "Semesters", "Courses/Subjects"],
            "Record Count": [
                db.query(models.AcademicYear).count(),
                db.query(models.Section).count(),
                db.query(models.Department).count(),
                db.query(models.Program).count(),
                db.query(models.Class).count(),
                db.query(models.Faculty).count(),
                db.query(models.Classroom).count(),
                db.query(models.Lab).count(),
                db.query(models.Semester).count(),
                db.query(models.Course).count()
            ],
            "Status": ["Completed"] * 10
        }
        df_summary = pd.DataFrame(summary_data)

        # 2. API Inventory Sheet (Based on your routers)
        api_modules = [
            "Academic Calendar", "Academic Year", "Batch", "Class", "Classroom Occupancy", 
            "Classroom", "Course", "Department", "Division", "Faculty Timetable", 
            "Faculty", "Lab", "Logs", "Program", "Section", "Semester", 
            "Student Batch", "Timetable"
        ]
        df_api = pd.DataFrame({
            "API Module Name": api_modules,
            "Backend Router": [f"{m.lower().replace(' ', '_')}.py" for m in api_modules],
            "Status": "Functional / Integrated"
        })

        # 3. Faculty Directory
        faculty = db.query(models.Faculty).all()
        df_faculty = pd.DataFrame([{
            "Name": f.faculty_name,
            "Email": f.email,
            "Designation": f.designation,
            "Qualification": f.qualification,
            "Mobile": f.mobile_no
        } for f in faculty])

        # 4. Detailed Course Roadmap (The Core Work)
        courses = db.query(models.Course).join(models.Program).all()
        df_courses = pd.DataFrame([{
            "Program": c.program.program_name,
            "Subject Name": c.course_name,
            "Type": c.course_type,
            "Credits": c.course_credit,
            "Lecture Hours": c.course_hours,
            "Status": "Seeded (SPPU NEP 2024)"
        } for c in courses])

        # Write to Excel with multiple sheets
        filename = "College_ERP_Backend_Report.xlsx"
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            df_summary.to_excel(writer, sheet_name='Project Overview', index=False)
            df_api.to_excel(writer, sheet_name='API Inventory', index=False)
            df_courses.to_excel(writer, sheet_name='Academic Roadmap', index=False)
            df_faculty.to_excel(writer, sheet_name='Faculty List', index=False)

        print(f"✅ Report generated: {os.path.abspath(filename)}")
        print("You can now attach this file to your email to Sir.")

    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    generate_professional_report()