# from fastapi import FastAPI

# app = FastAPI()

# @app.get("/")
# def home():
#     return {"message": "FastAPI started !"}

#--------------------FAST API---------------------------#

# from fastapi import FastAPI
# from database import engine
# import models
# from routers import department

# models.Base.metadata.create_all(bind=engine)

# app = FastAPI(title="College ERP System")

# # Include routers
# app.include_router(department.router)

# @app.get("/")
# def home():
#     return {"message": "College ERP API is running!"}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~API for all routers~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

from fastapi import FastAPI
from database import engine
import models



from routers import (
    department,
    academic_year,
    section,
    program,
    class_,
    division,
    batch,
    faculty,
    course,
    semester,
    classroom,
    lab,
    academic_calendar,
    timetable,
    faculty_timetable,
    classroom_occupancy,
    student_batch,
    logs,
    fees,
)

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="College ERP System — Timetable & Academic Planning")


# ── Register all routers ──────────────────────────────────────
app.include_router(department.router)
app.include_router(academic_year.router)
app.include_router(section.router)
app.include_router(program.router)
app.include_router(class_.router)
app.include_router(division.router)
app.include_router(batch.router)
app.include_router(faculty.router)
app.include_router(course.router)
app.include_router(semester.router)
app.include_router(classroom.router)
app.include_router(lab.router)
app.include_router(academic_calendar.router)
app.include_router(timetable.router)
app.include_router(faculty_timetable.router)
app.include_router(classroom_occupancy.router)
app.include_router(student_batch.router)
app.include_router(logs.router)
app.include_router(fees.router) 


@app.get("/")
def home():
    return {"message": "College ERP API is running!"}
