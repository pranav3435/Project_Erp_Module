from sqlalchemy import (
    Column, Integer, String, Text, Boolean,
    Date, Time, DateTime, ForeignKey, UniqueConstraint
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


# ============================================================
# ACADEMIC PLANNING MODELS
# ============================================================

class AcademicYear(Base):
    __tablename__ = "academic_year"

    id            = Column(Integer, primary_key=True, index=True)
    academic_year = Column(String(20), nullable=False, unique=True)
    start_date    = Column(Date)
    end_date      = Column(Date)
    is_active     = Column(Boolean, default=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    semesters          = relationship("Semester", back_populates="academic_year_rel", foreign_keys="Semester.academic_year")
    academic_calendars = relationship("AcademicCalendar", back_populates="academic_year_rel", foreign_keys="AcademicCalendar.academic_year")


class Department(Base):
    __tablename__ = "department"

    id                     = Column(Integer, primary_key=True, index=True)
    department_name        = Column(String(100), nullable=False, unique=True)
    department_description = Column(Text)
    hod_id                 = Column(Integer, ForeignKey("faculty.id", ondelete="SET NULL"), nullable=True)
    created_at             = Column(DateTime(timezone=True), server_default=func.now())
    updated_at             = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    hod       = relationship("Faculty", foreign_keys=[hod_id], back_populates="headed_department")
    programs  = relationship("Program", back_populates="department")
    faculty   = relationship("Faculty", foreign_keys="Faculty.department_id", back_populates="department")
    courses   = relationship("Course", back_populates="department")
    classes   = relationship("Class", back_populates="department")
    divisions = relationship("Division", back_populates="department")
    batches   = relationship("Batch", back_populates="department")


class Section(Base):
    __tablename__ = "section"

    id           = Column(Integer, primary_key=True, index=True)
    section_name = Column(String(50), nullable=False)   # e.g. Undergraduate, Postgraduate, Diploma
    abbreviation = Column(String(10), nullable=False)   # e.g. UG, PG, DIP
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    updated_at   = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    programs  = relationship("Program", back_populates="section")
    divisions = relationship("Division", back_populates="section")
    batches   = relationship("Batch", back_populates="section")
    courses   = relationship("Course", back_populates="section")


class Program(Base):
    __tablename__ = "program"

    id               = Column(Integer, primary_key=True, index=True)
    program_name     = Column(String(150), nullable=False)
    department_id    = Column(Integer, ForeignKey("department.id", ondelete="CASCADE"), nullable=False)
    section_id       = Column(Integer, ForeignKey("section.id", ondelete="SET NULL"), nullable=True)
    program_duration = Column(Integer, nullable=False)  # in years
    program_level    = Column(String(10))               # NEP-2020 NCrF level: 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 8.0
    sanction_intake  = Column(Integer)
    sanction_div     = Column(Integer)
    created_at       = Column(DateTime(timezone=True), server_default=func.now())
    updated_at       = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    department = relationship("Department", back_populates="programs")
    section    = relationship("Section", back_populates="programs")
    classes    = relationship("Class", back_populates="program")
    divisions  = relationship("Division", back_populates="program")
    batches    = relationship("Batch", back_populates="program")
    courses    = relationship("Course", back_populates="program")
    semesters  = relationship("Semester", back_populates="program")


class Class(Base):
    __tablename__ = "class"

    id            = Column(Integer, primary_key=True, index=True)
    class_name    = Column(String(100), nullable=False)
    program_id    = Column(Integer, ForeignKey("program.id", ondelete="CASCADE"), nullable=False)
    department_id = Column(Integer, ForeignKey("department.id", ondelete="CASCADE"), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    program    = relationship("Program", back_populates="classes")
    department = relationship("Department", back_populates="classes")
    divisions  = relationship("Division", back_populates="class_rel")
    batches    = relationship("Batch", back_populates="class_rel")


class Division(Base):
    __tablename__ = "division"

    id            = Column(Integer, primary_key=True, index=True)
    div_name      = Column(String(10), nullable=False)
    class_id      = Column(Integer, ForeignKey("class.id", ondelete="CASCADE"), nullable=False)
    program_id    = Column(Integer, ForeignKey("program.id", ondelete="CASCADE"), nullable=False)
    section_id    = Column(Integer, ForeignKey("section.id", ondelete="SET NULL"), nullable=True)
    department_id = Column(Integer, ForeignKey("department.id", ondelete="CASCADE"), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint("div_name", "class_id", name="uq_division_name_class"),
    )

    # Relationships
    class_rel   = relationship("Class", back_populates="divisions")
    program     = relationship("Program", back_populates="divisions")
    section     = relationship("Section", back_populates="divisions")
    department  = relationship("Department", back_populates="divisions")
    batches     = relationship("Batch", back_populates="division")
    timetables  = relationship("Timetable", back_populates="division")
    occupancies = relationship("ClassroomOccupancy", back_populates="division")


class Batch(Base):
    __tablename__ = "batch"

    id            = Column(Integer, primary_key=True, index=True)
    batch_name    = Column(String(50), nullable=False)
    program_id    = Column(Integer, ForeignKey("program.id", ondelete="CASCADE"), nullable=False)
    section_id    = Column(Integer, ForeignKey("section.id", ondelete="SET NULL"), nullable=True)
    class_id      = Column(Integer, ForeignKey("class.id", ondelete="CASCADE"), nullable=False)
    div_id        = Column(Integer, ForeignKey("division.id", ondelete="CASCADE"), nullable=False)
    department_id = Column(Integer, ForeignKey("department.id", ondelete="CASCADE"), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    program      = relationship("Program", back_populates="batches")
    section      = relationship("Section", back_populates="batches")
    class_rel    = relationship("Class", back_populates="batches")
    division     = relationship("Division", back_populates="batches")
    department   = relationship("Department", back_populates="batches")
    student_maps = relationship("StudentBatch", back_populates="batch")


class StudentBatch(Base):
    """
    Cross-module mapping table.
    student_id comes from the Student module (managed by another team).
    This table simply links a student (by their ID) to a batch in this module.
    """
    __tablename__ = "student_batch"

    id         = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, nullable=False, index=True)  # from Student module (external)
    batch_id   = Column(Integer, ForeignKey("batch.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint("student_id", "batch_id", name="uq_student_batch"),
    )

    # Relationships
    batch = relationship("Batch", back_populates="student_maps")


class Faculty(Base):
    __tablename__ = "faculty"

    id            = Column(Integer, primary_key=True, index=True)
    faculty_name  = Column(String(150), nullable=False)
    email         = Column(String(150), nullable=False, unique=True)
    designation   = Column(String(100))
    qualification = Column(String(150))
    mobile_no     = Column(String(15))
    faculty_photo = Column(String(255))
    faculty_type  = Column(String(50))                  # full-time / part-time / visiting
    department_id = Column(Integer, ForeignKey("department.id", ondelete="SET NULL"), nullable=True)
    time_slot     = Column(String(100))
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    department         = relationship("Department", foreign_keys=[department_id], back_populates="faculty")
    headed_department  = relationship("Department", foreign_keys="Department.hod_id", back_populates="hod")
    timetables         = relationship("Timetable", back_populates="faculty")
    faculty_timetables = relationship("FacultyTimetable", back_populates="faculty")


class Course(Base):
    __tablename__ = "course"

    id            = Column(Integer, primary_key=True, index=True)
    course_name   = Column(String(150), nullable=False)
    course_type   = Column(String(50))                  # theory / practical / elective
    course_credit = Column(Integer)
    course_hours  = Column(Integer)                     # hours per week
    program_id    = Column(Integer, ForeignKey("program.id", ondelete="CASCADE"), nullable=False)
    section_id    = Column(Integer, ForeignKey("section.id", ondelete="SET NULL"), nullable=True)
    department_id = Column(Integer, ForeignKey("department.id", ondelete="CASCADE"), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    program    = relationship("Program", back_populates="courses")
    section    = relationship("Section", back_populates="courses")
    department = relationship("Department", back_populates="courses")
    timetables = relationship("Timetable", back_populates="subject")


# ============================================================
# TIMETABLE MODELS
# ============================================================

class Semester(Base):
    __tablename__ = "semester"

    id              = Column(Integer, primary_key=True, index=True)
    semester_number = Column(String(5), nullable=False)  # Roman numerals: I, II, III … VIII
    program_id      = Column(Integer, ForeignKey("program.id", ondelete="SET NULL"), nullable=True)
    max_semesters   = Column(Integer)                    # UG non-NEP=6, UG NEP=8, PG=4
    academic_year   = Column(String(20), ForeignKey("academic_year.academic_year", ondelete="SET NULL"), nullable=True)
    created_at      = Column(DateTime(timezone=True), server_default=func.now())
    updated_at      = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    program            = relationship("Program", back_populates="semesters")
    academic_year_rel  = relationship("AcademicYear", foreign_keys=[academic_year], back_populates="semesters")
    timetables         = relationship("Timetable", back_populates="semester")
    academic_calendars = relationship("AcademicCalendar", back_populates="semester")
    occupancies        = relationship("ClassroomOccupancy", back_populates="semester")


class Classroom(Base):
    __tablename__ = "classroom"

    id                  = Column(Integer, primary_key=True, index=True)
    room_number         = Column(String(20), nullable=False, unique=True)
    building            = Column(String(50))
    capacity            = Column(Integer)
    room_type           = Column(String(30))             # lecture / seminar / computer_lab
    availability_status = Column(String(20), default="available")
    created_at          = Column(DateTime(timezone=True), server_default=func.now())
    updated_at          = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    timetables  = relationship("Timetable", back_populates="classroom")
    occupancies = relationship("ClassroomOccupancy", back_populates="classroom")


class Lab(Base):
    __tablename__ = "lab"

    id                  = Column(Integer, primary_key=True, index=True)
    lab_number          = Column(String(20), nullable=False)
    lab_name            = Column(String(150))
    building            = Column(String(50))
    capacity            = Column(Integer)
    availability_status = Column(String(20), default="available")
    day_of_week         = Column(String(15))
    time_slot           = Column(String(30))
    class_id            = Column(Integer, ForeignKey("class.id", ondelete="SET NULL"), nullable=True)
    batch_id            = Column(Integer, ForeignKey("batch.id", ondelete="SET NULL"), nullable=True)
    course_id           = Column(Integer, ForeignKey("course.id", ondelete="SET NULL"), nullable=True)
    department_id       = Column(Integer, ForeignKey("department.id", ondelete="SET NULL"), nullable=True)
    created_at          = Column(DateTime(timezone=True), server_default=func.now())
    updated_at          = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    class_rel  = relationship("Class", foreign_keys=[class_id])
    batch      = relationship("Batch", foreign_keys=[batch_id])
    course     = relationship("Course", foreign_keys=[course_id])
    department = relationship("Department", foreign_keys=[department_id])
    timetables = relationship("Timetable", back_populates="lab")


class AcademicCalendar(Base):
    __tablename__ = "academic_calendar"

    id            = Column(Integer, primary_key=True, index=True)
    academic_year = Column(String(20), ForeignKey("academic_year.academic_year", ondelete="SET NULL"), nullable=True)
    semester_id   = Column(Integer, ForeignKey("semester.id", ondelete="SET NULL"), nullable=True)
    start_date    = Column(Date)
    end_date      = Column(Date)
    day_type      = Column(String(20))                  # working / holiday / exam
    event_name    = Column(String(200))
    event_type    = Column(String(50))                  # holiday / exam / activity
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    academic_year_rel = relationship("AcademicYear", foreign_keys=[academic_year], back_populates="academic_calendars")
    semester          = relationship("Semester", back_populates="academic_calendars")


class Timetable(Base):
    __tablename__ = "timetable"

    id            = Column(Integer, primary_key=True, index=True)
    day           = Column(String(20), nullable=False)
    start_time    = Column(Time, nullable=False)
    end_time      = Column(Time, nullable=False)
    sub_id        = Column(Integer, ForeignKey("course.id", ondelete="SET NULL"), nullable=True)
    faculty_id    = Column(Integer, ForeignKey("faculty.id", ondelete="SET NULL"), nullable=True)
    classroom_id  = Column(Integer, ForeignKey("classroom.id", ondelete="SET NULL"), nullable=True)
    lab_id        = Column(Integer, ForeignKey("lab.id", ondelete="SET NULL"), nullable=True)
    semester_id   = Column(Integer, ForeignKey("semester.id", ondelete="SET NULL"), nullable=True)
    division_id   = Column(Integer, ForeignKey("division.id", ondelete="SET NULL"), nullable=True)
    academic_year = Column(String(20))
    batch_id     = Column(Integer, ForeignKey("batch.id", ondelete="SET NULL"), nullable=True)
    session_type = Column(String(20), default="lecture")  # lecture/practical/lunch_break
    is_break     = Column(Boolean, default=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint("faculty_id", "day", "start_time", "academic_year",   name="uq_faculty_slot"),
        UniqueConstraint("classroom_id", "day", "start_time", "academic_year", name="uq_classroom_slot"),
    )

    # Relationships
    subject            = relationship("Course", back_populates="timetables")
    faculty            = relationship("Faculty", back_populates="timetables")
    classroom          = relationship("Classroom", back_populates="timetables")
    lab                = relationship("Lab", back_populates="timetables")
    semester           = relationship("Semester", back_populates="timetables")
    division           = relationship("Division", back_populates="timetables")
    faculty_timetables = relationship("FacultyTimetable", back_populates="timetable")
    batch              = relationship("Batch", foreign_keys=[batch_id])


class FacultyTimetable(Base):
    __tablename__ = "faculty_timetable"

    id           = Column(Integer, primary_key=True, index=True)
    timetable_id = Column(Integer, ForeignKey("timetable.id", ondelete="CASCADE"), nullable=True)
    faculty_id   = Column(Integer, ForeignKey("faculty.id", ondelete="CASCADE"), nullable=True)
    day_of_week  = Column(String(15))
    time_slot    = Column(String(30))
    class_name   = Column(String(60))
    course_id    = Column(Integer, ForeignKey("course.id", ondelete="SET NULL"), nullable=True)
    session_type = Column(String(20))                   # lecture / practical / tutorial
    workload     = Column(Integer)                      # in hours
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    updated_at   = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    timetable = relationship("Timetable", back_populates="faculty_timetables")
    faculty   = relationship("Faculty", back_populates="faculty_timetables")
    course    = relationship("Course", foreign_keys=[course_id])


class ClassroomOccupancy(Base):
    __tablename__ = "classroom_occupancy"

    id            = Column(Integer, primary_key=True, index=True)
    day           = Column(String(20), nullable=False)
    start_time    = Column(Time, nullable=False)
    end_time      = Column(Time, nullable=False)
    classroom_id  = Column(Integer, ForeignKey("classroom.id", ondelete="CASCADE"), nullable=False)
    semester_id   = Column(Integer, ForeignKey("semester.id", ondelete="SET NULL"), nullable=True)
    division_id   = Column(Integer, ForeignKey("division.id", ondelete="SET NULL"), nullable=True)
    academic_year = Column(String(20))
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    classroom = relationship("Classroom", back_populates="occupancies")
    semester  = relationship("Semester", back_populates="occupancies")
    division  = relationship("Division", back_populates="occupancies")


# ============================================================
# LOGS MODEL
# ============================================================

class Log(Base):
    __tablename__ = "logs"

    log_id           = Column(Integer, primary_key=True, index=True)
    user_id          = Column(Integer, nullable=False, index=True)
    access_date_time = Column(DateTime(timezone=True), nullable=False, server_default=func.now())
    created_at       = Column(DateTime(timezone=True), server_default=func.now())
    updated_at       = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


##-----------------------PROGRAM FEES------------------------------##

class ProgramFees(Base):
    __tablename__ = "program_fees"

    id                   = Column(Integer, primary_key=True, index=True)
    class_id             = Column(Integer, ForeignKey("class.id", ondelete="CASCADE"), nullable=False)
    academic_year        = Column(String(20), ForeignKey("academic_year.academic_year", ondelete="SET NULL"), nullable=True)
    total_fees           = Column(Integer, nullable=False)          # total fees in INR
    installments_allowed = Column(Integer, default=1)               # how many installments allowed
    created_at           = Column(DateTime(timezone=True), server_default=func.now())
    updated_at           = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    class_rel         = relationship("Class", foreign_keys=[class_id])
    academic_year_rel = relationship("AcademicYear", foreign_keys=[academic_year])
    installments      = relationship("FeeInstallment", back_populates="program_fees")


class FeeInstallment(Base):
    __tablename__ = "fee_installment"

    id              = Column(Integer, primary_key=True, index=True)
    program_fees_id = Column(Integer, ForeignKey("program_fees.id", ondelete="CASCADE"), nullable=False)
    installment_no  = Column(Integer, nullable=False)               # 1, 2, 3
    amount          = Column(Integer, nullable=False)               # amount in INR
    due_date        = Column(Date, nullable=True)                   # due date for installment
    created_at      = Column(DateTime(timezone=True), server_default=func.now())
    updated_at      = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    program_fees = relationship("ProgramFees", back_populates="installments")