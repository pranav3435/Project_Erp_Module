from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import AcademicCalendar
from schemas import AcademicCalendarCreate, AcademicCalendarUpdate, AcademicCalendarResponse

router = APIRouter(prefix="/academic-calendar", tags=["Academic Calendar"])

@router.post("/", response_model=AcademicCalendarResponse, status_code=status.HTTP_201_CREATED)
def create_event(data: AcademicCalendarCreate, db: Session = Depends(get_db)):
    new = AcademicCalendar(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[AcademicCalendarResponse])
def get_all_events(db: Session = Depends(get_db)):
    return db.query(AcademicCalendar).all()

@router.get("/{id}", response_model=AcademicCalendarResponse)
def get_event(id: int, db: Session = Depends(get_db)):
    record = db.query(AcademicCalendar).filter(AcademicCalendar.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Event with id {id} not found")
    return record

@router.get("/year/{academic_year}", response_model=List[AcademicCalendarResponse])
def get_events_by_year(academic_year: str, db: Session = Depends(get_db)):
    return db.query(AcademicCalendar).filter(AcademicCalendar.academic_year == academic_year).all()

@router.put("/{id}", response_model=AcademicCalendarResponse)
def update_event(id: int, data: AcademicCalendarUpdate, db: Session = Depends(get_db)):
    record = db.query(AcademicCalendar).filter(AcademicCalendar.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Event with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_event(id: int, db: Session = Depends(get_db)):
    record = db.query(AcademicCalendar).filter(AcademicCalendar.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Event with id {id} not found")
    db.delete(record); db.commit()
    return None
