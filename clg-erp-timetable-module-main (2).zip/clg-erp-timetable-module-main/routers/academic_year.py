from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import AcademicYear
from schemas import AcademicYearCreate, AcademicYearUpdate, AcademicYearResponse

router = APIRouter(prefix="/academic-years", tags=["Academic Years"])


@router.post("/", response_model=AcademicYearResponse, status_code=status.HTTP_201_CREATED)
def create_academic_year(data: AcademicYearCreate, db: Session = Depends(get_db)):
    existing = db.query(AcademicYear).filter(AcademicYear.academic_year == data.academic_year).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Academic year '{data.academic_year}' already exists")
    new = AcademicYear(**data.model_dump())
    db.add(new)
    db.commit()
    db.refresh(new)
    return new


@router.get("/", response_model=List[AcademicYearResponse])
def get_all_academic_years(db: Session = Depends(get_db)):
    return db.query(AcademicYear).all()


@router.get("/{id}", response_model=AcademicYearResponse)
def get_academic_year(id: int, db: Session = Depends(get_db)):
    record = db.query(AcademicYear).filter(AcademicYear.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Academic year with id {id} not found")
    return record


@router.put("/{id}", response_model=AcademicYearResponse)
def update_academic_year(id: int, data: AcademicYearUpdate, db: Session = Depends(get_db)):
    record = db.query(AcademicYear).filter(AcademicYear.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Academic year with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit()
    db.refresh(record)
    return record


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_academic_year(id: int, db: Session = Depends(get_db)):
    record = db.query(AcademicYear).filter(AcademicYear.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Academic year with id {id} not found")
    db.delete(record)
    db.commit()
    return None
