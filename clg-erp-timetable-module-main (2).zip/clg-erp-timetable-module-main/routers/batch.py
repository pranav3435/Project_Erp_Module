from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Batch
from schemas import BatchCreate, BatchUpdate, BatchResponse

router = APIRouter(prefix="/batches", tags=["Batches"])

@router.post("/", response_model=BatchResponse, status_code=status.HTTP_201_CREATED)
def create_batch(data: BatchCreate, db: Session = Depends(get_db)):
    new = Batch(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[BatchResponse])
def get_all_batches(db: Session = Depends(get_db)):
    return db.query(Batch).all()

@router.get("/{id}", response_model=BatchResponse)
def get_batch(id: int, db: Session = Depends(get_db)):
    record = db.query(Batch).filter(Batch.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Batch with id {id} not found")
    return record

@router.get("/division/{div_id}", response_model=List[BatchResponse])
def get_batches_by_division(div_id: int, db: Session = Depends(get_db)):
    return db.query(Batch).filter(Batch.div_id == div_id).all()

@router.put("/{id}", response_model=BatchResponse)
def update_batch(id: int, data: BatchUpdate, db: Session = Depends(get_db)):
    record = db.query(Batch).filter(Batch.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Batch with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_batch(id: int, db: Session = Depends(get_db)):
    record = db.query(Batch).filter(Batch.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Batch with id {id} not found")
    db.delete(record); db.commit()
    return None
