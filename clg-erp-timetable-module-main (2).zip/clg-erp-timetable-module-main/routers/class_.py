from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Class
from schemas import ClassCreate, ClassUpdate, ClassResponse

router = APIRouter(prefix="/classes", tags=["Classes"])


@router.post("/", response_model=ClassResponse, status_code=status.HTTP_201_CREATED)
def create_class(data: ClassCreate, db: Session = Depends(get_db)):
    new = Class(**data.model_dump())
    db.add(new)
    db.commit()
    db.refresh(new)
    return new


@router.get("/", response_model=List[ClassResponse])
def get_all_classes(db: Session = Depends(get_db)):
    return db.query(Class).all()


@router.get("/{id}", response_model=ClassResponse)
def get_class(id: int, db: Session = Depends(get_db)):
    record = db.query(Class).filter(Class.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Class with id {id} not found")
    return record


@router.get("/program/{program_id}", response_model=List[ClassResponse])
def get_classes_by_program(program_id: int, db: Session = Depends(get_db)):
    return db.query(Class).filter(Class.program_id == program_id).all()


@router.put("/{id}", response_model=ClassResponse)
def update_class(id: int, data: ClassUpdate, db: Session = Depends(get_db)):
    record = db.query(Class).filter(Class.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Class with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit()
    db.refresh(record)
    return record


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_class(id: int, db: Session = Depends(get_db)):
    record = db.query(Class).filter(Class.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Class with id {id} not found")
    db.delete(record)
    db.commit()
    return None
