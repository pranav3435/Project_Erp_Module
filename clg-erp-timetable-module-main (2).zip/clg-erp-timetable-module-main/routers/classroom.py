from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Classroom
from schemas import ClassroomCreate, ClassroomUpdate, ClassroomResponse

router = APIRouter(prefix="/classrooms", tags=["Classrooms"])

@router.post("/", response_model=ClassroomResponse, status_code=status.HTTP_201_CREATED)
def create_classroom(data: ClassroomCreate, db: Session = Depends(get_db)):
    existing = db.query(Classroom).filter(Classroom.room_number == data.room_number).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Classroom '{data.room_number}' already exists")
    new = Classroom(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[ClassroomResponse])
def get_all_classrooms(db: Session = Depends(get_db)):
    return db.query(Classroom).all()

@router.get("/{id}", response_model=ClassroomResponse)
def get_classroom(id: int, db: Session = Depends(get_db)):
    record = db.query(Classroom).filter(Classroom.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Classroom with id {id} not found")
    return record

@router.put("/{id}", response_model=ClassroomResponse)
def update_classroom(id: int, data: ClassroomUpdate, db: Session = Depends(get_db)):
    record = db.query(Classroom).filter(Classroom.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Classroom with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_classroom(id: int, db: Session = Depends(get_db)):
    record = db.query(Classroom).filter(Classroom.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Classroom with id {id} not found")
    db.delete(record); db.commit()
    return None
