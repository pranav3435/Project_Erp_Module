from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import ClassroomOccupancy
from schemas import ClassroomOccupancyCreate, ClassroomOccupancyUpdate, ClassroomOccupancyResponse

router = APIRouter(prefix="/classroom-occupancy", tags=["Classroom Occupancy"])

@router.post("/", response_model=ClassroomOccupancyResponse, status_code=status.HTTP_201_CREATED)
def create_occupancy(data: ClassroomOccupancyCreate, db: Session = Depends(get_db)):
    new = ClassroomOccupancy(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[ClassroomOccupancyResponse])
def get_all_occupancies(db: Session = Depends(get_db)):
    return db.query(ClassroomOccupancy).all()

@router.get("/{id}", response_model=ClassroomOccupancyResponse)
def get_occupancy(id: int, db: Session = Depends(get_db)):
    record = db.query(ClassroomOccupancy).filter(ClassroomOccupancy.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Occupancy record with id {id} not found")
    return record

@router.get("/classroom/{classroom_id}", response_model=List[ClassroomOccupancyResponse])
def get_occupancy_by_classroom(classroom_id: int, db: Session = Depends(get_db)):
    return db.query(ClassroomOccupancy).filter(ClassroomOccupancy.classroom_id == classroom_id).all()

@router.put("/{id}", response_model=ClassroomOccupancyResponse)
def update_occupancy(id: int, data: ClassroomOccupancyUpdate, db: Session = Depends(get_db)):
    record = db.query(ClassroomOccupancy).filter(ClassroomOccupancy.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Occupancy record with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_occupancy(id: int, db: Session = Depends(get_db)):
    record = db.query(ClassroomOccupancy).filter(ClassroomOccupancy.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Occupancy record with id {id} not found")
    db.delete(record); db.commit()
    return None
