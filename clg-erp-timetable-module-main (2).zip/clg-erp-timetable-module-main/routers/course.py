from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Course
from schemas import CourseCreate, CourseUpdate, CourseResponse

router = APIRouter(prefix="/courses", tags=["Courses"])

@router.post("/", response_model=CourseResponse, status_code=status.HTTP_201_CREATED)
def create_course(data: CourseCreate, db: Session = Depends(get_db)):
    new = Course(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[CourseResponse])
def get_all_courses(db: Session = Depends(get_db)):
    return db.query(Course).all()

@router.get("/{id}", response_model=CourseResponse)
def get_course(id: int, db: Session = Depends(get_db)):
    record = db.query(Course).filter(Course.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Course with id {id} not found")
    return record

@router.get("/program/{program_id}", response_model=List[CourseResponse])
def get_courses_by_program(program_id: int, db: Session = Depends(get_db)):
    return db.query(Course).filter(Course.program_id == program_id).all()

@router.get("/department/{department_id}", response_model=List[CourseResponse])
def get_courses_by_department(department_id: int, db: Session = Depends(get_db)):
    return db.query(Course).filter(Course.department_id == department_id).all()

@router.put("/{id}", response_model=CourseResponse)
def update_course(id: int, data: CourseUpdate, db: Session = Depends(get_db)):
    record = db.query(Course).filter(Course.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Course with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_course(id: int, db: Session = Depends(get_db)):
    record = db.query(Course).filter(Course.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Course with id {id} not found")
    db.delete(record); db.commit()
    return None
