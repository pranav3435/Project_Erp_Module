from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Department
from schemas import DepartmentCreate, DepartmentUpdate, DepartmentResponse

router = APIRouter(
    prefix="/departments",
    tags=["Departments"]
)


# ── CREATE ────────────────────────────────────────────────────
@router.post("/", response_model=DepartmentResponse, status_code=status.HTTP_201_CREATED)
def create_department(department: DepartmentCreate, db: Session = Depends(get_db)):
    # Check if department already exists
    existing = db.query(Department).filter(
        Department.department_name == department.department_name
    ).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Department '{department.department_name}' already exists"
        )
    new_department = Department(**department.model_dump())
    db.add(new_department)
    db.commit()
    db.refresh(new_department)
    return new_department


# ── GET ALL ───────────────────────────────────────────────────
@router.get("/", response_model=List[DepartmentResponse])
def get_all_departments(db: Session = Depends(get_db)):
    departments = db.query(Department).all()
    return departments


# ── GET ONE ───────────────────────────────────────────────────
@router.get("/{department_id}", response_model=DepartmentResponse)
def get_department(department_id: int, db: Session = Depends(get_db)):
    department = db.query(Department).filter(Department.id == department_id).first()
    if not department:
        raise HTTPException(
            status_code=404,
            detail=f"Department with id {department_id} not found"
        )
    return department


# ── UPDATE ────────────────────────────────────────────────────
@router.put("/{department_id}", response_model=DepartmentResponse)
def update_department(department_id: int, updated_data: DepartmentUpdate, db: Session = Depends(get_db)):
    department = db.query(Department).filter(Department.id == department_id).first()
    if not department:
        raise HTTPException(
            status_code=404,
            detail=f"Department with id {department_id} not found"
        )
    for key, value in updated_data.model_dump(exclude_unset=True).items():
        setattr(department, key, value)
    db.commit()
    db.refresh(department)
    return department


# ── DELETE ────────────────────────────────────────────────────
@router.delete("/{department_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_department(department_id: int, db: Session = Depends(get_db)):
    department = db.query(Department).filter(Department.id == department_id).first()
    if not department:
        raise HTTPException(
            status_code=404,
            detail=f"Department with id {department_id} not found"
        )
    db.delete(department)
    db.commit()
    return None