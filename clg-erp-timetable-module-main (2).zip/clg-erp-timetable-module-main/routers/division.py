# ── division.py ───────────────────────────────────────────────
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Division
from schemas import DivisionCreate, DivisionUpdate, DivisionResponse

router = APIRouter(prefix="/divisions", tags=["Divisions"])

@router.post("/", response_model=DivisionResponse, status_code=status.HTTP_201_CREATED)
def create_division(data: DivisionCreate, db: Session = Depends(get_db)):
    new = Division(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[DivisionResponse])
def get_all_divisions(db: Session = Depends(get_db)):
    return db.query(Division).all()

@router.get("/{id}", response_model=DivisionResponse)
def get_division(id: int, db: Session = Depends(get_db)):
    record = db.query(Division).filter(Division.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Division with id {id} not found")
    return record

@router.get("/class/{class_id}", response_model=List[DivisionResponse])
def get_divisions_by_class(class_id: int, db: Session = Depends(get_db)):
    return db.query(Division).filter(Division.class_id == class_id).all()

@router.put("/{id}", response_model=DivisionResponse)
def update_division(id: int, data: DivisionUpdate, db: Session = Depends(get_db)):
    record = db.query(Division).filter(Division.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Division with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_division(id: int, db: Session = Depends(get_db)):
    record = db.query(Division).filter(Division.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Division with id {id} not found")
    db.delete(record); db.commit()
    return None
