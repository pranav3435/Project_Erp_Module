from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Faculty
from schemas import FacultyCreate, FacultyUpdate, FacultyResponse

router = APIRouter(prefix="/faculty", tags=["Faculty"])

@router.post("/", response_model=FacultyResponse, status_code=status.HTTP_201_CREATED)
def create_faculty(data: FacultyCreate, db: Session = Depends(get_db)):
    existing = db.query(Faculty).filter(Faculty.email == data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Faculty with email '{data.email}' already exists")
    new = Faculty(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[FacultyResponse])
def get_all_faculty(db: Session = Depends(get_db)):
    return db.query(Faculty).all()

@router.get("/{id}", response_model=FacultyResponse)
def get_faculty(id: int, db: Session = Depends(get_db)):
    record = db.query(Faculty).filter(Faculty.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Faculty with id {id} not found")
    return record

@router.get("/department/{department_id}", response_model=List[FacultyResponse])
def get_faculty_by_department(department_id: int, db: Session = Depends(get_db)):
    return db.query(Faculty).filter(Faculty.department_id == department_id).all()

@router.put("/{id}", response_model=FacultyResponse)
def update_faculty(id: int, data: FacultyUpdate, db: Session = Depends(get_db)):
    record = db.query(Faculty).filter(Faculty.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Faculty with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_faculty(id: int, db: Session = Depends(get_db)):
    record = db.query(Faculty).filter(Faculty.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Faculty with id {id} not found")
    db.delete(record); db.commit()
    return None
