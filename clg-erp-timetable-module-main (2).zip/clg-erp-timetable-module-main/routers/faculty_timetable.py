from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import FacultyTimetable
from schemas import FacultyTimetableCreate, FacultyTimetableUpdate, FacultyTimetableResponse

router = APIRouter(prefix="/faculty-timetables", tags=["Faculty Timetable"])

@router.post("/", response_model=FacultyTimetableResponse, status_code=status.HTTP_201_CREATED)
def create_faculty_timetable(data: FacultyTimetableCreate, db: Session = Depends(get_db)):
    new = FacultyTimetable(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[FacultyTimetableResponse])
def get_all_faculty_timetables(db: Session = Depends(get_db)):
    return db.query(FacultyTimetable).all()

@router.get("/{id}", response_model=FacultyTimetableResponse)
def get_faculty_timetable(id: int, db: Session = Depends(get_db)):
    record = db.query(FacultyTimetable).filter(FacultyTimetable.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Faculty timetable with id {id} not found")
    return record

@router.get("/faculty/{faculty_id}", response_model=List[FacultyTimetableResponse])
def get_timetable_by_faculty(faculty_id: int, db: Session = Depends(get_db)):
    return db.query(FacultyTimetable).filter(FacultyTimetable.faculty_id == faculty_id).all()

@router.put("/{id}", response_model=FacultyTimetableResponse)
def update_faculty_timetable(id: int, data: FacultyTimetableUpdate, db: Session = Depends(get_db)):
    record = db.query(FacultyTimetable).filter(FacultyTimetable.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Faculty timetable with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_faculty_timetable(id: int, db: Session = Depends(get_db)):
    record = db.query(FacultyTimetable).filter(FacultyTimetable.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Faculty timetable with id {id} not found")
    db.delete(record); db.commit()
    return None
