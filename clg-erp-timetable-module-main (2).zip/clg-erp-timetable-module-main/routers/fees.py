from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import ProgramFees, FeeInstallment
from schemas import (
    ProgramFeesCreate, ProgramFeesUpdate, ProgramFeesResponse,
    FeeInstallmentCreate, FeeInstallmentUpdate, FeeInstallmentResponse
)

router = APIRouter(prefix="/fees", tags=["Fees"])


# ── PROGRAM FEES ──────────────────────────────────────────────

@router.post("/", response_model=ProgramFeesResponse, status_code=status.HTTP_201_CREATED)
def create_program_fees(data: ProgramFeesCreate, db: Session = Depends(get_db)):
    existing = db.query(ProgramFees).filter_by(
        class_id=data.class_id, academic_year=data.academic_year
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Fees for this class and year already exist")
    new = ProgramFees(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[ProgramFeesResponse])
def get_all_fees(db: Session = Depends(get_db)):
    return db.query(ProgramFees).all()

@router.get("/{id}", response_model=ProgramFeesResponse)
def get_fees(id: int, db: Session = Depends(get_db)):
    record = db.query(ProgramFees).filter(ProgramFees.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Fees record with id {id} not found")
    return record

@router.get("/class/{class_id}", response_model=List[ProgramFeesResponse])
def get_fees_by_class(class_id: int, db: Session = Depends(get_db)):
    return db.query(ProgramFees).filter(ProgramFees.class_id == class_id).all()

@router.put("/{id}", response_model=ProgramFeesResponse)
def update_fees(id: int, data: ProgramFeesUpdate, db: Session = Depends(get_db)):
    record = db.query(ProgramFees).filter(ProgramFees.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Fees record with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_fees(id: int, db: Session = Depends(get_db)):
    record = db.query(ProgramFees).filter(ProgramFees.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Fees record with id {id} not found")
    db.delete(record); db.commit()
    return None


# ── FEE INSTALLMENTS ──────────────────────────────────────────

@router.post("/installments/", response_model=FeeInstallmentResponse, status_code=status.HTTP_201_CREATED)
def create_installment(data: FeeInstallmentCreate, db: Session = Depends(get_db)):
    new = FeeInstallment(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/installments/", response_model=List[FeeInstallmentResponse])
def get_all_installments(db: Session = Depends(get_db)):
    return db.query(FeeInstallment).all()

@router.get("/installments/{id}", response_model=FeeInstallmentResponse)
def get_installment(id: int, db: Session = Depends(get_db)):
    record = db.query(FeeInstallment).filter(FeeInstallment.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Installment with id {id} not found")
    return record

@router.get("/installments/fees/{program_fees_id}", response_model=List[FeeInstallmentResponse])
def get_installments_by_fees(program_fees_id: int, db: Session = Depends(get_db)):
    return db.query(FeeInstallment).filter(
        FeeInstallment.program_fees_id == program_fees_id
    ).all()

@router.put("/installments/{id}", response_model=FeeInstallmentResponse)
def update_installment(id: int, data: FeeInstallmentUpdate, db: Session = Depends(get_db)):
    record = db.query(FeeInstallment).filter(FeeInstallment.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Installment with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/installments/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_installment(id: int, db: Session = Depends(get_db)):
    record = db.query(FeeInstallment).filter(FeeInstallment.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Installment with id {id} not found")
    db.delete(record); db.commit()
    return None
