from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Lab
from schemas import LabCreate, LabUpdate, LabResponse

router = APIRouter(prefix="/labs", tags=["Labs"])

@router.post("/", response_model=LabResponse, status_code=status.HTTP_201_CREATED)
def create_lab(data: LabCreate, db: Session = Depends(get_db)):
    new = Lab(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[LabResponse])
def get_all_labs(db: Session = Depends(get_db)):
    return db.query(Lab).all()

@router.get("/{id}", response_model=LabResponse)
def get_lab(id: int, db: Session = Depends(get_db)):
    record = db.query(Lab).filter(Lab.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Lab with id {id} not found")
    return record

@router.put("/{id}", response_model=LabResponse)
def update_lab(id: int, data: LabUpdate, db: Session = Depends(get_db)):
    record = db.query(Lab).filter(Lab.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Lab with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_lab(id: int, db: Session = Depends(get_db)):
    record = db.query(Lab).filter(Lab.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Lab with id {id} not found")
    db.delete(record); db.commit()
    return None
