from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Log
from schemas import LogCreate, LogResponse

router = APIRouter(prefix="/logs", tags=["Logs"])

@router.post("/", response_model=LogResponse, status_code=status.HTTP_201_CREATED)
def create_log(data: LogCreate, db: Session = Depends(get_db)):
    new = Log(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[LogResponse])
def get_all_logs(db: Session = Depends(get_db)):
    return db.query(Log).all()

@router.get("/{log_id}", response_model=LogResponse)
def get_log(log_id: int, db: Session = Depends(get_db)):
    record = db.query(Log).filter(Log.log_id == log_id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Log with id {log_id} not found")
    return record

@router.get("/user/{user_id}", response_model=List[LogResponse])
def get_logs_by_user(user_id: int, db: Session = Depends(get_db)):
    return db.query(Log).filter(Log.user_id == user_id).all()

@router.delete("/{log_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_log(log_id: int, db: Session = Depends(get_db)):
    record = db.query(Log).filter(Log.log_id == log_id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Log with id {log_id} not found")
    db.delete(record); db.commit()
    return None
