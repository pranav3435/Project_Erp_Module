from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Program
from schemas import ProgramCreate, ProgramUpdate, ProgramResponse

router = APIRouter(prefix="/programs", tags=["Programs"])


@router.post("/", response_model=ProgramResponse, status_code=status.HTTP_201_CREATED)
def create_program(data: ProgramCreate, db: Session = Depends(get_db)):
    new = Program(**data.model_dump())
    db.add(new)
    db.commit()
    db.refresh(new)
    return new


@router.get("/", response_model=List[ProgramResponse])
def get_all_programs(db: Session = Depends(get_db)):
    return db.query(Program).all()


@router.get("/{id}", response_model=ProgramResponse)
def get_program(id: int, db: Session = Depends(get_db)):
    record = db.query(Program).filter(Program.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Program with id {id} not found")
    return record


@router.get("/department/{department_id}", response_model=List[ProgramResponse])
def get_programs_by_department(department_id: int, db: Session = Depends(get_db)):
    return db.query(Program).filter(Program.department_id == department_id).all()


@router.put("/{id}", response_model=ProgramResponse)
def update_program(id: int, data: ProgramUpdate, db: Session = Depends(get_db)):
    record = db.query(Program).filter(Program.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Program with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit()
    db.refresh(record)
    return record


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_program(id: int, db: Session = Depends(get_db)):
    record = db.query(Program).filter(Program.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Program with id {id} not found")
    db.delete(record)
    db.commit()
    return None
