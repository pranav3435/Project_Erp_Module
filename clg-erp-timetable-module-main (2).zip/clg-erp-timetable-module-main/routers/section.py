from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Section
from schemas import SectionCreate, SectionUpdate, SectionResponse

router = APIRouter(prefix="/sections", tags=["Sections"])


@router.post("/", response_model=SectionResponse, status_code=status.HTTP_201_CREATED)
def create_section(data: SectionCreate, db: Session = Depends(get_db)):
    new = Section(**data.model_dump())
    db.add(new)
    db.commit()
    db.refresh(new)
    return new


@router.get("/", response_model=List[SectionResponse])
def get_all_sections(db: Session = Depends(get_db)):
    return db.query(Section).all()


@router.get("/{id}", response_model=SectionResponse)
def get_section(id: int, db: Session = Depends(get_db)):
    record = db.query(Section).filter(Section.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Section with id {id} not found")
    return record


@router.put("/{id}", response_model=SectionResponse)
def update_section(id: int, data: SectionUpdate, db: Session = Depends(get_db)):
    record = db.query(Section).filter(Section.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Section with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit()
    db.refresh(record)
    return record


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_section(id: int, db: Session = Depends(get_db)):
    record = db.query(Section).filter(Section.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Section with id {id} not found")
    db.delete(record)
    db.commit()
    return None
