from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Semester
from schemas import SemesterCreate, SemesterUpdate, SemesterResponse

router = APIRouter(prefix="/semesters", tags=["Semesters"])

@router.post("/", response_model=SemesterResponse, status_code=status.HTTP_201_CREATED)
def create_semester(data: SemesterCreate, db: Session = Depends(get_db)):
    new = Semester(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[SemesterResponse])
def get_all_semesters(db: Session = Depends(get_db)):
    return db.query(Semester).all()

@router.get("/{id}", response_model=SemesterResponse)
def get_semester(id: int, db: Session = Depends(get_db)):
    record = db.query(Semester).filter(Semester.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Semester with id {id} not found")
    return record

@router.get("/program/{program_id}", response_model=List[SemesterResponse])
def get_semesters_by_program(program_id: int, db: Session = Depends(get_db)):
    return db.query(Semester).filter(Semester.program_id == program_id).all()

@router.put("/{id}", response_model=SemesterResponse)
def update_semester(id: int, data: SemesterUpdate, db: Session = Depends(get_db)):
    record = db.query(Semester).filter(Semester.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Semester with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_semester(id: int, db: Session = Depends(get_db)):
    record = db.query(Semester).filter(Semester.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Semester with id {id} not found")
    db.delete(record); db.commit()
    return None
