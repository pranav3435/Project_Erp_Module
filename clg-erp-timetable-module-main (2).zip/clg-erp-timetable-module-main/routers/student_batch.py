from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import StudentBatch
from schemas import StudentBatchCreate, StudentBatchResponse

router = APIRouter(prefix="/student-batches", tags=["Student Batch"])

@router.post("/", response_model=StudentBatchResponse, status_code=status.HTTP_201_CREATED)
def assign_student_to_batch(data: StudentBatchCreate, db: Session = Depends(get_db)):
    existing = db.query(StudentBatch).filter(
        StudentBatch.student_id == data.student_id,
        StudentBatch.batch_id == data.batch_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Student already assigned to this batch")
    new = StudentBatch(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[StudentBatchResponse])
def get_all_student_batches(db: Session = Depends(get_db)):
    return db.query(StudentBatch).all()

@router.get("/batch/{batch_id}", response_model=List[StudentBatchResponse])
def get_students_by_batch(batch_id: int, db: Session = Depends(get_db)):
    return db.query(StudentBatch).filter(StudentBatch.batch_id == batch_id).all()

@router.get("/student/{student_id}", response_model=List[StudentBatchResponse])
def get_batches_by_student(student_id: int, db: Session = Depends(get_db)):
    return db.query(StudentBatch).filter(StudentBatch.student_id == student_id).all()

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_student_from_batch(id: int, db: Session = Depends(get_db)):
    record = db.query(StudentBatch).filter(StudentBatch.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Record with id {id} not found")
    db.delete(record); db.commit()
    return None
