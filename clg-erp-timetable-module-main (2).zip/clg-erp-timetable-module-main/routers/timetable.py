from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import Timetable
from schemas import TimetableCreate, TimetableUpdate, TimetableResponse

router = APIRouter(prefix="/timetables", tags=["Timetable"])

@router.post("/", response_model=TimetableResponse, status_code=status.HTTP_201_CREATED)
def create_timetable(data: TimetableCreate, db: Session = Depends(get_db)):
    new = Timetable(**data.model_dump())
    db.add(new); db.commit(); db.refresh(new)
    return new

@router.get("/", response_model=List[TimetableResponse])
def get_all_timetables(db: Session = Depends(get_db)):
    return db.query(Timetable).all()

@router.get("/{id}", response_model=TimetableResponse)
def get_timetable(id: int, db: Session = Depends(get_db)):
    record = db.query(Timetable).filter(Timetable.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Timetable with id {id} not found")
    return record

@router.get("/division/{division_id}", response_model=List[TimetableResponse])
def get_timetable_by_division(division_id: int, db: Session = Depends(get_db)):
    return db.query(Timetable).filter(Timetable.division_id == division_id).all()

@router.get("/faculty/{faculty_id}", response_model=List[TimetableResponse])
def get_timetable_by_faculty(faculty_id: int, db: Session = Depends(get_db)):
    return db.query(Timetable).filter(Timetable.faculty_id == faculty_id).all()

@router.put("/{id}", response_model=TimetableResponse)
def update_timetable(id: int, data: TimetableUpdate, db: Session = Depends(get_db)):
    record = db.query(Timetable).filter(Timetable.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Timetable with id {id} not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)
    db.commit(); db.refresh(record)
    return record

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_timetable(id: int, db: Session = Depends(get_db)):
    record = db.query(Timetable).filter(Timetable.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Timetable with id {id} not found")
    db.delete(record); db.commit()
    return None
