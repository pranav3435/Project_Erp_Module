from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import date, time, datetime


# ============================================================
# ACADEMIC YEAR SCHEMAS
# ============================================================
class AcademicYearBase(BaseModel):
    academic_year: str
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    is_active: Optional[bool] = False

class AcademicYearCreate(AcademicYearBase):
    pass

class AcademicYearUpdate(BaseModel):
    academic_year: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    is_active: Optional[bool] = None

class AcademicYearResponse(AcademicYearBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# DEPARTMENT SCHEMAS
# ============================================================
class DepartmentBase(BaseModel):
    department_name: str
    department_description: Optional[str] = None
    hod_id: Optional[int] = None

class DepartmentCreate(DepartmentBase):
    pass

class DepartmentUpdate(BaseModel):
    department_name: Optional[str] = None
    department_description: Optional[str] = None
    hod_id: Optional[int] = None

class DepartmentResponse(DepartmentBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# SECTION SCHEMAS
# ============================================================
class SectionBase(BaseModel):
    section_name: str
    abbreviation: str

class SectionCreate(SectionBase):
    pass

class SectionUpdate(BaseModel):
    section_name: Optional[str] = None
    abbreviation: Optional[str] = None

class SectionResponse(SectionBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# PROGRAM SCHEMAS
# ============================================================
class ProgramBase(BaseModel):
    program_name: str
    department_id: int
    section_id: Optional[int] = None
    program_duration: int
    program_level: Optional[str] = None
    sanction_intake: Optional[int] = None
    sanction_div: Optional[int] = None

class ProgramCreate(ProgramBase):
    pass

class ProgramUpdate(BaseModel):
    program_name: Optional[str] = None
    department_id: Optional[int] = None
    section_id: Optional[int] = None
    program_duration: Optional[int] = None
    program_level: Optional[str] = None
    sanction_intake: Optional[int] = None
    sanction_div: Optional[int] = None

class ProgramResponse(ProgramBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# CLASS SCHEMAS
# ============================================================
class ClassBase(BaseModel):
    class_name: str
    program_id: int
    department_id: int

class ClassCreate(ClassBase):
    pass

class ClassUpdate(BaseModel):
    class_name: Optional[str] = None
    program_id: Optional[int] = None
    department_id: Optional[int] = None

class ClassResponse(ClassBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# DIVISION SCHEMAS
# ============================================================
class DivisionBase(BaseModel):
    div_name: str
    class_id: int
    program_id: int
    section_id: Optional[int] = None
    department_id: int

class DivisionCreate(DivisionBase):
    pass

class DivisionUpdate(BaseModel):
    div_name: Optional[str] = None
    class_id: Optional[int] = None
    program_id: Optional[int] = None
    section_id: Optional[int] = None
    department_id: Optional[int] = None

class DivisionResponse(DivisionBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# BATCH SCHEMAS
# ============================================================
class BatchBase(BaseModel):
    batch_name: str
    program_id: int
    section_id: Optional[int] = None
    class_id: int
    div_id: int
    department_id: int

class BatchCreate(BatchBase):
    pass

class BatchUpdate(BaseModel):
    batch_name: Optional[str] = None
    program_id: Optional[int] = None
    section_id: Optional[int] = None
    class_id: Optional[int] = None
    div_id: Optional[int] = None
    department_id: Optional[int] = None

class BatchResponse(BatchBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# STUDENT BATCH SCHEMAS
# ============================================================
class StudentBatchBase(BaseModel):
    student_id: int
    batch_id: int

class StudentBatchCreate(StudentBatchBase):
    pass

class StudentBatchResponse(StudentBatchBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# FACULTY SCHEMAS
# ============================================================
class FacultyBase(BaseModel):
    faculty_name: str
    email: str
    designation: Optional[str] = None
    qualification: Optional[str] = None
    mobile_no: Optional[str] = None
    faculty_photo: Optional[str] = None
    faculty_type: Optional[str] = None
    department_id: Optional[int] = None
    time_slot: Optional[str] = None

class FacultyCreate(FacultyBase):
    pass

class FacultyUpdate(BaseModel):
    faculty_name: Optional[str] = None
    email: Optional[str] = None
    designation: Optional[str] = None
    qualification: Optional[str] = None
    mobile_no: Optional[str] = None
    faculty_photo: Optional[str] = None
    faculty_type: Optional[str] = None
    department_id: Optional[int] = None
    time_slot: Optional[str] = None

class FacultyResponse(FacultyBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# COURSE SCHEMAS
# ============================================================
class CourseBase(BaseModel):
    course_name: str
    course_type: Optional[str] = None
    course_credit: Optional[int] = None
    course_hours: Optional[int] = None
    program_id: int
    section_id: Optional[int] = None
    department_id: int

class CourseCreate(CourseBase):
    pass

class CourseUpdate(BaseModel):
    course_name: Optional[str] = None
    course_type: Optional[str] = None
    course_credit: Optional[int] = None
    course_hours: Optional[int] = None
    program_id: Optional[int] = None
    section_id: Optional[int] = None
    department_id: Optional[int] = None

class CourseResponse(CourseBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# SEMESTER SCHEMAS
# ============================================================
class SemesterBase(BaseModel):
    semester_number: str
    program_id: Optional[int] = None
    max_semesters: Optional[int] = None
    academic_year: Optional[str] = None

class SemesterCreate(SemesterBase):
    pass

class SemesterUpdate(BaseModel):
    semester_number: Optional[str] = None
    program_id: Optional[int] = None
    max_semesters: Optional[int] = None
    academic_year: Optional[str] = None

class SemesterResponse(SemesterBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# CLASSROOM SCHEMAS
# ============================================================
class ClassroomBase(BaseModel):
    room_number: str
    building: Optional[str] = None
    capacity: Optional[int] = None
    room_type: Optional[str] = None
    availability_status: Optional[str] = "available"

class ClassroomCreate(ClassroomBase):
    pass

class ClassroomUpdate(BaseModel):
    room_number: Optional[str] = None
    building: Optional[str] = None
    capacity: Optional[int] = None
    room_type: Optional[str] = None
    availability_status: Optional[str] = None

class ClassroomResponse(ClassroomBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# LAB SCHEMAS
# ============================================================
class LabBase(BaseModel):
    lab_number: str
    lab_name: Optional[str] = None
    building: Optional[str] = None
    capacity: Optional[int] = None
    availability_status: Optional[str] = "available"
    day_of_week: Optional[str] = None
    time_slot: Optional[str] = None
    class_id: Optional[int] = None
    batch_id: Optional[int] = None
    course_id: Optional[int] = None
    department_id: Optional[int] = None

class LabCreate(LabBase):
    pass

class LabUpdate(BaseModel):
    lab_number: Optional[str] = None
    lab_name: Optional[str] = None
    building: Optional[str] = None
    capacity: Optional[int] = None
    availability_status: Optional[str] = None
    day_of_week: Optional[str] = None
    time_slot: Optional[str] = None
    class_id: Optional[int] = None
    batch_id: Optional[int] = None
    course_id: Optional[int] = None
    department_id: Optional[int] = None

class LabResponse(LabBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# ACADEMIC CALENDAR SCHEMAS
# ============================================================
class AcademicCalendarBase(BaseModel):
    academic_year: Optional[str] = None
    semester_id: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    day_type: Optional[str] = None
    event_name: Optional[str] = None
    event_type: Optional[str] = None

class AcademicCalendarCreate(AcademicCalendarBase):
    pass

class AcademicCalendarUpdate(BaseModel):
    academic_year: Optional[str] = None
    semester_id: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    day_type: Optional[str] = None
    event_name: Optional[str] = None
    event_type: Optional[str] = None

class AcademicCalendarResponse(AcademicCalendarBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# TIMETABLE SCHEMAS
# ============================================================
class TimetableBase(BaseModel):
    day: str
    start_time: time
    end_time: time
    sub_id: Optional[int] = None
    faculty_id: Optional[int] = None
    classroom_id: Optional[int] = None
    lab_id: Optional[int] = None
    semester_id: Optional[int] = None
    division_id: Optional[int] = None
    academic_year: Optional[str] = None
    batch_id:     Optional[int] = None
    session_type: Optional[str] = "lecture"
    is_break:     Optional[bool] = False

class TimetableCreate(TimetableBase):
    pass

class TimetableUpdate(BaseModel):
    day: Optional[str] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None
    sub_id: Optional[int] = None
    faculty_id: Optional[int] = None
    classroom_id: Optional[int] = None
    lab_id: Optional[int] = None
    semester_id: Optional[int] = None
    division_id: Optional[int] = None
    academic_year: Optional[str] = None
    batch_id:     Optional[int] = None
    session_type: Optional[str] = None
    is_break:     Optional[bool] = None

class TimetableResponse(TimetableBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# FACULTY TIMETABLE SCHEMAS
# ============================================================
class FacultyTimetableBase(BaseModel):
    timetable_id: Optional[int] = None
    faculty_id: Optional[int] = None
    day_of_week: Optional[str] = None
    time_slot: Optional[str] = None
    class_name: Optional[str] = None
    course_id: Optional[int] = None
    session_type: Optional[str] = None
    workload: Optional[int] = None

class FacultyTimetableCreate(FacultyTimetableBase):
    pass

class FacultyTimetableUpdate(BaseModel):
    timetable_id: Optional[int] = None
    faculty_id: Optional[int] = None
    day_of_week: Optional[str] = None
    time_slot: Optional[str] = None
    class_name: Optional[str] = None
    course_id: Optional[int] = None
    session_type: Optional[str] = None
    workload: Optional[int] = None

class FacultyTimetableResponse(FacultyTimetableBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# CLASSROOM OCCUPANCY SCHEMAS
# ============================================================
class ClassroomOccupancyBase(BaseModel):
    day: str
    start_time: time
    end_time: time
    classroom_id: int
    semester_id: Optional[int] = None
    division_id: Optional[int] = None
    academic_year: Optional[str] = None

class ClassroomOccupancyCreate(ClassroomOccupancyBase):
    pass

class ClassroomOccupancyUpdate(BaseModel):
    day: Optional[str] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None
    classroom_id: Optional[int] = None
    semester_id: Optional[int] = None
    division_id: Optional[int] = None
    academic_year: Optional[str] = None

class ClassroomOccupancyResponse(ClassroomOccupancyBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# ============================================================
# LOGS SCHEMAS
# ============================================================
class LogBase(BaseModel):
    user_id: int
    access_date_time: Optional[datetime] = None

class LogCreate(LogBase):
    pass

class LogResponse(LogBase):
    log_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True
        
        
# ProgramFeesBase, ProgramFeesCreate, ProgramFeesUpdate, ProgramFeesResponse
# FeeInstallmentBase, FeeInstallmentCreate, FeeInstallmentUpdate, FeeInstallmentResponse

# ============================================================
# PROGRAM FEES SCHEMAS
# ============================================================
# PROGRAM FEES SCHEMAS
class ProgramFeesBase(BaseModel):
    class_id: int
    academic_year: Optional[str] = None
    total_fees: int
    installments_allowed: Optional[int] = 1

class ProgramFeesCreate(ProgramFeesBase):
    pass

class ProgramFeesUpdate(BaseModel):
    class_id: Optional[int] = None
    academic_year: Optional[str] = None
    total_fees: Optional[int] = None
    installments_allowed: Optional[int] = None

class ProgramFeesResponse(ProgramFeesBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True


# FEE INSTALLMENT SCHEMAS
class FeeInstallmentBase(BaseModel):
    program_fees_id: int
    installment_no: int
    amount: int
    due_date: Optional[date] = None

class FeeInstallmentCreate(FeeInstallmentBase):
    pass

class FeeInstallmentUpdate(BaseModel):
    installment_no: Optional[int] = None
    amount: Optional[int] = None
    due_date: Optional[date] = None

class FeeInstallmentResponse(FeeInstallmentBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True