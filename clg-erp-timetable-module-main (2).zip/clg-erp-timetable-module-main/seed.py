"""
seed.py — Initial data setup for College ERP System
Run: python seed.py
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models

models.Base.metadata.create_all(bind=engine)

def seed():
    db: Session = SessionLocal()
    try:
        print("🌱 Starting seed data insertion...\n")

        # ── 1. ACADEMIC YEARS ────────────────────────────────────
        print("📅 Adding Academic Years...")
        academic_years = [
            models.AcademicYear(academic_year="2024-2025", start_date="2024-06-01", end_date="2025-05-31", is_active=False),
            models.AcademicYear(academic_year="2025-2026", start_date="2025-06-01", end_date="2026-05-31", is_active=True),
        ]
        for ay in academic_years:
            exists = db.query(models.AcademicYear).filter_by(academic_year=ay.academic_year).first()
            if not exists:
                db.add(ay)
        db.commit()
        print("  ✅ Academic Years added\n")

        # ── 2. SECTIONS ──────────────────────────────────────────
        print("📚 Adding Sections...")
        sections = [
            models.Section(section_name="Undergraduate", abbreviation="UG"),
            models.Section(section_name="Postgraduate",  abbreviation="PG"),
        ]
        for s in sections:
            exists = db.query(models.Section).filter_by(section_name=s.section_name).first()
            if not exists:
                db.add(s)
        db.commit()
        print("  ✅ Sections added\n")

        # Fetch section IDs
        ug = db.query(models.Section).filter_by(abbreviation="UG").first()
        pg = db.query(models.Section).filter_by(abbreviation="PG").first()

        # ── 3. DEPARTMENTS (no HOD yet — added after faculty) ────
        print("🏛️  Adding Departments...")
        departments_data = [
            {"department_name": "Computer Science", "department_description": "Covers programming, algorithms, data science, cybersecurity and software development."},
            {"department_name": "Commerce",         "department_description": "Covers accounting, finance, business studies, economics and management."},
            {"department_name": "Animation",        "department_description": "Covers 2D/3D animation, visual effects, digital media and design."},
        ]
        for d in departments_data:
            exists = db.query(models.Department).filter_by(department_name=d["department_name"]).first()
            if not exists:
                db.add(models.Department(**d))
        db.commit()
        print("  ✅ Departments added\n")

        # Fetch department IDs
        cs_dept  = db.query(models.Department).filter_by(department_name="Computer Science").first()
        com_dept = db.query(models.Department).filter_by(department_name="Commerce").first()
        ani_dept = db.query(models.Department).filter_by(department_name="Animation").first()

        # ── 4. FACULTY ───────────────────────────────────────────
        print("👩‍🏫 Adding Faculty...")
        faculty_data = [
            # Computer Science
            {"faculty_name": "Rekha Joshi",        "email": "rekha.joshi@college.edu",        "designation": "Vice Principal",         "qualification": "M.Sc Computer Science, Ph.D", "mobile_no": "9876543201", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Pisal Sir",           "email": "pisal@college.edu",              "designation": "HOD Computer Science",   "qualification": "M.Tech Computer Science",     "mobile_no": "9876543202", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Prashant Deshmukh",   "email": "prashant.deshmukh@college.edu",  "designation": "Placement Coordinator",  "qualification": "MBA, B.E",                    "mobile_no": "9876543203", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Priyanka Kutwad",     "email": "priyanka.kutwad@college.edu",    "designation": "Assistant Professor",    "qualification": "M.Sc Computer Science",       "mobile_no": "9876543204", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Swati Joshi",         "email": "swati.joshi@college.edu",        "designation": "Assistant Professor",    "qualification": "M.Tech",                      "mobile_no": "9876543205", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Jyoti Patil",         "email": "jyoti.patil@college.edu",        "designation": "Lecturer",               "qualification": "M.Sc IT",                     "mobile_no": "9876543206", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Varsharani Dond",     "email": "varsharani.dond@college.edu",    "designation": "Lecturer",               "qualification": "M.Sc Computer Science",       "mobile_no": "9876543207", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Janhavi Baikar",      "email": "janhavi.baikar@college.edu",     "designation": "Assistant Professor",    "qualification": "M.Tech Data Science",         "mobile_no": "9876543208", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Surabhi Dangi",       "email": "surabhi.dangi@college.edu",      "designation": "Lecturer",               "qualification": "M.Sc Cyber Security",         "mobile_no": "9876543209", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Sapna Mulmule",       "email": "sapna.mulmule@college.edu",      "designation": "Assistant Professor",    "qualification": "M.Sc Computer Science",       "mobile_no": "9876543210", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Sapna Malpani",       "email": "sapna.malpani@college.edu",      "designation": "Lecturer",               "qualification": "MCA",                         "mobile_no": "9876543211", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Swapnil Jadhavrao",   "email": "swapnil.jadhavrao@college.edu",  "designation": "Assistant Professor",    "qualification": "M.Tech",                      "mobile_no": "9876543212", "faculty_type": "full-time", "department_id": cs_dept.id},
            {"faculty_name": "Shivaji Godawale",    "email": "shivaji.godawale@college.edu",   "designation": "Lecturer",               "qualification": "M.Sc IT",                     "mobile_no": "9876543213", "faculty_type": "full-time", "department_id": cs_dept.id},
            # Commerce
            {"faculty_name": "Anita Sharma",        "email": "anita.sharma@college.edu",       "designation": "HOD Commerce",           "qualification": "M.Com, Ph.D",                 "mobile_no": "9876543220", "faculty_type": "full-time", "department_id": com_dept.id},
            {"faculty_name": "Suresh Patil",        "email": "suresh.patil@college.edu",       "designation": "Assistant Professor",    "qualification": "M.Com, B.Ed",                 "mobile_no": "9876543221", "faculty_type": "full-time", "department_id": com_dept.id},
            {"faculty_name": "Kavita Nair",         "email": "kavita.nair@college.edu",        "designation": "Assistant Professor",    "qualification": "MBA Finance",                 "mobile_no": "9876543222", "faculty_type": "full-time", "department_id": com_dept.id},
            {"faculty_name": "Ravi Mehta",          "email": "ravi.mehta@college.edu",         "designation": "Lecturer",               "qualification": "M.Com",                       "mobile_no": "9876543223", "faculty_type": "full-time", "department_id": com_dept.id},
            {"faculty_name": "Pooja Kulkarni",      "email": "pooja.kulkarni@college.edu",     "designation": "Lecturer",               "qualification": "M.Com, MBA",                  "mobile_no": "9876543224", "faculty_type": "full-time", "department_id": com_dept.id},
            # Animation
            {"faculty_name": "Anand Rao",           "email": "anand.rao@college.edu",          "designation": "HOD Animation",          "qualification": "M.F.A Animation",             "mobile_no": "9876543230", "faculty_type": "full-time", "department_id": ani_dept.id},
            {"faculty_name": "Deepa Krishnan",      "email": "deepa.krishnan@college.edu",     "designation": "Assistant Professor",    "qualification": "B.Voc Animation",             "mobile_no": "9876543231", "faculty_type": "full-time", "department_id": ani_dept.id},
            {"faculty_name": "Vikram Shetty",       "email": "vikram.shetty@college.edu",      "designation": "Lecturer",               "qualification": "Diploma in 3D Animation",     "mobile_no": "9876543232", "faculty_type": "part-time", "department_id": ani_dept.id},
            {"faculty_name": "Nisha Iyer",          "email": "nisha.iyer@college.edu",         "designation": "Lecturer",               "qualification": "B.Des Visual Arts",           "mobile_no": "9876543233", "faculty_type": "part-time", "department_id": ani_dept.id},
        ]
        for f in faculty_data:
            exists = db.query(models.Faculty).filter_by(email=f["email"]).first()
            if not exists:
                db.add(models.Faculty(**f))
        db.commit()
        print("  ✅ Faculty added\n")

        # Fetch HODs
        pisal       = db.query(models.Faculty).filter_by(email="pisal@college.edu").first()
        anita       = db.query(models.Faculty).filter_by(email="anita.sharma@college.edu").first()
        anand       = db.query(models.Faculty).filter_by(email="anand.rao@college.edu").first()

        # ── 5. SET HODs ON DEPARTMENTS ───────────────────────────
        print("👔 Assigning HODs to Departments...")
        cs_dept.hod_id  = pisal.id
        com_dept.hod_id = anita.id
        ani_dept.hod_id = anand.id
        db.commit()
        print("  ✅ HODs assigned\n")

        # ── 6. PROGRAMS ──────────────────────────────────────────
        print("🎓 Adding Programs...")
        programs_data = [
            # Computer Science UG (3 years) — level 6.0
            {"program_name": "B.Sc. Computer Science",          "department_id": cs_dept.id,  "section_id": ug.id, "program_duration": 3, "program_level": "6.0", "sanction_intake": 60, "sanction_div": 2},
            {"program_name": "B.Sc. Cyber and Digital Science", "department_id": cs_dept.id,  "section_id": ug.id, "program_duration": 3, "program_level": "6.0", "sanction_intake": 60, "sanction_div": 2},
            {"program_name": "B.Sc. Cyber Security",            "department_id": cs_dept.id,  "section_id": ug.id, "program_duration": 3, "program_level": "6.0", "sanction_intake": 60, "sanction_div": 2},
            {"program_name": "B.Sc. Animation",                 "department_id": ani_dept.id, "section_id": ug.id, "program_duration": 3, "program_level": "6.0", "sanction_intake": 40, "sanction_div": 1},
            # Commerce UG (3 years)
            {"program_name": "B.Com",                           "department_id": com_dept.id, "section_id": ug.id, "program_duration": 3, "program_level": "6.0", "sanction_intake": 120,"sanction_div": 4},
            {"program_name": "B.B.A",                           "department_id": com_dept.id, "section_id": ug.id, "program_duration": 3, "program_level": "6.0", "sanction_intake": 60, "sanction_div": 2},
            # Computer Science PG (2 years) — level 7.0
            {"program_name": "M.Sc. Computer Science",          "department_id": cs_dept.id,  "section_id": pg.id, "program_duration": 2, "program_level": "7.0", "sanction_intake": 30, "sanction_div": 1},
            {"program_name": "M.Sc. Computer Application",      "department_id": cs_dept.id,  "section_id": pg.id, "program_duration": 2, "program_level": "7.0", "sanction_intake": 30, "sanction_div": 1},
            {"program_name": "M.Sc. Data Science",              "department_id": cs_dept.id,  "section_id": pg.id, "program_duration": 2, "program_level": "7.0", "sanction_intake": 30, "sanction_div": 1},
            # Commerce PG (2 years)
            {"program_name": "M.Com",                           "department_id": com_dept.id, "section_id": pg.id, "program_duration": 2, "program_level": "7.0", "sanction_intake": 30, "sanction_div": 1},
        ]
        for p in programs_data:
            exists = db.query(models.Program).filter_by(program_name=p["program_name"]).first()
            if not exists:
                db.add(models.Program(**p))
        db.commit()
        print("  ✅ Programs added\n")

        # Fetch programs
        bsc_cs    = db.query(models.Program).filter_by(program_name="B.Sc. Computer Science").first()
        bsc_cyber = db.query(models.Program).filter_by(program_name="B.Sc. Cyber and Digital Science").first()
        bsc_csec  = db.query(models.Program).filter_by(program_name="B.Sc. Cyber Security").first()
        bsc_anim  = db.query(models.Program).filter_by(program_name="B.Sc. Animation").first()
        bcom      = db.query(models.Program).filter_by(program_name="B.Com").first()
        bba       = db.query(models.Program).filter_by(program_name="B.B.A").first()
        msc_cs    = db.query(models.Program).filter_by(program_name="M.Sc. Computer Science").first()
        msc_ca    = db.query(models.Program).filter_by(program_name="M.Sc. Computer Application").first()
        msc_ds    = db.query(models.Program).filter_by(program_name="M.Sc. Data Science").first()
        mcom      = db.query(models.Program).filter_by(program_name="M.Com").first()

        # ── 7. CLASSES ───────────────────────────────────────────
        print("🏫 Adding Classes...")
        classes_data = [
            # B.Sc CS
            {"class_name": "B.Sc. CS - FY",  "program_id": bsc_cs.id,   "department_id": cs_dept.id},
            {"class_name": "B.Sc. CS - SY",  "program_id": bsc_cs.id,   "department_id": cs_dept.id},
            {"class_name": "B.Sc. CS - TY",  "program_id": bsc_cs.id,   "department_id": cs_dept.id},
            # B.Sc Cyber Digital
            {"class_name": "B.Sc. CDS - FY", "program_id": bsc_cyber.id,"department_id": cs_dept.id},
            {"class_name": "B.Sc. CDS - SY", "program_id": bsc_cyber.id,"department_id": cs_dept.id},
            {"class_name": "B.Sc. CDS - TY", "program_id": bsc_cyber.id,"department_id": cs_dept.id},
            # B.Sc Cyber Security
            {"class_name": "B.Sc. CSec - FY","program_id": bsc_csec.id, "department_id": cs_dept.id},
            {"class_name": "B.Sc. CSec - SY","program_id": bsc_csec.id, "department_id": cs_dept.id},
            {"class_name": "B.Sc. CSec - TY","program_id": bsc_csec.id, "department_id": cs_dept.id},
            # B.Sc Animation
            {"class_name": "B.Sc. Anim - FY","program_id": bsc_anim.id, "department_id": ani_dept.id},
            {"class_name": "B.Sc. Anim - SY","program_id": bsc_anim.id, "department_id": ani_dept.id},
            {"class_name": "B.Sc. Anim - TY","program_id": bsc_anim.id, "department_id": ani_dept.id},
            # B.Com
            {"class_name": "B.Com - FY",     "program_id": bcom.id,     "department_id": com_dept.id},
            {"class_name": "B.Com - SY",     "program_id": bcom.id,     "department_id": com_dept.id},
            {"class_name": "B.Com - TY",     "program_id": bcom.id,     "department_id": com_dept.id},
            # BBA
            {"class_name": "B.B.A - FY",     "program_id": bba.id,      "department_id": com_dept.id},
            {"class_name": "B.B.A - SY",     "program_id": bba.id,      "department_id": com_dept.id},
            {"class_name": "B.B.A - TY",     "program_id": bba.id,      "department_id": com_dept.id},
            # M.Sc CS
            {"class_name": "M.Sc. CS - FY",  "program_id": msc_cs.id,   "department_id": cs_dept.id},
            {"class_name": "M.Sc. CS - SY",  "program_id": msc_cs.id,   "department_id": cs_dept.id},
            # M.Sc CA
            {"class_name": "M.Sc. CA - FY",  "program_id": msc_ca.id,   "department_id": cs_dept.id},
            {"class_name": "M.Sc. CA - SY",  "program_id": msc_ca.id,   "department_id": cs_dept.id},
            # M.Sc DS
            {"class_name": "M.Sc. DS - FY",  "program_id": msc_ds.id,   "department_id": cs_dept.id},
            {"class_name": "M.Sc. DS - SY",  "program_id": msc_ds.id,   "department_id": cs_dept.id},
            # M.Com
            {"class_name": "M.Com - FY",     "program_id": mcom.id,     "department_id": com_dept.id},
            {"class_name": "M.Com - SY",     "program_id": mcom.id,     "department_id": com_dept.id},
        ]
        for c in classes_data:
            exists = db.query(models.Class).filter_by(class_name=c["class_name"]).first()
            if not exists:
                db.add(models.Class(**c))
        db.commit()
        print("  ✅ Classes added\n")

        # ── 8. DIVISIONS ─────────────────────────────────────────
        print("🔀 Adding Divisions...")
        # For each class, add divisions based on sanction_div
        all_classes = db.query(models.Class).all()
        programs_map = {p.id: p for p in db.query(models.Program).all()}
        for cls in all_classes:
            program = programs_map.get(cls.program_id)
            num_divs = program.sanction_div if program and program.sanction_div else 1
            div_names = ["A", "B", "C", "D"][:num_divs]
            for div_name in div_names:
                exists = db.query(models.Division).filter_by(
                    div_name=div_name, class_id=cls.id
                ).first()
                if not exists:
                    db.add(models.Division(
                        div_name=div_name,
                        class_id=cls.id,
                        program_id=cls.program_id,
                        section_id=program.section_id,
                        department_id=cls.department_id,
                    ))
        db.commit()
        print("  ✅ Divisions added\n")

        # ── 9. CLASSROOMS ────────────────────────────────────────
        print("🚪 Adding Classrooms...")
        classrooms_data = (
            # Old building rooms 1-6
            [{"room_number": str(i), "building": "Old Building", "capacity": 60, "room_type": "lecture", "availability_status": "available"} for i in range(1, 7)]
            +
            # New building rooms 101-404
            [
                {"room_number": f"{floor}{room:02d}", "building": "New Building",
                 "capacity": 60, "room_type": "lecture", "availability_status": "available"}
                for floor in range(1, 5)
                for room in range(1, 5)
            ]
        )
        for cr in classrooms_data:
            exists = db.query(models.Classroom).filter_by(room_number=cr["room_number"]).first()
            if not exists:
                db.add(models.Classroom(**cr))
        db.commit()
        print("  ✅ Classrooms added\n")

        # ── 10. LABS ─────────────────────────────────────────────
        print("🔬 Adding Labs...")
        labs_data = [
            {"lab_number": "CS-LAB-1", "lab_name": "Programming Lab 1",    "building": "New Building", "capacity": 40, "availability_status": "available"},
            {"lab_number": "CS-LAB-2", "lab_name": "Programming Lab 2",    "building": "New Building", "capacity": 40, "availability_status": "available"},
            {"lab_number": "CS-LAB-3", "lab_name": "Networking Lab",       "building": "New Building", "capacity": 30, "availability_status": "available"},
            {"lab_number": "CS-LAB-4", "lab_name": "Data Science Lab",     "building": "New Building", "capacity": 30, "availability_status": "available"},
            {"lab_number": "CS-LAB-5", "lab_name": "Cyber Security Lab",   "building": "New Building", "capacity": 30, "availability_status": "available"},
            {"lab_number": "AN-LAB-1", "lab_name": "3D Animation Lab",     "building": "New Building", "capacity": 30, "availability_status": "available"},
            {"lab_number": "AN-LAB-2", "lab_name": "VFX and Editing Lab",  "building": "New Building", "capacity": 20, "availability_status": "available"},
            {"lab_number": "COM-LAB-1","lab_name": "Commerce Computer Lab","building": "Old Building", "capacity": 40, "availability_status": "available"},
        ]
        for lab in labs_data:
            exists = db.query(models.Lab).filter_by(lab_number=lab["lab_number"]).first()
            if not exists:
                db.add(models.Lab(**lab))
        db.commit()
        print("  ✅ Labs added\n")

        # ── 11. SEMESTERS ────────────────────────────────────────
        print("📆 Adding Semesters...")
        roman = ["I","II","III","IV","V","VI","VII","VIII"]
        all_programs = db.query(models.Program).all()
        for prog in all_programs:
            # UG = 6 semesters, PG = 4 semesters
            max_sem = 6 if prog.section_id == ug.id else 4
            for i in range(max_sem):
                exists = db.query(models.Semester).filter_by(
                    semester_number=roman[i], program_id=prog.id
                ).first()
                if not exists:
                    db.add(models.Semester(
                        semester_number=roman[i],
                        program_id=prog.id,
                        max_semesters=max_sem,
                        academic_year="2025-2026"
                    ))
        db.commit()
        print("  ✅ Semesters added\n")

        # ── 12. ACADEMIC CALENDAR ────────────────────────────────
        print("📅 Adding Academic Calendar Events...")
        sem1 = db.query(models.Semester).filter_by(semester_number="I", program_id=bsc_cs.id).first()
        sem2 = db.query(models.Semester).filter_by(semester_number="II", program_id=bsc_cs.id).first()
        calendar_data = [
            {"academic_year": "2025-2026", "semester_id": sem1.id if sem1 else None, "start_date": "2025-06-16", "end_date": "2025-06-16", "day_type": "working",  "event_name": "Odd Semester Begins",     "event_type": "activity"},
            {"academic_year": "2025-2026", "semester_id": sem1.id if sem1 else None, "start_date": "2025-08-15", "end_date": "2025-08-15", "day_type": "holiday",  "event_name": "Independence Day",        "event_type": "holiday"},
            {"academic_year": "2025-2026", "semester_id": sem1.id if sem1 else None, "start_date": "2025-10-02", "end_date": "2025-10-02", "day_type": "holiday",  "event_name": "Gandhi Jayanti",          "event_type": "holiday"},
            {"academic_year": "2025-2026", "semester_id": sem1.id if sem1 else None, "start_date": "2025-10-20", "end_date": "2025-10-31", "day_type": "exam",     "event_name": "Internal Assessment I",   "event_type": "exam"},
            {"academic_year": "2025-2026", "semester_id": sem1.id if sem1 else None, "start_date": "2025-11-17", "end_date": "2025-11-28", "day_type": "exam",     "event_name": "End Semester Exams (Odd)","event_type": "exam"},
            {"academic_year": "2025-2026", "semester_id": sem2.id if sem2 else None, "start_date": "2026-01-05", "end_date": "2026-01-05", "day_type": "working",  "event_name": "Even Semester Begins",    "event_type": "activity"},
            {"academic_year": "2025-2026", "semester_id": sem2.id if sem2 else None, "start_date": "2026-01-26", "end_date": "2026-01-26", "day_type": "holiday",  "event_name": "Republic Day",            "event_type": "holiday"},
            {"academic_year": "2025-2026", "semester_id": sem2.id if sem2 else None, "start_date": "2026-03-10", "end_date": "2026-03-20", "day_type": "exam",     "event_name": "Internal Assessment II",  "event_type": "exam"},
            {"academic_year": "2025-2026", "semester_id": sem2.id if sem2 else None, "start_date": "2026-04-20", "end_date": "2026-05-05", "day_type": "exam",     "event_name": "End Semester Exams (Even)","event_type": "exam"},
            {"academic_year": "2025-2026", "semester_id": sem2.id if sem2 else None, "start_date": "2026-05-10", "end_date": "2026-05-31", "day_type": "holiday",  "event_name": "Summer Vacation",         "event_type": "holiday"},
        ]
        for event in calendar_data:
            exists = db.query(models.AcademicCalendar).filter_by(
                event_name=event["event_name"], academic_year=event["academic_year"]
            ).first()
            if not exists:
                db.add(models.AcademicCalendar(**event))
        db.commit()
        print("  ✅ Academic Calendar added\n")

        print("=" * 50)
        print("🎉 ALL SEED DATA INSERTED SUCCESSFULLY!")
        print("=" * 50)
        print(f"\n📊 Summary:")
        print(f"  Academic Years : {db.query(models.AcademicYear).count()}")
        print(f"  Sections       : {db.query(models.Section).count()}")
        print(f"  Departments    : {db.query(models.Department).count()}")
        print(f"  Faculty        : {db.query(models.Faculty).count()}")
        print(f"  Programs       : {db.query(models.Program).count()}")
        print(f"  Classes        : {db.query(models.Class).count()}")
        print(f"  Divisions      : {db.query(models.Division).count()}")
        print(f"  Classrooms     : {db.query(models.Classroom).count()}")
        print(f"  Labs           : {db.query(models.Lab).count()}")
        print(f"  Semesters      : {db.query(models.Semester).count()}")
        print(f"  Calendar Events: {db.query(models.AcademicCalendar).count()}")
        print(f"  Program Fees   : {db.query(models.ProgramFees).count()}")
        print(f"  Installments   : {db.query(models.FeeInstallment).count()}")
        
    
    
    
    # ── 13. PROGRAM FEES + INSTALLMENTS (Class-wise) ─────────
        print("💰 Adding Class-wise Fees and Installments...")

        # Format: (class_name, total_fees, installments, [amounts], [due_dates])
        fees_data = [
            # ── B.Sc. Computer Science ──────────────────────────
            ("B.Sc. CS - FY",  45000, 3, [15000, 15000, 15000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. CS - SY",  46000, 3, [16000, 15000, 15000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. CS - TY",  48000, 3, [16000, 16000, 16000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── B.Sc. Cyber and Digital Science ─────────────────
            ("B.Sc. CDS - FY", 47000, 3, [16000, 16000, 15000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. CDS - SY", 48000, 3, [16000, 16000, 16000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. CDS - TY", 50000, 3, [17000, 17000, 16000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── B.Sc. Cyber Security ─────────────────────────────
            ("B.Sc. CSec - FY",47000, 3, [16000, 16000, 15000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. CSec - SY",48000, 3, [16000, 16000, 16000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. CSec - TY",50000, 3, [17000, 17000, 16000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── B.Sc. Animation ──────────────────────────────────
            ("B.Sc. Anim - FY",50000, 3, [18000, 16000, 16000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. Anim - SY",52000, 3, [18000, 17000, 17000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("B.Sc. Anim - TY",55000, 3, [19000, 18000, 18000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── B.Com ────────────────────────────────────────────
            ("B.Com - FY",     25000, 2, [13000, 12000],         ["2025-07-01", "2025-11-01"]),
            ("B.Com - SY",     26000, 2, [13000, 13000],         ["2025-07-01", "2025-11-01"]),
            ("B.Com - TY",     27000, 2, [14000, 13000],         ["2025-07-01", "2025-11-01"]),
            # ── B.B.A ────────────────────────────────────────────
            ("B.B.A - FY",     35000, 2, [18000, 17000],         ["2025-07-01", "2025-11-01"]),
            ("B.B.A - SY",     36000, 2, [18000, 18000],         ["2025-07-01", "2025-11-01"]),
            ("B.B.A - TY",     38000, 2, [19000, 19000],         ["2025-07-01", "2025-11-01"]),
            # ── M.Sc. Computer Science ───────────────────────────
            ("M.Sc. CS - FY",  55000, 3, [19000, 18000, 18000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("M.Sc. CS - SY",  57000, 3, [20000, 19000, 18000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── M.Sc. Computer Application ───────────────────────
            ("M.Sc. CA - FY",  55000, 3, [19000, 18000, 18000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("M.Sc. CA - SY",  57000, 3, [20000, 19000, 18000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── M.Sc. Data Science ───────────────────────────────
            ("M.Sc. DS - FY",  60000, 3, [21000, 20000, 19000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            ("M.Sc. DS - SY",  62000, 3, [22000, 21000, 19000], ["2025-07-01", "2025-10-01", "2026-01-01"]),
            # ── M.Com ────────────────────────────────────────────
            ("M.Com - FY",     30000, 2, [16000, 14000],         ["2025-07-01", "2025-11-01"]),
            ("M.Com - SY",     32000, 2, [17000, 15000],         ["2025-07-01", "2025-11-01"]),
        ]

        for class_name, total, installments, amounts, due_dates in fees_data:
            cls = db.query(models.Class).filter_by(class_name=class_name).first()
            if not cls:
                print(f"  ⚠️  Class not found: {class_name}")
                continue

            exists = db.query(models.ProgramFees).filter_by(
                class_id=cls.id, academic_year="2025-2026"
            ).first()

            if not exists:
                fees = models.ProgramFees(
                    class_id=cls.id,
                    academic_year="2025-2026",
                    total_fees=total,
                    installments_allowed=installments
                )
                db.add(fees)
                db.commit()
                db.refresh(fees)

                for i, (amount, due_date) in enumerate(zip(amounts, due_dates), 1):
                    db.add(models.FeeInstallment(
                        program_fees_id=fees.id,
                        installment_no=i,
                        amount=amount,
                        due_date=due_date
                    ))
                db.commit()

        print("  ✅ Class-wise Fees and Installments added\n")


    except Exception as e:
        db.rollback()
        print(f"\n❌ Error: {e}")
        raise e
    finally:
        db.close()


if __name__ == "__main__":
    seed()
    
    
    