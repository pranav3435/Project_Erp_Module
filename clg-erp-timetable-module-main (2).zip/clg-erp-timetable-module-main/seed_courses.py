"""
seed_courses.py — Adds courses/subjects for all programs and semesters
Based on: SPPU (Savitribai Phule Pune University) NEP 2024 syllabus
Run AFTER seed.py: python seed_courses.py
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models

def add_course(db, course_code, course_name, course_type, credits, hours, program_name, section_abbr, dept_name):
    program = db.query(models.Program).filter_by(program_name=program_name).first()
    section = db.query(models.Section).filter_by(abbreviation=section_abbr).first()
    dept    = db.query(models.Department).filter_by(department_name=dept_name).first()

    if not program or not section or not dept:
        print(f"  ⚠️  Skipping {course_code} — program/section/dept not found")
        return

    exists = db.query(models.Course).filter_by(course_name=course_name, program_id=program.id).first()
    if not exists:
        db.add(models.Course(
            course_name=course_name,
            course_type=course_type,
            course_credit=credits,
            course_hours=hours,
            program_id=program.id,
            section_id=section.id,
            department_id=dept.id,
        ))

def seed_courses():
    db: Session = SessionLocal()
    try:
        print("📚 Starting Course Seed Data...\n")

        # ════════════════════════════════════════════════════════
        # B.Sc. COMPUTER SCIENCE — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("🖥️  Adding B.Sc. Computer Science courses...")

        bsc_cs_courses = [
            # ── SEMESTER I ──────────────────────────────────────
            ("CS-101-T",  "Problem Solving Using C Programming",         "theory",    2, 2),
            ("CS-102-P",  "Lab: Problem Solving Using C Programming",    "practical", 2, 4),
            ("CS-103-T",  "Database Management Systems I",               "theory",    2, 2),
            ("CS-104-P",  "Lab: Database Management Systems I",          "practical", 2, 4),
            ("MTS-101-T", "Mathematics I",                               "theory",    2, 2),
            ("MTS-102-P", "Lab: Mathematics I",                          "practical", 2, 4),
            ("ELS-101-T", "Electronic Science I",                        "theory",    2, 2),
            ("ELS-102-P", "Lab: Electronic Science I",                   "practical", 2, 4),
            ("IKS-100-T", "Indian Knowledge System (Generic IKS)",       "theory",    2, 2),
            ("OE-101-CS", "Office Automation I",                         "elective",  2, 2),
            ("SEC-101-CS","Statistical Methods for Computer Science I",  "theory",    2, 4),
            ("AEC-101",   "Modern Indian Language I (Hindi/Marathi)",    "theory",    2, 2),
            ("VEC-101",   "Environmental Studies I",                     "theory",    2, 2),
            # ── SEMESTER II ─────────────────────────────────────
            ("CS-151-T",  "Advanced C Programming",                      "theory",    2, 2),
            ("CS-152-P",  "Lab: Advanced C Programming",                 "practical", 2, 4),
            ("CS-153-T",  "Database Management Systems II",              "theory",    2, 2),
            ("CS-154-P",  "Lab: Database Management Systems II",         "practical", 2, 4),
            ("MTS-151-T", "Mathematics II",                              "theory",    2, 2),
            ("MTS-152-P", "Lab: Mathematics II",                         "practical", 2, 4),
            ("ELS-151-T", "Electronic Science II",                       "theory",    2, 2),
            ("ELS-152-P", "Lab: Electronic Science II",                  "practical", 2, 4),
            ("OE-151-CS", "Computer Fundamentals and Internet",          "elective",  2, 2),
            ("SEC-151-CS","Statistical Methods for Computer Science II", "theory",    2, 4),
            ("AEC-151",   "Modern Indian Language II (Hindi/Marathi)",   "theory",    2, 2),
            ("VEC-151",   "Environmental Studies II",                    "theory",    2, 2),
            ("CC-151",    "Co-Curricular Course (NSS/NCC/Sports)",       "elective",  2, 2),
            # ── SEMESTER III ────────────────────────────────────
            ("CS-231-T",  "Data Structures",                             "theory",    3, 3),
            ("CS-232-P",  "Lab: Data Structures",                        "practical", 2, 4),
            ("CS-233-T",  "Object Oriented Programming Using C++",       "theory",    3, 3),
            ("CS-234-P",  "Lab: Object Oriented Programming C++",        "practical", 2, 4),
            ("CS-235-T",  "Software Engineering",                        "theory",    2, 2),
            ("MTS-231-T", "Mathematics III",                             "theory",    2, 2),
            ("ELS-231-T", "Electronic Science III",                      "theory",    2, 2),
            ("OE-231-CS", "Introduction to Python Programming",          "elective",  2, 2),
            ("SEC-231-CS","Web Designing using HTML and CSS",            "theory",    2, 4),
            ("AEC-231",   "Communication Skills in English I",           "theory",    2, 2),
            # ── SEMESTER IV ─────────────────────────────────────
            ("CS-241-T",  "Python Programming",                          "theory",    3, 3),
            ("CS-242-P",  "Lab: Python Programming",                     "practical", 2, 4),
            ("CS-243-T",  "Computer Networks",                           "theory",    3, 3),
            ("CS-244-P",  "Lab: Computer Networks",                      "practical", 2, 4),
            ("CS-245-T",  "Operating Systems",                           "theory",    3, 3),
            ("MTS-241-T", "Mathematics IV",                              "theory",    2, 2),
            ("ELS-241-T", "Electronic Science IV",                       "theory",    2, 2),
            ("OE-241-CS", "JavaScript Programming",                      "elective",  2, 2),
            ("SEC-241-CS","Linux Administration",                        "theory",    2, 4),
            ("AEC-241",   "Communication Skills in English II",          "theory",    2, 2),
            ("FP-241",    "Field Project / On Job Training I",           "practical", 4, 8),
            # ── SEMESTER V ──────────────────────────────────────
            ("CS-331-T",  "System Software and Operating Systems",       "theory",    3, 3),
            ("CS-332-T",  "Theory of Computation",                       "theory",    3, 3),
            ("CS-333-T",  "Computer Networks and Security",              "theory",    3, 3),
            ("CS-334-T",  "Web Technology (PHP and MySQL)",              "theory",    3, 3),
            ("CS-335-P",  "Lab: Web Technology",                         "practical", 2, 4),
            ("CS-336-T",  "Software Project Management",                 "theory",    2, 2),
            ("ME-331-CS", "Major Elective: Machine Learning",            "elective",  3, 3),
            ("ME-332-CS", "Major Elective: Mobile Application Development","elective",3, 3),
            ("ME-333-CS", "Major Elective: Cloud Computing",             "elective",  3, 3),
            ("SEC-331-CS","Cyber Security Fundamentals",                 "theory",    2, 4),
            # ── SEMESTER VI ─────────────────────────────────────
            ("CS-341-T",  "Design and Analysis of Algorithms",           "theory",    3, 3),
            ("CS-342-T",  "Artificial Intelligence",                     "theory",    3, 3),
            ("CS-343-T",  "Network Security and Cryptography",           "theory",    3, 3),
            ("CS-344-T",  "Software Testing and Quality Assurance",      "theory",    2, 2),
            ("CS-345-P",  "Lab: Artificial Intelligence",                "practical", 2, 4),
            ("CS-346-P",  "Project Work",                                "practical", 4, 8),
            ("ME-341-CS", "Major Elective: Data Science",                "elective",  3, 3),
            ("ME-342-CS", "Major Elective: Internet of Things (IoT)",    "elective",  3, 3),
            ("ME-343-CS", "Major Elective: Blockchain Technology",       "elective",  3, 3),
            ("FP-341",    "Field Project / On Job Training II",          "practical", 4, 8),
        ]

        for code, name, ctype, credits, hours in bsc_cs_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "B.Sc. Computer Science", "UG", "Computer Science")
        db.commit()
        print("  ✅ B.Sc. Computer Science courses added\n")

        # ════════════════════════════════════════════════════════
        # B.Sc. CYBER AND DIGITAL SCIENCE — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("🔐 Adding B.Sc. Cyber and Digital Science courses...")

        bsc_cds_courses = [
            # Sem I
            ("CDS-101-T", "Fundamentals of Computing and Programming",   "theory",    2, 2),
            ("CDS-102-P", "Lab: Fundamentals of Computing",              "practical", 2, 4),
            ("CDS-103-T", "Digital Electronics",                         "theory",    2, 2),
            ("CDS-104-P", "Lab: Digital Electronics",                    "practical", 2, 4),
            ("CDS-105-T", "Mathematics for Cyber Science I",             "theory",    2, 2),
            ("IKS-100-T", "Indian Knowledge System",                     "theory",    2, 2),
            ("OE-101-CDS","Office Automation I",                         "elective",  2, 2),
            ("AEC-101-CDS","Modern Indian Language I",                   "theory",    2, 2),
            ("VEC-101-CDS","Environmental Studies I",                    "theory",    2, 2),
            # Sem II
            ("CDS-151-T", "Python Programming for Cyber Science",        "theory",    2, 2),
            ("CDS-152-P", "Lab: Python Programming",                     "practical", 2, 4),
            ("CDS-153-T", "Computer Networks Fundamentals",              "theory",    2, 2),
            ("CDS-154-P", "Lab: Computer Networks",                      "practical", 2, 4),
            ("CDS-155-T", "Mathematics for Cyber Science II",            "theory",    2, 2),
            ("OE-151-CDS","Internet and Web Fundamentals",               "elective",  2, 2),
            ("AEC-151-CDS","Modern Indian Language II",                  "theory",    2, 2),
            ("VEC-151-CDS","Environmental Studies II",                   "theory",    2, 2),
            # Sem III
            ("CDS-231-T", "Network Security",                            "theory",    3, 3),
            ("CDS-232-P", "Lab: Network Security",                       "practical", 2, 4),
            ("CDS-233-T", "Operating System Security",                   "theory",    3, 3),
            ("CDS-234-T", "Database Security",                           "theory",    3, 3),
            ("CDS-235-T", "Ethical Hacking Fundamentals",                "theory",    2, 2),
            ("OE-231-CDS","Scripting for Security",                      "elective",  2, 2),
            # Sem IV
            ("CDS-241-T", "Advanced Network Security",                   "theory",    3, 3),
            ("CDS-242-P", "Lab: Advanced Network Security",              "practical", 2, 4),
            ("CDS-243-T", "Web Application Security",                    "theory",    3, 3),
            ("CDS-244-T", "Digital Forensics",                           "theory",    3, 3),
            ("CDS-245-T", "Cryptography and Data Protection",            "theory",    3, 3),
            ("FP-241-CDS","Field Project / Internship I",                "practical", 4, 8),
            # Sem V
            ("CDS-331-T", "Penetration Testing",                         "theory",    3, 3),
            ("CDS-332-P", "Lab: Penetration Testing",                    "practical", 2, 4),
            ("CDS-333-T", "Malware Analysis",                            "theory",    3, 3),
            ("CDS-334-T", "Cloud Security",                              "theory",    3, 3),
            ("CDS-335-T", "Cyber Laws and Ethics",                       "theory",    2, 2),
            ("ME-331-CDS","Major Elective: IoT Security",                "elective",  3, 3),
            ("ME-332-CDS","Major Elective: AI in Cybersecurity",         "elective",  3, 3),
            # Sem VI
            ("CDS-341-T", "Advanced Cryptography",                       "theory",    3, 3),
            ("CDS-342-T", "Incident Response and Management",            "theory",    3, 3),
            ("CDS-343-T", "Blockchain for Security",                     "theory",    3, 3),
            ("CDS-344-P", "Lab: Incident Response",                      "practical", 2, 4),
            ("CDS-345-P", "Project Work",                                "practical", 4, 8),
            ("ME-341-CDS","Major Elective: Zero Trust Architecture",     "elective",  3, 3),
            ("FP-341-CDS","Field Project / Internship II",               "practical", 4, 8),
        ]
        for code, name, ctype, credits, hours in bsc_cds_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "B.Sc. Cyber and Digital Science", "UG", "Computer Science")
        db.commit()
        print("  ✅ B.Sc. Cyber and Digital Science courses added\n")

        # ════════════════════════════════════════════════════════
        # B.Sc. CYBER SECURITY — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("🔒 Adding B.Sc. Cyber Security courses...")

        bsc_csec_courses = [
            # Sem I
            ("CSEC-101-T","Introduction to Cyber Security",              "theory",    2, 2),
            ("CSEC-102-P","Lab: Introduction to Cyber Security",         "practical", 2, 4),
            ("CSEC-103-T","Fundamentals of Networking",                  "theory",    2, 2),
            ("CSEC-104-P","Lab: Networking Fundamentals",                "practical", 2, 4),
            ("CSEC-105-T","Programming for Security using Python",       "theory",    2, 2),
            ("IKS-100-CS2","Indian Knowledge System",                    "theory",    2, 2),
            ("VEC-101-CS2","Environmental Studies I",                    "theory",    2, 2),
            # Sem II
            ("CSEC-151-T","System Security",                             "theory",    2, 2),
            ("CSEC-152-P","Lab: System Security",                        "practical", 2, 4),
            ("CSEC-153-T","Cryptography Basics",                         "theory",    2, 2),
            ("CSEC-154-T","Security Protocols",                          "theory",    2, 2),
            ("VEC-151-CS2","Environmental Studies II",                   "theory",    2, 2),
            ("CC-151-CS2","Co-Curricular Course",                        "elective",  2, 2),
            # Sem III
            ("CSEC-231-T","Network Security and Firewalls",              "theory",    3, 3),
            ("CSEC-232-P","Lab: Network Security",                       "practical", 2, 4),
            ("CSEC-233-T","Ethical Hacking",                             "theory",    3, 3),
            ("CSEC-234-T","Application Security",                        "theory",    3, 3),
            ("CSEC-235-T","Security Audit and Compliance",               "theory",    2, 2),
            # Sem IV
            ("CSEC-241-T","Digital Forensics and Investigation",         "theory",    3, 3),
            ("CSEC-242-P","Lab: Digital Forensics",                      "practical", 2, 4),
            ("CSEC-243-T","Malware Analysis and Reverse Engineering",    "theory",    3, 3),
            ("CSEC-244-T","Cloud Security and Privacy",                  "theory",    3, 3),
            ("CSEC-245-T","Cyber Laws, Ethics and Policy",               "theory",    2, 2),
            ("FP-241-CS2","Internship / Field Project I",                "practical", 4, 8),
            # Sem V
            ("CSEC-331-T","Advanced Penetration Testing",                "theory",    3, 3),
            ("CSEC-332-P","Lab: Penetration Testing",                    "practical", 2, 4),
            ("CSEC-333-T","Security Information and Event Management",   "theory",    3, 3),
            ("CSEC-334-T","IoT Security",                                "theory",    3, 3),
            ("ME-331-CS2","Major Elective: Blockchain Security",         "elective",  3, 3),
            ("ME-332-CS2","Major Elective: AI and ML for Security",      "elective",  3, 3),
            # Sem VI
            ("CSEC-341-T","Incident Handling and Response",              "theory",    3, 3),
            ("CSEC-342-T","Vulnerability Assessment",                    "theory",    3, 3),
            ("CSEC-343-P","Lab: Vulnerability Assessment",               "practical", 2, 4),
            ("CSEC-344-P","Final Project: Security Implementation",      "practical", 4, 8),
            ("ME-341-CS2","Major Elective: Zero Trust Security",         "elective",  3, 3),
            ("FP-341-CS2","Internship / Field Project II",               "practical", 4, 8),
        ]
        for code, name, ctype, credits, hours in bsc_csec_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "B.Sc. Cyber Security", "UG", "Computer Science")
        db.commit()
        print("  ✅ B.Sc. Cyber Security courses added\n")

        # ════════════════════════════════════════════════════════
        # B.Sc. ANIMATION — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("🎨 Adding B.Sc. Animation courses...")

        bsc_anim_courses = [
            # Sem I
            ("ANIM-101-T","Introduction to Animation and Visual Arts",   "theory",    2, 2),
            ("ANIM-102-P","Lab: Drawing and Sketching Fundamentals",     "practical", 2, 4),
            ("ANIM-103-T","Principles of Design and Color Theory",       "theory",    2, 2),
            ("ANIM-104-P","Lab: Design and Color",                       "practical", 2, 4),
            ("ANIM-105-T","History of Animation and Film",               "theory",    2, 2),
            ("IKS-100-AN","Indian Knowledge System",                     "theory",    2, 2),
            ("VEC-101-AN","Environmental Studies I",                     "theory",    2, 2),
            # Sem II
            ("ANIM-151-T","2D Animation Fundamentals",                   "theory",    2, 2),
            ("ANIM-152-P","Lab: 2D Animation",                           "practical", 4, 8),
            ("ANIM-153-T","Storyboarding and Script Writing",            "theory",    2, 2),
            ("ANIM-154-P","Lab: Storyboarding",                          "practical", 2, 4),
            ("ANIM-155-T","Typography and Graphic Design",               "theory",    2, 2),
            ("VEC-151-AN","Environmental Studies II",                    "theory",    2, 2),
            # Sem III
            ("ANIM-231-T","3D Modeling Fundamentals using Blender",      "theory",    3, 3),
            ("ANIM-232-P","Lab: 3D Modeling",                            "practical", 4, 8),
            ("ANIM-233-T","Character Design and Development",            "theory",    3, 3),
            ("ANIM-234-P","Lab: Character Design",                       "practical", 2, 4),
            ("ANIM-235-T","Digital Photography and Cinematography",      "theory",    2, 2),
            ("OE-231-AN", "Introduction to Video Editing",               "elective",  2, 2),
            # Sem IV
            ("ANIM-241-T","3D Animation and Rigging",                    "theory",    3, 3),
            ("ANIM-242-P","Lab: 3D Animation",                           "practical", 4, 8),
            ("ANIM-243-T","Visual Effects (VFX) Fundamentals",           "theory",    3, 3),
            ("ANIM-244-P","Lab: Visual Effects",                         "practical", 4, 8),
            ("ANIM-245-T","Motion Graphics",                             "theory",    2, 2),
            ("FP-241-AN", "Field Project / Internship I",                "practical", 4, 8),
            # Sem V
            ("ANIM-331-T","Advanced 3D Animation Techniques",            "theory",    3, 3),
            ("ANIM-332-P","Lab: Advanced 3D Animation",                  "practical", 4, 8),
            ("ANIM-333-T","Compositing and Post Production",             "theory",    3, 3),
            ("ANIM-334-P","Lab: Compositing",                            "practical", 4, 8),
            ("ANIM-335-T","Game Design Fundamentals",                    "theory",    2, 2),
            ("ME-331-AN", "Major Elective: AR and VR Fundamentals",      "elective",  3, 3),
            ("ME-332-AN", "Major Elective: Film Production",             "elective",  3, 3),
            # Sem VI
            ("ANIM-341-T","Animation for Games",                         "theory",    3, 3),
            ("ANIM-342-P","Lab: Animation for Games",                    "practical", 4, 8),
            ("ANIM-343-T","Portfolio Development and Industry Practices","theory",    2, 2),
            ("ANIM-344-P","Final Animation Project",                     "practical", 6, 12),
            ("ME-341-AN", "Major Elective: Advanced VFX",                "elective",  3, 3),
            ("FP-341-AN", "Internship / Field Project II",               "practical", 4, 8),
        ]
        for code, name, ctype, credits, hours in bsc_anim_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "B.Sc. Animation", "UG", "Animation")
        db.commit()
        print("  ✅ B.Sc. Animation courses added\n")

        # ════════════════════════════════════════════════════════
        # B.COM — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("💼 Adding B.Com courses...")

        bcom_courses = [
            # Sem I
            ("BCO-101-T", "Financial Accounting I",                      "theory",    4, 5),
            ("BCO-102-T", "Business Economics I (Micro)",                "theory",    4, 5),
            ("BCO-103-T", "Principles of Management",                    "theory",    4, 5),
            ("BCO-104-T", "Business Mathematics and Statistics I",       "theory",    2, 2),
            ("BCO-105-T", "Business Communication Skills I",             "theory",    2, 2),
            ("BCO-106-T", "Environmental Awareness",                     "theory",    2, 2),
            ("OE-101-BCO","Introduction to Computers",                   "elective",  2, 2),
            ("IKS-100-BCO","Indian Knowledge System",                    "theory",    2, 2),
            # Sem II
            ("BCO-151-T", "Financial Accounting II",                     "theory",    4, 5),
            ("BCO-152-T", "Business Economics II (Macro)",               "theory",    4, 5),
            ("BCO-153-T", "Principles of Marketing",                     "theory",    4, 5),
            ("BCO-154-T", "Business Mathematics and Statistics II",      "theory",    2, 2),
            ("BCO-155-T", "Business Communication Skills II",            "theory",    2, 2),
            ("BCO-156-T", "Principles of Finance",                       "theory",    2, 2),
            ("OE-151-BCO","E-Commerce Fundamentals",                     "elective",  2, 2),
            ("CC-151-BCO","Co-Curricular Course (NSS/NCC/Sports)",       "elective",  2, 2),
            # Sem III
            ("BCO-231-T", "Corporate Accounting I",                      "theory",    4, 5),
            ("BCO-232-T", "Cost Accounting I",                           "theory",    4, 5),
            ("BCO-233-T", "Business Law I",                              "theory",    4, 5),
            ("BCO-234-T", "Principles of Human Resource Management",     "theory",    4, 5),
            ("BCO-235-T", "Business Research Methods",                   "theory",    2, 2),
            ("OE-231-BCO","Tally and Accounting Software",               "elective",  2, 4),
            # Sem IV
            ("BCO-241-T", "Corporate Accounting II",                     "theory",    4, 5),
            ("BCO-242-T", "Cost Accounting II",                          "theory",    4, 5),
            ("BCO-243-T", "Business Law II (Company Law)",               "theory",    4, 5),
            ("BCO-244-T", "Entrepreneurship Development",                "theory",    4, 5),
            ("BCO-245-T", "Auditing and Assurance",                      "theory",    2, 2),
            ("FP-241-BCO","Field Project / Internship",                  "practical", 4, 8),
            # Sem V
            ("BCO-331-T", "Management Accounting",                       "theory",    4, 5),
            ("BCO-332-T", "Direct and Indirect Taxation",                "theory",    4, 5),
            ("BCO-333-T", "Financial Management",                        "theory",    4, 5),
            ("BCO-334-T", "Strategic Management",                        "theory",    4, 5),
            ("ME-331-BCO","Major Elective: Banking and Finance",         "elective",  4, 5),
            ("ME-332-BCO","Major Elective: International Business",      "elective",  4, 5),
            ("ME-333-BCO","Major Elective: Digital Marketing",           "elective",  4, 5),
            # Sem VI
            ("BCO-341-T", "Advanced Financial Accounting",               "theory",    4, 5),
            ("BCO-342-T", "GST and Tax Planning",                        "theory",    4, 5),
            ("BCO-343-T", "Corporate Governance and Business Ethics",    "theory",    4, 5),
            ("BCO-344-T", "Investment Analysis and Portfolio Management","theory",    4, 5),
            ("BCO-345-P", "Project Work",                                "practical", 4, 8),
            ("ME-341-BCO","Major Elective: Supply Chain Management",     "elective",  4, 5),
            ("ME-342-BCO","Major Elective: Insurance and Risk Management","elective", 4, 5),
            ("FP-341-BCO","Field Project II",                            "practical", 4, 8),
        ]
        for code, name, ctype, credits, hours in bcom_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "B.Com", "UG", "Commerce")
        db.commit()
        print("  ✅ B.Com courses added\n")

        # ════════════════════════════════════════════════════════
        # B.B.A — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("📊 Adding B.B.A courses...")

        bba_courses = [
            # Sem I
            ("BBA-101-T", "Principles of Management",                    "theory",    4, 5),
            ("BBA-102-T", "Business Economics (Micro)",                  "theory",    4, 5),
            ("BBA-103-T", "Financial Accounting",                        "theory",    4, 5),
            ("BBA-104-T", "Business Mathematics I",                      "theory",    2, 2),
            ("BBA-105-T", "Business Communication I",                    "theory",    2, 2),
            ("BBA-106-T", "Environmental Awareness",                     "theory",    2, 2),
            ("OE-101-BBA","Office Automation Tools",                     "elective",  2, 2),
            ("IKS-100-BBA","Indian Knowledge System",                    "theory",    2, 2),
            # Sem II
            ("BBA-151-T", "Principles of Marketing",                     "theory",    4, 5),
            ("BBA-152-T", "Business Economics (Macro)",                  "theory",    4, 5),
            ("BBA-153-T", "Principles of Finance",                       "theory",    4, 5),
            ("BBA-154-T", "Business Mathematics II",                     "theory",    2, 2),
            ("BBA-155-T", "Business Communication II",                   "theory",    2, 2),
            ("BBA-156-T", "Principles of Human Resource Management",     "theory",    4, 5),
            ("OE-151-BBA","E-Commerce and Digital Business",             "elective",  2, 2),
            # Sem III
            ("BBA-231-T", "Financial Management",                        "theory",    4, 5),
            ("BBA-232-T", "Marketing Management",                        "theory",    4, 5),
            ("BBA-233-T", "Organizational Behavior",                     "theory",    4, 5),
            ("BBA-234-T", "Business Research Methods",                   "theory",    4, 5),
            ("BBA-235-T", "Business Law",                                "theory",    2, 2),
            ("OE-231-BBA","Digital Marketing Fundamentals",              "elective",  2, 2),
            # Sem IV
            ("BBA-241-T", "Strategic Management",                        "theory",    4, 5),
            ("BBA-242-T", "Entrepreneurship and Innovation",             "theory",    4, 5),
            ("BBA-243-T", "Supply Chain and Operations Management",      "theory",    4, 5),
            ("BBA-244-T", "Business Analytics",                          "theory",    4, 5),
            ("BBA-245-T", "Corporate Social Responsibility",             "theory",    2, 2),
            ("FP-241-BBA","Field Project / Internship",                  "practical", 4, 8),
            # Sem V
            ("BBA-331-T", "International Business Management",           "theory",    4, 5),
            ("BBA-332-T", "Project Management",                          "theory",    4, 5),
            ("BBA-333-T", "Leadership and Team Management",              "theory",    4, 5),
            ("ME-331-BBA","Major Elective: Banking and Financial Services","elective",4, 5),
            ("ME-332-BBA","Major Elective: Retail Management",           "elective",  4, 5),
            ("ME-333-BBA","Major Elective: Event Management",            "elective",  4, 5),
            # Sem VI
            ("BBA-341-T", "Corporate Governance and Ethics",             "theory",    4, 5),
            ("BBA-342-T", "Mergers Acquisitions and Corporate Restructuring","theory",4, 5),
            ("BBA-343-T", "Change Management",                           "theory",    4, 5),
            ("BBA-344-P", "Project Work",                                "practical", 4, 8),
            ("ME-341-BBA","Major Elective: Wealth Management",           "elective",  4, 5),
            ("ME-342-BBA","Major Elective: Digital Transformation",      "elective",  4, 5),
            ("FP-341-BBA","Field Project II",                            "practical", 4, 8),
        ]
        for code, name, ctype, credits, hours in bba_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "B.B.A", "UG", "Commerce")
        db.commit()
        print("  ✅ B.B.A courses added\n")

        # ════════════════════════════════════════════════════════
        # M.Sc. COMPUTER SCIENCE — SPPU NEP 2024 (4 Semesters)
        # ════════════════════════════════════════════════════════
        print("🎓 Adding M.Sc. Computer Science courses...")

        msc_cs_courses = [
            # Sem I
            ("MCS-101-T", "Advanced Data Structures and Algorithms",     "theory",    4, 4),
            ("MCS-102-T", "Advanced Database Management Systems",        "theory",    4, 4),
            ("MCS-103-T", "Advanced Operating Systems",                  "theory",    4, 4),
            ("MCS-104-P", "Lab: Advanced Programming",                   "practical", 2, 4),
            ("MCS-105-T", "Research Methodology",                        "theory",    2, 2),
            ("ME-101-MCS","Elective: Machine Learning",                  "elective",  4, 4),
            # Sem II
            ("MCS-151-T", "Advanced Computer Networks",                  "theory",    4, 4),
            ("MCS-152-T", "Distributed Systems",                         "theory",    4, 4),
            ("MCS-153-T", "Software Architecture and Design Patterns",   "theory",    4, 4),
            ("MCS-154-P", "Lab: Network and Distributed Systems",        "practical", 2, 4),
            ("MCS-155-T", "Cloud Computing",                             "theory",    4, 4),
            ("ME-151-MCS","Elective: Deep Learning",                     "elective",  4, 4),
            ("FP-151-MCS","Mini Project",                                "practical", 4, 8),
            # Sem III
            ("MCS-231-T", "Artificial Intelligence",                     "theory",    4, 4),
            ("MCS-232-T", "Big Data Analytics",                          "theory",    4, 4),
            ("MCS-233-T", "Information Security",                        "theory",    4, 4),
            ("MCS-234-P", "Lab: AI and Big Data",                        "practical", 2, 4),
            ("ME-231-MCS","Elective: Natural Language Processing",       "elective",  4, 4),
            ("ME-232-MCS","Elective: Computer Vision",                   "elective",  4, 4),
            # Sem IV
            ("MCS-241-T", "Advanced Topics in Computer Science",         "theory",    4, 4),
            ("MCS-242-T", "Seminar and Technical Presentation",          "theory",    2, 2),
            ("MCS-243-P", "Major Project",                               "practical", 8, 16),
            ("ME-241-MCS","Elective: Quantum Computing",                 "elective",  4, 4),
            ("ME-242-MCS","Elective: Cybersecurity Management",          "elective",  4, 4),
        ]
        for code, name, ctype, credits, hours in msc_cs_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "M.Sc. Computer Science", "PG", "Computer Science")
        db.commit()
        print("  ✅ M.Sc. Computer Science courses added\n")

        # ════════════════════════════════════════════════════════
        # M.Sc. COMPUTER APPLICATION — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("🎓 Adding M.Sc. Computer Application courses...")

        msc_ca_courses = [
            # Sem I
            ("MCA-101-T", "Advanced Java Programming",                   "theory",    4, 4),
            ("MCA-102-P", "Lab: Advanced Java",                          "practical", 2, 4),
            ("MCA-103-T", "Advanced Web Technologies",                   "theory",    4, 4),
            ("MCA-104-P", "Lab: Web Technologies",                       "practical", 2, 4),
            ("MCA-105-T", "Software Engineering and Project Management", "theory",    4, 4),
            ("MCA-106-T", "Research Methodology",                        "theory",    2, 2),
            ("ME-101-MCA","Elective: Mobile App Development",            "elective",  4, 4),
            # Sem II
            ("MCA-151-T", "Full Stack Web Development",                  "theory",    4, 4),
            ("MCA-152-P", "Lab: Full Stack Development",                 "practical", 2, 4),
            ("MCA-153-T", "Cloud Computing and DevOps",                  "theory",    4, 4),
            ("MCA-154-T", "Data Science and Machine Learning",           "theory",    4, 4),
            ("MCA-155-P", "Lab: Data Science",                           "practical", 2, 4),
            ("ME-151-MCA","Elective: UI/UX Design",                      "elective",  4, 4),
            ("FP-151-MCA","Mini Project",                                "practical", 4, 8),
            # Sem III
            ("MCA-231-T", "Enterprise Application Development",          "theory",    4, 4),
            ("MCA-232-P", "Lab: Enterprise Application",                 "practical", 2, 4),
            ("MCA-233-T", "Information Security and Cyber Laws",         "theory",    4, 4),
            ("MCA-234-T", "Artificial Intelligence Applications",        "theory",    4, 4),
            ("ME-231-MCA","Elective: Blockchain Development",            "elective",  4, 4),
            ("ME-232-MCA","Elective: Internet of Things",                "elective",  4, 4),
            # Sem IV
            ("MCA-241-T", "Advanced Software Testing",                   "theory",    4, 4),
            ("MCA-242-T", "Seminar and Technical Presentation",          "theory",    2, 2),
            ("MCA-243-P", "Major Project",                               "practical", 8, 16),
            ("ME-241-MCA","Elective: Game Development",                  "elective",  4, 4),
            ("ME-242-MCA","Elective: Augmented Reality Development",     "elective",  4, 4),
        ]
        for code, name, ctype, credits, hours in msc_ca_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "M.Sc. Computer Application", "PG", "Computer Science")
        db.commit()
        print("  ✅ M.Sc. Computer Application courses added\n")

        # ════════════════════════════════════════════════════════
        # M.Sc. DATA SCIENCE — SPPU NEP 2024
        # ════════════════════════════════════════════════════════
        print("🎓 Adding M.Sc. Data Science courses...")

        msc_ds_courses = [
            # Sem I
            ("MDS-101-T", "Statistics for Data Science",                 "theory",    4, 4),
            ("MDS-102-P", "Lab: Statistical Analysis using R/Python",    "practical", 2, 4),
            ("MDS-103-T", "Machine Learning Fundamentals",               "theory",    4, 4),
            ("MDS-104-P", "Lab: Machine Learning",                       "practical", 2, 4),
            ("MDS-105-T", "Data Warehousing and Mining",                 "theory",    4, 4),
            ("MDS-106-T", "Research Methodology",                        "theory",    2, 2),
            ("ME-101-MDS","Elective: Python for Data Science",           "elective",  4, 4),
            # Sem II
            ("MDS-151-T", "Deep Learning and Neural Networks",           "theory",    4, 4),
            ("MDS-152-P", "Lab: Deep Learning",                          "practical", 2, 4),
            ("MDS-153-T", "Big Data Technologies (Hadoop/Spark)",        "theory",    4, 4),
            ("MDS-154-P", "Lab: Big Data",                               "practical", 2, 4),
            ("MDS-155-T", "Data Visualization",                          "theory",    4, 4),
            ("ME-151-MDS","Elective: Natural Language Processing",       "elective",  4, 4),
            ("FP-151-MDS","Mini Project",                                "practical", 4, 8),
            # Sem III
            ("MDS-231-T", "Reinforcement Learning",                      "theory",    4, 4),
            ("MDS-232-P", "Lab: Reinforcement Learning",                 "practical", 2, 4),
            ("MDS-233-T", "Computer Vision",                             "theory",    4, 4),
            ("MDS-234-T", "Business Intelligence and Analytics",         "theory",    4, 4),
            ("ME-231-MDS","Elective: Time Series Analysis",              "elective",  4, 4),
            ("ME-232-MDS","Elective: Recommender Systems",               "elective",  4, 4),
            # Sem IV
            ("MDS-241-T", "Ethics in Data Science and AI",               "theory",    2, 2),
            ("MDS-242-T", "Seminar and Technical Presentation",          "theory",    2, 2),
            ("MDS-243-P", "Major Project: Data Science Application",     "practical", 8, 16),
            ("ME-241-MDS","Elective: MLOps and Deployment",              "elective",  4, 4),
            ("ME-242-MDS","Elective: Generative AI",                     "elective",  4, 4),
        ]
        for code, name, ctype, credits, hours in msc_ds_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "M.Sc. Data Science", "PG", "Computer Science")
        db.commit()
        print("  ✅ M.Sc. Data Science courses added\n")

        # ════════════════════════════════════════════════════════
        # M.COM — SPPU NEP 2024 (4 Semesters)
        # ════════════════════════════════════════════════════════
        print("🎓 Adding M.Com courses...")

        mcom_courses = [
            # Sem I
            ("MCO-101-T", "Advanced Financial Accounting",               "theory",    4, 4),
            ("MCO-102-T", "Managerial Economics",                        "theory",    4, 4),
            ("MCO-103-T", "Advanced Cost Accounting",                    "theory",    4, 4),
            ("MCO-104-T", "Research Methodology in Commerce",            "theory",    4, 4),
            ("MCO-105-T", "Corporate Laws and Governance",               "theory",    4, 4),
            ("ME-101-MCO","Elective: Financial Markets and Institutions","elective",  4, 4),
            # Sem II
            ("MCO-151-T", "Strategic Financial Management",              "theory",    4, 4),
            ("MCO-152-T", "Advanced Auditing and Assurance",             "theory",    4, 4),
            ("MCO-153-T", "International Business and Trade",            "theory",    4, 4),
            ("MCO-154-T", "Taxation — Direct and Indirect",              "theory",    4, 4),
            ("ME-151-MCO","Elective: Investment Banking",                "elective",  4, 4),
            ("FP-151-MCO","Mini Project / Field Work",                   "practical", 4, 8),
            # Sem III
            ("MCO-231-T", "Corporate Finance",                           "theory",    4, 4),
            ("MCO-232-T", "Mergers Acquisitions and Valuations",         "theory",    4, 4),
            ("MCO-233-T", "Supply Chain Finance",                        "theory",    4, 4),
            ("MCO-234-T", "E-Commerce and Digital Commerce",             "theory",    4, 4),
            ("ME-231-MCO","Elective: Risk Management and Insurance",     "elective",  4, 4),
            ("ME-232-MCO","Elective: Wealth and Portfolio Management",   "elective",  4, 4),
            # Sem IV
            ("MCO-241-T", "Business Ethics and CSR",                     "theory",    4, 4),
            ("MCO-242-T", "Seminar and Presentation",                    "theory",    2, 2),
            ("MCO-243-P", "Major Project / Dissertation",                "practical", 8, 16),
            ("ME-241-MCO","Elective: FinTech and Digital Payments",      "elective",  4, 4),
            ("ME-242-MCO","Elective: Derivatives and Risk",              "elective",  4, 4),
        ]
        for code, name, ctype, credits, hours in mcom_courses:
            add_course(db, code, name, ctype, credits, hours,
                       "M.Com", "PG", "Commerce")
        db.commit()
        print("  ✅ M.Com courses added\n")

        # ── FINAL SUMMARY ────────────────────────────────────────
        total = db.query(models.Course).count()
        print("=" * 55)
        print("🎉 ALL COURSES INSERTED SUCCESSFULLY!")
        print("=" * 55)
        print(f"\n📊 Total Courses in Database: {total}")
        print("\nCourses by Program:")
        for prog in db.query(models.Program).all():
            count = db.query(models.Course).filter_by(program_id=prog.id).count()
            print(f"  {prog.program_name:<45} → {count} courses")

    except Exception as e:
        db.rollback()
        print(f"\n❌ Error: {e}")
        raise e
    finally:
        db.close()


if __name__ == "__main__":
    seed_courses()