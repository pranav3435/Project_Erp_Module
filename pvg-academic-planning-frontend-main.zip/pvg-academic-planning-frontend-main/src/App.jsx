import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import FacultyDashboard from './pages/FacultyDashboard';
import StudentDashboard from './pages/StudentDashboard';
import Timetable from './pages/Timetable';
import AcademicPlanning from './pages/AcademicPlanning';
import GenericModulePage from './pages/GenericModulePage';
import { MODULE_CONFIG } from './config/modules';

function Topbar() {
  const location = useLocation();
  const getPageName = () => {
    if (location.pathname.startsWith('/module/')) {
      const moduleKey = location.pathname.split('/')[2];
      return MODULE_CONFIG[moduleKey]?.title || 'Module';
    }
    switch (location.pathname) {
      case '/dashboard': return 'Dashboard';
      case '/timetable': return 'Weekly Timetable';
      case '/planning': return 'Course Overview';
      default: return 'College ERP';
    }
  };

  return (
    <header className="erp-topbar" style={{ height: '80px', paddingRight: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <button className="erp-topbar__btn" data-erp-sidebar-toggle>
          <i className="fa-solid fa-bars"></i>
        </button>
        <nav className="erp-topbar__breadcrumb" data-erp-breadcrumb style={{ whiteSpace: 'nowrap', zIndex: 2, marginLeft: '16px' }}>
          <span>{getPageName()}</span>
        </nav>
      </div>
      
      {/* 
        The dropdown has been removed for production!
        The role is now automatically determined by localStorage or URL query parameters passed from the Auth module.
      */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <span style={{ fontSize: '13px', color: 'var(--erp-text-muted)', background: 'rgba(0,0,0,0.05)', padding: '6px 12px', borderRadius: '20px' }}>
          <i className="fa-solid fa-shield-halved" style={{ marginRight: '6px' }}></i>
          Secured View
        </span>
      </div>
    </header>
  );
}

function MainContent({ userRole }) {
  const renderDashboard = () => {
    if (userRole === 'faculty') return <FacultyDashboard />;
    if (userRole === 'student') return <StudentDashboard />;
    return <Dashboard />; // Admin default
  };

  return (
    <main className="erp-main" style={{ overflowY: 'auto', flex: 1, padding: '24px' }}>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={renderDashboard()} />
        <Route path="/timetable" element={<Timetable userRole={userRole} />} />
        <Route path="/planning" element={<AcademicPlanning />} />
        <Route path="/module/:moduleKey" element={<GenericModulePage userRole={userRole} />} />
      </Routes>
    </main>
  );
}

function MainLayout() {
  const [userRole, setUserRole] = useState(localStorage.getItem('userRole') || 'admin');

  useEffect(() => {
    // Check if the external authentication module passed a role in the URL
    const params = new URLSearchParams(window.location.search);
    const roleParam = params.get('role');
    
    if (roleParam) {
      const normalizedRole = roleParam.toLowerCase();
      if (['admin', 'faculty', 'student'].includes(normalizedRole)) {
        setUserRole(normalizedRole);
        localStorage.setItem('userRole', normalizedRole);
        
        // Clean up the URL so the parameter doesn't stay there
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    }
  }, []);

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden' }}>
      <Sidebar userRole={userRole} />
      <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden', '--erp-topbar-h': '80px' }}>
        <Topbar />
        <MainContent userRole={userRole} />
      </div>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="*" element={<MainLayout />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
