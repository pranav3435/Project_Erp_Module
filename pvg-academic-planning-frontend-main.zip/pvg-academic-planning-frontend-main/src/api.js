const API_BASE_URL = '/api';

export const fetchDashboardStats = async () => {
  const response = await fetch(`${API_BASE_URL}/dashboard/stats`);
  if (!response.ok) throw new Error('Failed to fetch dashboard stats');
  return response.json();
};

export const fetchTimetable = async () => {
  const response = await fetch(`${API_BASE_URL}/timetables/`);
  if (!response.ok) throw new Error('Failed to fetch timetable');
  return response.json();
};

export const fetchCourses = async () => {
  const response = await fetch(`${API_BASE_URL}/courses/`);
  if (!response.ok) throw new Error('Failed to fetch courses');
  return response.json();
};
