import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, CalendarDays, GraduationCap, Settings, Bell, Search, User } from 'lucide-react';
import './Layout.css';

const Layout = ({ children }) => {
  const location = useLocation();

  const getPageTitle = () => {
    switch (location.pathname) {
      case '/dashboard': return 'Overview Dashboard';
      case '/timetable': return 'Timetable Management';
      case '/academic-planning': return 'Academic Planning';
      default: return 'College ERP';
    }
  };

  return (
    <div className="app-container">
      {/* Sidebar */}
      <aside className="sidebar glass-panel">
        <div className="sidebar-header">
          <div className="logo-icon">
            <GraduationCap size={28} color="var(--primary-color)" />
          </div>
          <h2>EduERP</h2>
        </div>

        <nav className="sidebar-nav">
          <NavLink to="/dashboard" className={({isActive}) => isActive ? 'nav-item active' : 'nav-item'}>
            <LayoutDashboard size={20} />
            <span>Dashboard</span>
          </NavLink>
          <NavLink to="/timetable" className={({isActive}) => isActive ? 'nav-item active' : 'nav-item'}>
            <CalendarDays size={20} />
            <span>Timetable</span>
          </NavLink>
          <NavLink to="/academic-planning" className={({isActive}) => isActive ? 'nav-item active' : 'nav-item'}>
            <GraduationCap size={20} />
            <span>Academic Planning</span>
          </NavLink>
        </nav>

        <div className="sidebar-footer">
          <button className="nav-item">
            <Settings size={20} />
            <span>Settings</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="main-content">
        <header className="top-header glass-panel">
          <div className="header-title">
            <h1>{getPageTitle()}</h1>
          </div>
          <div className="header-actions">
            <div className="search-bar">
              <Search size={18} className="search-icon" />
              <input type="text" placeholder="Search..." className="search-input" />
            </div>
            <button className="icon-btn">
              <Bell size={20} />
              <span className="badge">3</span>
            </button>
            <div className="user-profile">
              <div className="avatar">
                <User size={20} />
              </div>
              <div className="user-info">
                <span className="user-name">Admin User</span>
                <span className="user-role">Administrator</span>
              </div>
            </div>
          </div>
        </header>

        <main className="page-content animate-fade-in">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
