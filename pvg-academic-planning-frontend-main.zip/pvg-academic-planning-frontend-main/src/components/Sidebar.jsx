import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { MODULE_CONFIG } from '../config/modules';

const Sidebar = ({ userRole }) => {
  const navigate = useNavigate();
  
  const handleLogout = () => {
    localStorage.removeItem('userRole');
    window.location.href = 'https://automatic-certify-appointee.ngrok-free.dev/login';
  };

  // Define allowed modules for each role
  const allowedModules = {
    admin: Object.keys(MODULE_CONFIG), // Admin gets everything
    faculty: ['courses', 'academic-calendar'], // Map to My Courses, Academic Calendar
    student: ['departments', 'programs', 'courses', 'fees', 'academic-calendar'] 
  };

  const categories = {};
  Object.entries(MODULE_CONFIG).forEach(([key, config]) => {
    // Filter modules based on role
    if (allowedModules[userRole]?.includes(key) || userRole === 'admin') {
      if (!categories[config.category]) categories[config.category] = [];
      categories[config.category].push({ key, ...config });
    }
  });

  return (
    <aside className="erp-sidebar" style={{ overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
      <div className="erp-sidebar__brand" style={{ flexShrink: 0 }}>
        <div className="erp-sidebar__brand-text">
          <h2>PVG COET&M</h2>
          <span>ERP System</span>
        </div>
      </div>

      <nav className="erp-sidebar__nav" style={{ flex: 1, overflowY: 'auto', paddingBottom: '20px' }}>
        <div className="erp-nav-label">Dashboards</div>

        <NavLink
          to="/dashboard"
          className={({ isActive }) => `erp-nav-item ${isActive ? 'erp-nav-item--active' : ''}`}
        >
          <i className="fa-solid fa-gauge-high"></i>
          <span className="erp-nav-item__text">Dashboard</span>
        </NavLink>

        <NavLink
          to="/timetable"
          className={({ isActive }) => `erp-nav-item ${isActive ? 'erp-nav-item--active' : ''}`}
        >
          <i className="fa-solid fa-calendar-days"></i>
          <span className="erp-nav-item__text">{userRole === 'admin' ? 'Weekly Timetable' : 'My Timetable'}</span>
        </NavLink>

        {userRole === 'admin' && (
          <NavLink
            to="/planning"
            className={({ isActive }) => `erp-nav-item ${isActive ? 'erp-nav-item--active' : ''}`}
          >
            <i className="fa-solid fa-book-open"></i>
            <span className="erp-nav-item__text">Course Overview</span>
          </NavLink>
        )}

        {Object.entries(categories).map(([category, modules]) => (
          <React.Fragment key={category}>
            <div className="erp-nav-label" style={{ marginTop: '20px' }}>{category}</div>
            {modules.map(mod => (
              <NavLink
                key={mod.key}
                to={`/module/${mod.key}`}
                className={({ isActive }) => `erp-nav-item ${isActive ? 'erp-nav-item--active' : ''}`}
              >
                <i className={`fa-solid ${mod.icon}`}></i>
                <span className="erp-nav-item__text">{mod.title}</span>
              </NavLink>
            ))}
          </React.Fragment>
        ))}

        <div className="erp-nav-label" style={{ marginTop: '20px' }}>External Modules</div>
        
        <a 
          href="https://automatic-certify-appointee.ngrok-free.dev" 
          className="erp-nav-item"
        >
          <i className="fa-solid fa-shield-halved"></i>
          <span className="erp-nav-item__text">Auth Module</span>
        </a>

        <a 
          href="https://6dcc-2409-40c2-102b-132f-21b1-c754-e5b9-6da5.ngrok-free.app" 
          className="erp-nav-item"
        >
          <i className="fa-solid fa-address-card"></i>
          <span className="erp-nav-item__text">Admission Module</span>
        </a>

        <a 
          href="https://exploring-ageless-thigh.ngrok-free.dev" 
          className="erp-nav-item"
        >
          <i className="fa-solid fa-money-check-dollar"></i>
          <span className="erp-nav-item__text">Fee Module</span>
        </a>

        <a 
          href="https://enactment-commode-configure.ngrok-free.dev" 
          className="erp-nav-item"
        >
          <i className="fa-solid fa-graduation-cap"></i>
          <span className="erp-nav-item__text">SIS Module</span>
        </a>
      </nav>

      <div className="erp-sidebar__footer" style={{ flexShrink: 0 }}>
        <div className="erp-avatar erp-avatar--md">
          {userRole === 'admin' ? 'AD' : userRole === 'faculty' ? 'FA' : 'ST'}
        </div>
        <div className="erp-sidebar__user-info">
          <p style={{ textTransform: 'capitalize' }}>{userRole} User</p>
          <span style={{ textTransform: 'capitalize' }}>{userRole}</span>
        </div>
        <i className="fa-solid fa-right-from-bracket erp-sidebar__logout" style={{ cursor: 'pointer' }} onClick={handleLogout} title="Logout"></i>
      </div>
    </aside>
  );
};

export default Sidebar;
