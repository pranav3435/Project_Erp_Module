export const MODULE_CONFIG = {
  "departments": {
    title: "Departments",
    description: "Manage college departments and branches.",
    endpoint: "departments",
    icon: "fa-building",
    category: "Administration Setup"
  },
  "academic-years": {
    title: "Academic Years",
    description: "Manage academic years for curriculum.",
    endpoint: "academic-years",
    icon: "fa-calendar",
    category: "Administration Setup"
  },
  "programs": {
    title: "Programs",
    description: "Manage academic programs and degrees.",
    endpoint: "programs",
    icon: "fa-graduation-cap",
    category: "Administration Setup"
  },
  "semesters": {
    title: "Semesters",
    description: "Manage semesters.",
    endpoint: "semesters",
    icon: "fa-layer-group",
    category: "Academic Structure"
  },
  "classes": {
    title: "Classes",
    description: "Manage classes.",
    endpoint: "classes",
    icon: "fa-chalkboard",
    category: "Academic Structure"
  },
  "sections": {
    title: "Sections",
    description: "Manage sections (UG/PG).",
    endpoint: "sections",
    icon: "fa-puzzle-piece",
    category: "Academic Structure"
  },
  "divisions": {
    title: "Divisions",
    description: "Manage divisions.",
    endpoint: "divisions",
    icon: "fa-users-rectangle",
    category: "Academic Structure"
  },
  "batches": {
    title: "Batches",
    description: "Manage lab and practical batches.",
    endpoint: "batches",
    icon: "fa-users-line",
    category: "Academic Structure"
  },
  "courses": {
    title: "Courses",
    description: "Manage subjects and courses.",
    endpoint: "courses",
    icon: "fa-book",
    category: "Academic Structure"
  },
  "faculty": {
    title: "Faculty Directory",
    description: "Manage teaching staff.",
    endpoint: "faculty",
    icon: "fa-chalkboard-user",
    category: "Staff & Students"
  },
  "student-batches": {
    title: "Student Batches",
    description: "Assign students to specific batches.",
    endpoint: "student-batches",
    icon: "fa-user-graduate",
    category: "Staff & Students"
  },
  "classrooms": {
    title: "Classrooms",
    description: "Manage physical classrooms.",
    endpoint: "classrooms",
    icon: "fa-door-open",
    category: "Infrastructure"
  },
  "labs": {
    title: "Labs",
    description: "Manage laboratory rooms.",
    endpoint: "labs",
    icon: "fa-flask",
    category: "Infrastructure"
  },
  "academic-calendar": {
    title: "Academic Calendar",
    description: "Holidays, exams, and events.",
    endpoint: "academic-calendar",
    icon: "fa-calendar-days",
    category: "Scheduling & Events"
  },
  "timetables": {
    title: "Timetables",
    description: "View and manage all timetable.",
    endpoint: "timetable",
    icon: "fa-table-cells",
    category: "Scheduling & Events"
  },
  "faculty-timetables": {
    title: "Faculty Timetables",
    description: "Faculty-specific schedules.",
    endpoint: "faculty-timetables",
    icon: "fa-clock",
    category: "Scheduling & Events"
  },
  "classroom-occupancy": {
    title: "Classroom Occupancy",
    description: "Monitor room booking tracker.",
    endpoint: "classroom-occupancy",
    icon: "fa-building-user",
    category: "Scheduling & Events"
  },
  "fees": {
    title: "Fees",
    description: "Manage class-wise fees and installments.",
    endpoint: "fees",
    icon: "fa-money-check-dollar",
    category: "Finance & Admin"
  },
  "logs": {
    title: "Logs",
    description: "System user activity logs.",
    endpoint: "logs",
    icon: "fa-list",
    category: "Finance & Admin"
  }
};
