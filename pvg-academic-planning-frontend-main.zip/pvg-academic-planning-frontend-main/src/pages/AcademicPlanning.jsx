import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const AcademicPlanning = () => {
  const navigate = useNavigate();
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetch('/api/courses/')
      .then(res => res.json())
      .then(data => {
        // Map database Course objects to the UI format
        const mappedCourses = Array.isArray(data) ? data.map(dbCourse => ({
          id: dbCourse.id.toString(),
          name: dbCourse.course_name,
          credits: dbCourse.course_credit || 0,
          prof: "Not Assigned",
          type: dbCourse.course_type ? dbCourse.course_type.charAt(0).toUpperCase() + dbCourse.course_type.slice(1) : "Core",
          students: 0
        })) : [];
        setCourses(mappedCourses);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching courses:", err);
        setLoading(false);
      });
  }, []);

  const filteredCourses = courses.filter(course => 
    course.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    course.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <i className="fa-solid fa-spinner fa-spin fa-3x" style={{ color: 'var(--erp-primary)' }}></i>
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px', color: 'var(--erp-text)' }}>Academic Planning</h1>
          <p style={{ color: 'var(--erp-text-muted)' }}>Manage curriculum, courses, and credit requirements.</p>
        </div>
        <button className="erp-btn erp-btn--primary" onClick={() => navigate('/module/courses')}>
          <i className="fa-solid fa-plus" style={{ marginRight: '8px' }}></i>
          Add Course
        </button>
      </div>

      <div className="erp-card" style={{ marginBottom: '24px' }}>
        <div className="erp-card__body" style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <i className="fa-solid fa-search" style={{ color: 'var(--erp-text-muted)', position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)' }}></i>
            <input 
              type="text" 
              placeholder="Search courses by name or ID..." 
              className="erp-form-control" 
              style={{ width: '100%', paddingLeft: '44px' }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button className="erp-btn erp-btn--outline">
            <i className="fa-solid fa-filter" style={{ marginRight: '8px' }}></i>
            Filters
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '24px' }}>
        {filteredCourses.map(course => (
          <div key={course.id} className="erp-card">
            <div className="erp-card__body" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                <span className={`erp-badge erp-badge--${course.type === 'Core' ? 'primary' : 'secondary'}`}>
                  {course.type}
                </span>
                <span style={{ fontWeight: '600', color: 'var(--erp-text-muted)' }}>{course.id}</span>
              </div>
              
              <h3 style={{ fontSize: '18px', fontWeight: '700', marginBottom: '8px', lineHeight: '1.3', color: 'var(--erp-text)', margin: '0 0 8px 0' }}>{course.name}</h3>
              <p style={{ color: 'var(--erp-text-muted)', fontSize: '14px', marginBottom: '20px' }}>
                <i className="fa-solid fa-chalkboard-user" style={{ marginRight: '6px' }}></i> {course.prof}
              </p>
              
              <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '16px', borderTop: '1px solid var(--erp-border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--erp-text-muted)', fontSize: '13px', fontWeight: '500' }}>
                    <i className="fa-solid fa-star" style={{ color: 'var(--erp-warning)' }}></i>
                    {course.credits} Credits
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--erp-text-muted)', fontSize: '13px', fontWeight: '500' }}>
                    <i className="fa-solid fa-users"></i>
                    {course.students}
                  </div>
                </div>
                <button className="erp-btn erp-btn--ghost erp-btn--sm" style={{ padding: '6px', borderRadius: '50%' }}>
                  <i className="fa-solid fa-book-open"></i>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AcademicPlanning;
