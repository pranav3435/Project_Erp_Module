import React, { useState, useEffect } from 'react';

const StatCard = ({ title, value, iconClass, colorClass, trend }) => (
  <div className={`erp-stat-card erp-stat-card${colorClass}`}>
    <div className="erp-stat-card__header">
      <div className="erp-stat-card__icon"><i className={`fa-solid ${iconClass}`}></i></div>
      {trend && <span className="erp-stat-card__trend erp-stat-card__trend--up">{trend}</span>}
    </div>
    <div className="erp-stat-card__value">{value}</div>
    <div className="erp-stat-card__label">{title}</div>
  </div>
);

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('/api/dashboard/stats')
      .then(res => {
        if (!res.ok) throw new Error("Failed to fetch");
        return res.json();
      })
      .then(data => {
        setStats(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching stats:", err);
        setError("Could not load dashboard data. Is the backend running?");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <i className="fa-solid fa-spinner fa-spin fa-3x" style={{ color: 'var(--erp-primary)' }}></i>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: '40px', textAlign: 'center', backgroundColor: '#fff', borderRadius: '8px', border: '1px solid var(--erp-border)', marginTop: '20px' }}>
        <i className="fa-solid fa-triangle-exclamation fa-3x" style={{ marginBottom: '16px', color: 'var(--erp-danger, #ef4444)' }}></i>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '12px', color: 'var(--erp-text, #1f2937)' }}>Connection Error</h2>
        <p style={{ fontSize: '1.1rem', color: 'var(--erp-text-muted, #4b5563)' }}>{error}</p>
        <p style={{ marginTop: '16px', fontSize: '1rem', color: 'var(--erp-text-muted, #6b7280)' }}>
          Please make sure your FastAPI backend is running on <strong>http://localhost:8000</strong>.
        </p>
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div>
      <div style={{ marginBottom: '30px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px', color: 'var(--erp-text)' }}>Dashboard Overview</h1>
        <p style={{ color: 'var(--erp-text-muted)' }}>Welcome back! Here's what's happening today.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px', marginBottom: '32px' }}>
        <StatCard title="Total Students" value={stats.enrolledStudents} iconClass="fa-users" colorClass="--primary" trend="+2.4%" />
        <StatCard title="Active Professors" value={stats.activeProfessors} iconClass="fa-chalkboard-user" colorClass="--secondary" />
        <StatCard title="Total Courses" value={stats.totalCourses} iconClass="fa-book" colorClass="--success" trend="+1.1%" />
        <StatCard title="Classes Today" value={stats.classesToday} iconClass="fa-clock" colorClass="--warning" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
        <div className="erp-card">
          <div className="erp-card__header">
            <div>
              <div className="erp-card__title">Today's Schedule</div>
              <div className="erp-card__subtitle">Your upcoming classes and labs</div>
            </div>
            <button className="erp-btn erp-btn--outline erp-btn--sm">View Full <i className="fa-solid fa-arrow-right"></i></button>
          </div>
          <div className="erp-card__body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {stats.scheduleOverview.map((item, idx) => (
                <div key={idx} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '16px', borderRadius: '8px',
                  border: '1px solid var(--erp-border)',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    <div className="erp-badge erp-badge--primary" style={{ fontSize: '14px', padding: '8px 12px' }}>
                      {item.time}
                    </div>
                    <div>
                      <h4 style={{ fontWeight: '600', marginBottom: '4px', color: 'var(--erp-text)' }}>{item.course}</h4>
                      <p style={{ fontSize: '13px', color: 'var(--erp-text-muted)' }}>{item.prof} &bull; {item.room}</p>
                    </div>
                  </div>
                  <button className="erp-btn erp-btn--ghost erp-btn--sm">Details</button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="erp-card">
          <div className="erp-card__header">
            <div>
              <div className="erp-card__title"><i className="fa-solid fa-bolt" style={{ color: 'var(--erp-primary)', marginRight: '8px' }}></i> Recent Activity</div>
            </div>
          </div>
          <div className="erp-card__body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {stats.recentActivity.map((activity, idx) => {
                const alertClass = activity.type === 'primary' ? 'erp-alert--info' : activity.type === 'success' ? 'erp-alert--success' : 'erp-alert--warning';
                return (
                  <div key={idx} className={`erp-alert ${alertClass}`} style={{ marginBottom: 0 }}>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <span style={{ fontWeight: '500' }}>{activity.text}</span>
                      <span style={{ fontSize: '12px', opacity: 0.8, marginTop: '4px' }}>{activity.time}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Fees Structure Widget */}
      <div style={{ marginTop: '24px' }}>
        <div className="erp-card">
          <div className="erp-card__header">
            <div>
              <div className="erp-card__title"><i className="fa-solid fa-money-check-dollar" style={{ color: 'var(--erp-success)', marginRight: '8px' }}></i> Class-wise Fees & Installments</div>
              <div className="erp-card__subtitle">Overview of fee collection status across classes</div>
            </div>
            <button className="erp-btn erp-btn--primary erp-btn--sm">Manage Fees</button>
          </div>
          <div className="erp-card__body" style={{ overflowX: 'auto' }}>
            <table className="erp-table" style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid var(--erp-border)', color: 'var(--erp-text-muted)' }}>
                  <th style={{ padding: '12px 8px' }}>Class</th>
                  <th style={{ padding: '12px 8px' }}>Total Fee (₹)</th>
                  <th style={{ padding: '12px 8px' }}>Installment 1</th>
                  <th style={{ padding: '12px 8px' }}>Installment 2</th>
                  <th style={{ padding: '12px 8px' }}>Collection Status</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{ borderBottom: '1px solid var(--erp-border)' }}>
                  <td style={{ padding: '12px 8px', fontWeight: '500' }}>First Year - CS</td>
                  <td style={{ padding: '12px 8px' }}>1,20,000</td>
                  <td style={{ padding: '12px 8px' }}><span className="erp-badge erp-badge--success">Completed</span></td>
                  <td style={{ padding: '12px 8px' }}><span className="erp-badge erp-badge--warning">Pending</span></td>
                  <td style={{ padding: '12px 8px' }}>
                    <div style={{ width: '100%', backgroundColor: 'var(--erp-border)', height: '8px', borderRadius: '4px' }}>
                      <div style={{ width: '65%', backgroundColor: 'var(--erp-success)', height: '100%', borderRadius: '4px' }}></div>
                    </div>
                    <span style={{ fontSize: '12px', color: 'var(--erp-text-muted)' }}>65% Collected</span>
                  </td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--erp-border)' }}>
                  <td style={{ padding: '12px 8px', fontWeight: '500' }}>Second Year - IT</td>
                  <td style={{ padding: '12px 8px' }}>1,15,000</td>
                  <td style={{ padding: '12px 8px' }}><span className="erp-badge erp-badge--success">Completed</span></td>
                  <td style={{ padding: '12px 8px' }}><span className="erp-badge erp-badge--success">Completed</span></td>
                  <td style={{ padding: '12px 8px' }}>
                    <div style={{ width: '100%', backgroundColor: 'var(--erp-border)', height: '8px', borderRadius: '4px' }}>
                      <div style={{ width: '92%', backgroundColor: 'var(--erp-success)', height: '100%', borderRadius: '4px' }}></div>
                    </div>
                    <span style={{ fontSize: '12px', color: 'var(--erp-text-muted)' }}>92% Collected</span>
                  </td>
                </tr>
                <tr>
                  <td style={{ padding: '12px 8px', fontWeight: '500' }}>Third Year - MECH</td>
                  <td style={{ padding: '12px 8px' }}>1,10,000</td>
                  <td style={{ padding: '12px 8px' }}><span className="erp-badge erp-badge--warning">Pending</span></td>
                  <td style={{ padding: '12px 8px' }}><span className="erp-badge erp-badge--warning">Pending</span></td>
                  <td style={{ padding: '12px 8px' }}>
                    <div style={{ width: '100%', backgroundColor: 'var(--erp-border)', height: '8px', borderRadius: '4px' }}>
                      <div style={{ width: '30%', backgroundColor: 'var(--erp-warning)', height: '100%', borderRadius: '4px' }}></div>
                    </div>
                    <span style={{ fontSize: '12px', color: 'var(--erp-text-muted)' }}>30% Collected</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
