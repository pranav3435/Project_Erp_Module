import React from 'react';

const FacultyDashboard = () => {
  return (
    <div>
      <div style={{ marginBottom: '30px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px', color: 'var(--erp-text)' }}>Faculty Dashboard</h1>
        <p style={{ color: 'var(--erp-text-muted)' }}>Welcome back! Here's your schedule and updates.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px', marginBottom: '32px' }}>
        <div className="erp-stat-card erp-stat-card--primary">
          <div className="erp-stat-card__header">
            <div className="erp-stat-card__icon"><i className="fa-solid fa-chalkboard-user"></i></div>
          </div>
          <div className="erp-stat-card__value">4</div>
          <div className="erp-stat-card__label">My Courses</div>
        </div>
        <div className="erp-stat-card erp-stat-card--warning">
          <div className="erp-stat-card__header">
            <div className="erp-stat-card__icon"><i className="fa-solid fa-clock"></i></div>
          </div>
          <div className="erp-stat-card__value">2</div>
          <div className="erp-stat-card__label">Classes Today</div>
        </div>
        <div className="erp-stat-card erp-stat-card--success">
          <div className="erp-stat-card__header">
            <div className="erp-stat-card__icon"><i className="fa-solid fa-calendar-check"></i></div>
          </div>
          <div className="erp-stat-card__value">1</div>
          <div className="erp-stat-card__label">Upcoming Exams</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
        <div className="erp-card">
          <div className="erp-card__header">
            <div>
              <div className="erp-card__title">My Upcoming Classes</div>
              <div className="erp-card__subtitle">Your schedule for today</div>
            </div>
          </div>
          <div className="erp-card__body">
            <p style={{ color: 'var(--erp-text-muted)' }}>No upcoming classes in the next hour.</p>
          </div>
        </div>

        <div className="erp-card">
          <div className="erp-card__header">
            <div>
              <div className="erp-card__title"><i className="fa-solid fa-bell" style={{ color: 'var(--erp-primary)', marginRight: '8px' }}></i> Notifications</div>
            </div>
          </div>
          <div className="erp-card__body">
            <div className="erp-alert erp-alert--info">
              <span style={{ fontWeight: '500' }}>Faculty meeting at 4 PM</span>
            </div>
            <div className="erp-alert erp-alert--warning">
              <span style={{ fontWeight: '500' }}>Submit mid-term grades by Friday</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FacultyDashboard;
