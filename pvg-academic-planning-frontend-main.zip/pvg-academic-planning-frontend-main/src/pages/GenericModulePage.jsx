import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { MODULE_CONFIG } from '../config/modules';

const API_BASE = '/api';

// ── Name field priority list for each entity type ─────────────────────────────
// When we look up an id in a foreign table, we try these fields in order.
const NAME_FIELDS = [
  'faculty_name', 'department_name', 'program_name', 'course_name',
  'class_name', 'batch_name', 'div_name', 'section_name', 'semester_number',
  'room_number', 'lab_name', 'lab_number', 'academic_year',
  'name', 'title', 'description',
];

// ── Map every *_id suffix we might see → the API endpoint to fetch names from ─
const PLURAL_MAP = {
  department:    'departments',
  program:       'programs',
  section:       'sections',
  class:         'classes',
  div:           'divisions',
  division:      'divisions',
  batch:         'batches',
  faculty:       'faculty',
  hod:           'faculty',         // hod_id → faculty
  sub:           'courses',         // sub_id (subject) → courses
  course:        'courses',
  semester:      'semesters',
  classroom:     'classrooms',
  lab:           'labs',
  program_fees:  'fees',            // program_fees_id → fees
  timetable:     'timetables',
  student:       'student-batches', // student_id fallback
  user:          'logs',
};

// ── Pick the best human-readable text from a looked-up object ─────────────────
const pickName = (obj) => {
  if (!obj) return null;
  for (const field of NAME_FIELDS) {
    if (obj[field] != null && String(obj[field]).trim() !== '') {
      return String(obj[field]);
    }
  }
  // Last resort: return id
  return obj.id != null ? `ID: ${obj.id}` : null;
};

// ── Format column header: remove _id suffix, title-case ──────────────────────
const formatColumnName = (key) => {
  const cleaned = key.replace(/_id$/, '').replace(/_/g, ' ');
  return cleaned.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
};

/* ── Reusable Modal ─────────────────────────────────────────── */
const Modal = ({ title, onClose, children }) => (
  <div style={{ position:'fixed',inset:0,zIndex:1000,display:'flex',justifyContent:'center',alignItems:'center',backgroundColor:'rgba(0,0,0,0.5)',animation:'fadeIn .2s' }}>
    <div style={{ background:'#fff',borderRadius:'12px',width:'95%',maxWidth:'560px',maxHeight:'80vh',display:'flex',flexDirection:'column',boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}>
      <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',padding:'20px 24px',borderBottom:'1px solid #e5e7eb' }}>
        <h2 style={{ fontSize:'18px',fontWeight:'700',margin:0 }}>{title}</h2>
        <button onClick={onClose} style={{ background:'none',border:'none',fontSize:'20px',cursor:'pointer',color:'#6b7280' }}>&times;</button>
      </div>
      <div style={{ padding:'24px',overflowY:'auto',flex:1 }}>{children}</div>
    </div>
  </div>
);

/* ── Confirm Dialog ─────────────────────────────────────────── */
const ConfirmDialog = ({ message, onConfirm, onCancel }) => (
  <div style={{ position:'fixed',inset:0,zIndex:1000,display:'flex',justifyContent:'center',alignItems:'center',backgroundColor:'rgba(0,0,0,0.5)' }}>
    <div style={{ background:'#fff',borderRadius:'12px',padding:'32px',maxWidth:'420px',textAlign:'center',boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}>
      <i className="fa-solid fa-triangle-exclamation" style={{ fontSize:'40px',color:'#ef4444',marginBottom:'16px' }}></i>
      <p style={{ fontSize:'16px',marginBottom:'24px',color:'#1f2937' }}>{message}</p>
      <div style={{ display:'flex',gap:'12px',justifyContent:'center' }}>
        <button onClick={onCancel} style={{ padding:'10px 24px',borderRadius:'8px',border:'1px solid #d1d5db',background:'#fff',cursor:'pointer',fontWeight:'500' }}>Cancel</button>
        <button onClick={onConfirm} style={{ padding:'10px 24px',borderRadius:'8px',border:'none',background:'#ef4444',color:'#fff',cursor:'pointer',fontWeight:'500' }}>Delete</button>
      </div>
    </div>
  </div>
);

/* ── Toast Notification ─────────────────────────────────────── */
const Toast = ({ message, type }) => {
  const bg = type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6';
  return (
    <div style={{ position:'fixed',bottom:'24px',right:'24px',zIndex:2000,padding:'14px 24px',borderRadius:'10px',color:'#fff',background:bg,fontWeight:'500',boxShadow:'0 8px 24px rgba(0,0,0,0.2)',animation:'fadeIn .3s' }}>
      {message}
    </div>
  );
};

/* ── Main Component ─────────────────────────────────────────── */
const GenericModulePage = ({ userRole }) => {
  const { moduleKey } = useParams();
  const config = MODULE_CONFIG[moduleKey];

  const [data, setData]                         = useState([]);
  const [loading, setLoading]                   = useState(true);
  const [searchTerm, setSearchTerm]             = useState('');
  const [error, setError]                       = useState(null);
  const [schemaFields, setSchemaFields]         = useState([]);
  const [foreignKeyOptions, setForeignKeyOptions] = useState({});

  // ── Fetch all foreign-key lookup tables ──────────────────────
  useEffect(() => {
    const fetchOptions = async () => {
      const options = {};

      // Collect every _id field from both schema fields AND actual data columns
      const allIdFields = new Set([
        ...schemaFields.filter(f => f.endsWith('_id')),
        ...(data.length > 0
          ? Object.keys(data[0]).filter(f => f.endsWith('_id'))
          : []),
      ]);

      for (const field of allIdFields) {
        const base = field.replace(/_id$/, '');
        const endpoint = PLURAL_MAP[base];
        if (endpoint && !options[field]) {
          try {
            const res = await fetch(`${API_BASE}/${endpoint}/`);
            if (res.ok) {
              options[field] = await res.json();
            }
          } catch (e) {
            console.error(`Failed to fetch options for ${field}`);
          }
        }
      }
      setForeignKeyOptions(options);
    };

    if (schemaFields.length > 0 || data.length > 0) {
      fetchOptions();
    }
  }, [schemaFields, data]);

  // Modal states
  const [showAddModal, setShowAddModal]     = useState(false);
  const [showEditModal, setShowEditModal]   = useState(false);
  const [editingRow, setEditingRow]         = useState(null);
  const [formData, setFormData]             = useState({});
  const [formSubmitting, setFormSubmitting] = useState(false);

  // Delete states
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Filter state
  const [showFilters, setShowFilters]   = useState(false);
  const [filterColumn, setFilterColumn] = useState('');
  const [filterValue, setFilterValue]   = useState('');

  // Toast
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  /* ── Fetch Data ────────────────────────────────────────────── */
  const fetchData = useCallback(() => {
    if (!config) return;
    setLoading(true);
    setError(null);
    fetch(`${API_BASE}/${config.endpoint}/`)
      .then(res => { if (!res.ok) throw new Error('Failed'); return res.json(); })
      .then(d => { setData(Array.isArray(d) ? d : []); setLoading(false); })
      .catch(() => { setError("Could not load data. Ensure the backend server is running."); setLoading(false); });

    // Fetch OpenAPI schema to get fields for empty state / forms
    fetch(`${API_BASE}/openapi.json`)
      .then(res => res.json())
      .then(schema => {
        try {
          const postPath = schema.paths[`/${config.endpoint}/`]?.post || schema.paths[`/${config.endpoint}`]?.post;
          if (postPath) {
            const ref = postPath.requestBody.content['application/json'].schema.$ref;
            const schemaName = ref.split('/').pop();
            const properties = schema.components.schemas[schemaName].properties;
            setSchemaFields(Object.keys(properties).filter(k => k !== 'id'));
          }
        } catch (e) {
          console.error("Could not parse openapi schema for fields", e);
        }
      })
      .catch(console.error);
  }, [config]);

  useEffect(() => {
    fetchData();
    setSearchTerm('');
    setFilterColumn('');
    setFilterValue('');
  }, [moduleKey, fetchData]);

  if (!config) return <Navigate to="/dashboard" replace />;

  // ── Resolve a cell value: if it's an _id column, return the name ─────────
  const resolveCell = (col, value) => {
    if (!col.endsWith('_id')) return null; // not an id column → use default
    const options = foreignKeyOptions[col];
    if (!options || value == null || value === '' || value === '-') return null;
    const numVal = Number(value);
    const match = options.find(o => o.id === numVal);
    return match ? (pickName(match) ?? String(value)) : String(value);
  };

  // ── Build display columns ───────────────────────────────────────────────
  const allColumns = data.length > 0 ? Object.keys(data[0]) : schemaFields;

  // Columns we actually show: hide any _id col when we can resolve it to a name
  const displayColumns = allColumns.filter(col => {
    if (!col.endsWith('_id')) return true;
    // If we already have lookup data for it, show it (we'll display the name)
    // Always include if we have options or if no options yet loaded
    const base = col.replace(/_id$/, '');
    const endpoint = PLURAL_MAP[base];
    // Show the col; we'll render name in cell. Hide only raw numeric id columns
    // where the API also returns a _name sibling (e.g. course returns program_name alongside program_id)
    const nameCol = col.replace(/_id$/, '_name');
    if (allColumns.includes(nameCol)) return false; // backend already gives us the name col, hide id
    return true;
  });

  const editableColumns = schemaFields.filter(c =>
    c !== 'id' &&
    c !== 'created_at' &&
    c !== 'updated_at' &&
    c !== 'sanction_intake' &&
    c !== 'sanction_div' &&
    c !== 'section_id'
  );

  /* ── Filtering & Search ────────────────────────────────────── */
  // Build a searchable string for each row (includes resolved names)
  const getSearchableString = (item) => {
    return allColumns.map(col => {
      const raw = item[col];
      if (col.endsWith('_id')) {
        const resolved = resolveCell(col, raw);
        return resolved ?? String(raw ?? '');
      }
      return String(raw ?? '');
    }).join(' ').toLowerCase();
  };

  const filteredData = data.filter(item => {
    const searchable = getSearchableString(item);
    const matchesSearch = !searchTerm || searchable.includes(searchTerm.toLowerCase());

    let matchesFilter = true;
    if (filterColumn && filterValue) {
      const rawVal = item[filterColumn];
      if (filterColumn.endsWith('_id')) {
        const resolved = resolveCell(filterColumn, rawVal) ?? String(rawVal ?? '');
        matchesFilter = resolved.toLowerCase().includes(filterValue.toLowerCase());
      } else {
        matchesFilter = String(rawVal ?? '').toLowerCase().includes(filterValue.toLowerCase());
      }
    }
    return matchesSearch && matchesFilter;
  });

  /* ── Add New ───────────────────────────────────────────────── */
  const handleAddNew = () => {
    const emptyForm = {};
    editableColumns.forEach(c => emptyForm[c] = '');
    setFormData(emptyForm);
    setShowAddModal(true);
  };

  const handleCreate = () => {
    setFormSubmitting(true);
    fetch(`${API_BASE}/${config.endpoint}/`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    })
      .then(res => {
        if (!res.ok) {
          return res.json().then(e => {
            let errorMsg = 'Create failed';
            if (e.detail) {
              if (Array.isArray(e.detail)) {
                errorMsg = e.detail.map(err => `${err.loc[err.loc.length-1]}: ${err.msg}`).join(', ');
              } else {
                errorMsg = typeof e.detail === 'string' ? e.detail : JSON.stringify(e.detail);
              }
            }
            throw new Error(errorMsg);
          });
        }
        return res.json();
      })
      .then(() => { showToast(`${config.title} record created!`); setShowAddModal(false); fetchData(); })
      .catch(err => showToast(err.message, 'error'))
      .finally(() => setFormSubmitting(false));
  };

  /* ── Edit ───────────────────────────────────────────────────── */
  const handleEdit = (row) => {
    setEditingRow(row);
    const f = {};
    editableColumns.forEach(c => f[c] = row[c] ?? '');
    setFormData(f);
    setShowEditModal(true);
  };

  const handleUpdate = () => {
    setFormSubmitting(true);
    fetch(`${API_BASE}/${config.endpoint}/${editingRow.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    })
      .then(res => {
        if (!res.ok) {
          return res.json().then(e => {
            let errorMsg = 'Update failed';
            if (e.detail) {
              if (Array.isArray(e.detail)) {
                errorMsg = e.detail.map(err => `${err.loc[err.loc.length-1]}: ${err.msg}`).join(', ');
              } else {
                errorMsg = typeof e.detail === 'string' ? e.detail : JSON.stringify(e.detail);
              }
            }
            throw new Error(errorMsg);
          });
        }
        return res.json();
      })
      .then(() => { showToast(`Record updated!`); setShowEditModal(false); fetchData(); })
      .catch(err => showToast(err.message, 'error'))
      .finally(() => setFormSubmitting(false));
  };

  /* ── Delete ─────────────────────────────────────────────────── */
  const handleDelete = () => {
    fetch(`${API_BASE}/${config.endpoint}/${deleteTarget.id}`, { method: 'DELETE' })
      .then(res => { if (!res.ok) throw new Error('Delete failed'); showToast('Record deleted!'); setDeleteTarget(null); fetchData(); })
      .catch(err => showToast(err.message, 'error'));
  };

  /* ── Form Field Renderer ───────────────────────────────────── */
  const renderFormFields = () => (
    <div style={{ display:'flex',flexDirection:'column',gap:'16px' }}>
      {Object.keys(formData).map(key => {
        if (key.endsWith('_id') && foreignKeyOptions[key]) {
          const base = key.replace(/_id$/, '');
          return (
            <div key={key}>
              <label style={{ display:'block',fontSize:'13px',fontWeight:'600',marginBottom:'6px',color:'#374151',textTransform:'uppercase',letterSpacing:'0.5px' }}>
                {formatColumnName(key)}
              </label>
              <select
                value={formData[key] ?? ''}
                onChange={e => setFormData(prev => ({ ...prev, [key]: e.target.value ? Number(e.target.value) : '' }))}
                style={{ width:'100%',padding:'10px 14px',borderRadius:'8px',border:'1px solid #d1d5db',fontSize:'14px',outline:'none',boxSizing:'border-box',backgroundColor:'#fff' }}
              >
                <option value="">-- Select {formatColumnName(key)} --</option>
                {foreignKeyOptions[key].map(opt => (
                  <option key={opt.id} value={opt.id}>
                    {pickName(opt) ?? `ID: ${opt.id}`}
                  </option>
                ))}
              </select>
            </div>
          );
        }
        return (
          <div key={key}>
            <label style={{ display:'block',fontSize:'13px',fontWeight:'600',marginBottom:'6px',color:'#374151',textTransform:'uppercase',letterSpacing:'0.5px' }}>
              {formatColumnName(key)}
            </label>
            <input
              type={typeof formData[key] === 'number' ? 'number' : 'text'}
              value={formData[key] ?? ''}
              onChange={e => setFormData(prev => ({ ...prev, [key]: e.target.value }))}
              style={{ width:'100%',padding:'10px 14px',borderRadius:'8px',border:'1px solid #d1d5db',fontSize:'14px',outline:'none',boxSizing:'border-box' }}
            />
          </div>
        );
      })}
      <button
        onClick={showEditModal ? handleUpdate : handleCreate}
        disabled={formSubmitting}
        style={{ marginTop:'8px',padding:'12px',borderRadius:'8px',border:'none',background:'var(--erp-primary, #003A6A)',color:'#fff',fontSize:'15px',fontWeight:'600',cursor:'pointer',opacity:formSubmitting?0.6:1 }}
      >
        {formSubmitting ? 'Saving...' : (showEditModal ? 'Update Record' : 'Create Record')}
      </button>
    </div>
  );

  /* ── Render cell value ─────────────────────────────────────── */
  const renderCellValue = (col, value) => {
    if (typeof value === 'boolean') return value ? '✅ Yes' : '❌ No';
    if (col.endsWith('_id') && value != null) {
      const resolved = resolveCell(col, value);
      if (resolved) {
        return (
          <span style={{ display:'inline-flex',alignItems:'center',gap:'6px' }}>
            <span style={{
              display:'inline-block', padding:'2px 10px', borderRadius:'12px',
              fontSize:'12px', fontWeight:'600',
              background:'rgba(0,58,106,0.08)', color:'var(--erp-primary, #003A6A)',
              whiteSpace:'nowrap'
            }}>
              {resolved}
            </span>
          </span>
        );
      }
      return String(value ?? '-');
    }
    if (typeof value === 'object' && value !== null) return JSON.stringify(value);
    return String(value ?? '-');
  };

  /* ── Render ─────────────────────────────────────────────────── */
  return (
    <div>
      {/* Header */}
      <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'30px' }}>
        <div>
          <h1 style={{ fontSize:'28px',fontWeight:'700',marginBottom:'8px',color:'var(--erp-text)' }}>
            <i className={`fa-solid ${config.icon}`} style={{ marginRight:'12px',color:'var(--erp-primary)' }}></i>
            {config.title}
          </h1>
          <p style={{ color:'var(--erp-text-muted)' }}>{config.description}</p>
        </div>
        {userRole !== 'student' && (
          <button className="erp-btn erp-btn--primary" onClick={handleAddNew}>
            <i className="fa-solid fa-plus" style={{ marginRight:'8px' }}></i> Add New
          </button>
        )}
      </div>

      {/* Search + Filter Bar */}
      <div className="erp-card" style={{ marginBottom:'24px' }}>
        <div className="erp-card__body" style={{ display:'flex',gap:'16px',alignItems:'center',flexWrap:'wrap' }}>
          <div style={{ position:'relative',flex:1,minWidth:'200px' }}>
            <i className="fa-solid fa-search" style={{ color:'var(--erp-text-muted)',position:'absolute',left:'16px',top:'50%',transform:'translateY(-50%)' }}></i>
            <input type="text" placeholder={`Search ${config.title.toLowerCase()}...`} className="erp-form-control" style={{ width:'100%',paddingLeft:'44px' }} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
          <button className="erp-btn erp-btn--outline" onClick={() => setShowFilters(!showFilters)}>
            <i className="fa-solid fa-filter" style={{ marginRight:'8px' }}></i> Filters
          </button>
          {(searchTerm || filterValue) && (
            <button className="erp-btn erp-btn--ghost" onClick={() => { setSearchTerm(''); setFilterColumn(''); setFilterValue(''); }}>
              <i className="fa-solid fa-xmark" style={{ marginRight:'6px' }}></i> Clear
            </button>
          )}
        </div>
        {showFilters && displayColumns.length > 0 && (
          <div style={{ padding:'0 20px 20px',display:'flex',gap:'12px',alignItems:'center',flexWrap:'wrap' }}>
            <select value={filterColumn} onChange={e => setFilterColumn(e.target.value)} style={{ padding:'8px 12px',borderRadius:'8px',border:'1px solid #d1d5db',fontSize:'14px' }}>
              <option value="">Select Column</option>
              {displayColumns.map(c => <option key={c} value={c}>{formatColumnName(c)}</option>)}
            </select>
            {filterColumn && (
              <input type="text" placeholder={`Filter by ${formatColumnName(filterColumn)}...`} value={filterValue} onChange={e => setFilterValue(e.target.value)} style={{ padding:'8px 12px',borderRadius:'8px',border:'1px solid #d1d5db',fontSize:'14px',flex:1,minWidth:'150px' }} />
            )}
          </div>
        )}
      </div>

      {/* Record Count */}
      {!loading && !error && (
        <div style={{ marginBottom:'12px',fontSize:'13px',color:'var(--erp-text-muted)' }}>
          Showing {filteredData.length} of {data.length} records
        </div>
      )}

      {/* Data Table */}
      <div className="erp-card">
        {loading ? (
          <div style={{ padding:'60px 0',display:'flex',justifyContent:'center' }}><i className="fa-solid fa-spinner fa-spin fa-2x" style={{ color:'var(--erp-primary)' }}></i></div>
        ) : error ? (
          <div style={{ padding:'40px 20px',textAlign:'center',color:'var(--erp-danger)' }}>
            <i className="fa-solid fa-triangle-exclamation fa-2x" style={{ marginBottom:'16px' }}></i>
            <p>{error}</p>
            <button className="erp-btn erp-btn--primary" onClick={fetchData} style={{ marginTop:'12px' }}>
              <i className="fa-solid fa-rotate-right" style={{ marginRight:'8px' }}></i> Retry
            </button>
          </div>
        ) : data.length === 0 ? (
          <div style={{ padding:'60px 20px',textAlign:'center',color:'var(--erp-text-muted)' }}>
            <i className="fa-solid fa-folder-open fa-3x" style={{ marginBottom:'16px',opacity:0.5 }}></i>
            <p>No records found. Click <strong>Add New</strong> to create one.</p>
          </div>
        ) : (
          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%',borderCollapse:'collapse',textAlign:'left' }}>
              <thead>
                <tr style={{ borderBottom:'2px solid var(--erp-border)',backgroundColor:'rgba(0,0,0,0.02)' }}>
                  {displayColumns.map(col => (
                    <th key={col} style={{ padding:'16px',fontWeight:'600',color:'var(--erp-text-muted)',fontSize:'13px',textTransform:'uppercase',letterSpacing:'0.5px' }}>
                      {formatColumnName(col)}
                    </th>
                  ))}
                  {userRole !== 'student' && (
                    <th style={{ padding:'16px',fontWeight:'600',color:'var(--erp-text-muted)',fontSize:'13px',textTransform:'uppercase',letterSpacing:'0.5px',textAlign:'right' }}>Actions</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {filteredData.map((row, idx) => (
                  <tr key={row.id || idx} style={{ borderBottom:'1px solid var(--erp-border)' }} onMouseOver={e => e.currentTarget.style.backgroundColor='rgba(0,58,106,0.04)'} onMouseOut={e => e.currentTarget.style.backgroundColor='transparent'}>
                    {displayColumns.map(col => (
                      <td key={col} style={{ padding:'16px',color:'var(--erp-text)',fontSize:'14px' }}>
                        {renderCellValue(col, row[col])}
                      </td>
                    ))}
                    {userRole !== 'student' && (
                      <td style={{ padding:'16px',textAlign:'right',whiteSpace:'nowrap' }}>
                        <button title="Edit" onClick={() => handleEdit(row)} style={{ background:'none',border:'none',cursor:'pointer',padding:'8px',borderRadius:'6px',marginRight:'4px' }}>
                          <i className="fa-solid fa-pen" style={{ color:'var(--erp-primary)' }}></i>
                        </button>
                        <button title="Delete" onClick={() => setDeleteTarget(row)} style={{ background:'none',border:'none',cursor:'pointer',padding:'8px',borderRadius:'6px' }}>
                          <i className="fa-solid fa-trash" style={{ color:'#ef4444' }}></i>
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredData.length === 0 && <div style={{ padding:'30px',textAlign:'center',color:'var(--erp-text-muted)' }}>No records match your search.</div>}
          </div>
        )}
      </div>

      {/* ── Modals ─────────────────────────────────────────────── */}
      {showAddModal && (
        <Modal title={`Add New ${config.title}`} onClose={() => setShowAddModal(false)}>
          {editableColumns.length > 0 ? renderFormFields() : <p>Load data first to see available fields.</p>}
        </Modal>
      )}

      {showEditModal && editingRow && (
        <Modal title={`Edit ${config.title}`} onClose={() => setShowEditModal(false)}>
          {renderFormFields()}
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          message={`Are you sure you want to delete this record? This action cannot be undone.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  );
};

export default GenericModulePage;
