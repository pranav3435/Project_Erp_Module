import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = () => {
    const [role, setRole] = useState('Student');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLogin = (e) => {
        e.preventDefault();
        
        if (role !== 'Admin') {
            alert('Access Denied: Only Administrators are allowed to access this portal.');
            return;
        }

        // Save admin role to localStorage
        localStorage.setItem('userRole', 'Admin');
        console.log(`Logging in as ${role} with username: ${username}`);
        navigate('/dashboard');
    };

    return (
        <div className="login-page-body">
            <div className="login-container">
                <div className="login-header">
                    <h2>Dashboard Portal</h2>
                </div>
                
                <div className="role-tabs">
                    {['Student', 'Faculty', 'Admin'].map((r) => (
                        <button 
                            key={r}
                            className={`tab-btn ${role === r ? 'active' : ''}`} 
                            onClick={() => {
                                setRole(r);
                                setUsername('');
                                setPassword('');
                            }}
                            type="button"
                        >
                            {r}
                        </button>
                    ))}
                </div>

                <div className="form-container">
                    <h3 className="dynamic-title" id="formTitle">{role} Login</h3>
                    
                    <form id="loginForm" onSubmit={handleLogin}>
                        <div className="input-group">
                            <label htmlFor="username">Username / ID</label>
                            <input 
                                type="text" 
                                id="username" 
                                name="username" 
                                placeholder="Enter your ID" 
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required 
                            />
                        </div>
                        
                        <div className="input-group">
                            <label htmlFor="password">Password</label>
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                placeholder="Enter your password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required 
                            />
                        </div>
                        
                        <button type="submit" className="submit-btn">Login as {role}</button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Login;
