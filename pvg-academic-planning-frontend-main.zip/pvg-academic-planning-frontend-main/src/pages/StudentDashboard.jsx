import React from 'react';

const StudentDashboard = () => {
  return (
    <div>
      <div style={{ marginBottom: '30px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px', color: 'var(--erp-text)' }}>Student Dashboard</h1>
        <p style={{ color: 'var(--erp-text-muted)' }}>Welcome back! Here's your academic overview.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px', marginBottom: '32px' }}>
        <div className="erp-stat-card erp-stat-card--primary">
          <div className="erp-stat-card__header">
            <div className="erp-stat-card__icon"><i className="fa-solid fa-graduation-cap"></i></div>
          </div>
          <div className="erp-stat-card__value">120</div>
          <div className="erp-stat-card__label">Total Credits</div>
        </div>
        <div className="erp-stat-card erp-stat-card--success">
          <div className="erp-stat-card__header">
            <div className="erp-stat-card__icon"><i className="fa-solid fa-check-circle"></i></div>
          </div>
          <div className="erp-stat-card__value">85%</div>
          <div className="erp-stat-card__label">Attendance</div>
        </div>
        <div className="erp-stat-card erp-stat-card--danger">
          <div className="erp-stat-card__header">
            <div className="erp-stat-card__icon"><i className="fa-solid fa-file-invoice-dollar"></i></div>
          </div>
          <div className="erp-stat-card__value">₹25,000</div>
          <div className="erp-stat-card__label">Pending Fees</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
        <div className="erp-card">
          <div className="erp-card__header">
            <div>
              <div className="erp-card__title">My Classes Today</div>
              <div className="erp-card__subtitle">Your schedule for today</div>
            </div>
            <button className="erp-btn erp-btn--outline erp-btn--sm">Full Timetable</button>
          </div>
          <div className="erp-card__body">
            <p style={{ color: 'var(--erp-text-muted)' }}>No more classes today. Enjoy your day!</p>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div className="erp-card">
            <div className="erp-card__header">
              <div>
                <div className="erp-card__title"><i className="fa-solid fa-bullhorn" style={{ color: 'var(--erp-primary)', marginRight: '8px' }}></i> Notices</div>
              </div>
            </div>
            <div className="erp-card__body">
              <div className="erp-alert erp-alert--info">
                <span style={{ fontWeight: '500' }}>Library will be closed tomorrow.</span>
              </div>
            </div>
          </div>

          <div className="erp-card">
            <div className="erp-card__header">
              <div>
                <div className="erp-card__title"><i className="fa-solid fa-wallet" style={{ color: 'var(--erp-danger)', marginRight: '8px' }}></i> Fees Overview</div>
              </div>
            </div>
            <div className="erp-card__body">
               <p style={{ fontSize: '14px', marginBottom: '8px' }}><strong>Next Installment:</strong> Oct 15, 2026</p>
               <p style={{ fontSize: '14px', marginBottom: '16px' }}><strong>Amount:</strong> ₹25,000</p>
               <button className="erp-btn erp-btn--primary erp-btn--sm" style={{ width: '100%' }}>Pay Now</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
