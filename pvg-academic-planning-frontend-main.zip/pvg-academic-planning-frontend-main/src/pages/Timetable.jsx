import React, { useEffect, useState, useCallback } from 'react';
import './Timetable.css';

const BASE = '/api/timetable';

const DAYS = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday'
];

// 09:00 – 17:00 in 30-min increments
const generateTimeSlots = () => {

  const slots = [];

  for (let hour = 9; hour < 17; hour++) {

    for (let minute = 0; minute < 60; minute += 30) {

      const sh = String(hour).padStart(2, '0');
      const sm = String(minute).padStart(2, '0');

      let eh = hour;
      let em = minute + 30;

      if (em === 60) {
        em = 0;
        eh += 1;
      }

      const feh = String(eh).padStart(2, '0');
      const fem = String(em).padStart(2, '0');

      const dh = hour > 12 ? hour - 12 : hour;
      const ampm = hour >= 12 ? 'PM' : 'AM';

      slots.push({
        label: `${dh}:${sm} ${ampm}`,
        value: `${sh}:${sm}`,
        end: `${feh}:${fem}`,
      });
    }
  }

  return slots;
};

const TIME_SLOTS = generateTimeSlots();

const EMPTY_FORM = {
  department_id: '',
  program_id: '',
  class_id: '',
  division_id: '',
  batch_id: '',
  sub_id: '',
  faculty_id: '',
  classroom_id: '',
  lab_id: '',
  semester_id: '',
  academic_year: '2025-2026',
  day: 'Monday',
  start_time: '09:00',
  end_time: '09:30',
  session_type: 'lecture',
  is_break: false,
};

// ───────────────── helpers ─────────────────
const api = async (path) => {

  const res = await fetch(BASE + path);

  if (!res.ok) {
    throw new Error(await res.text());
  }

  return res.json();
};

const qs = (params) => {

  const q = Object.entries(params)
    .filter(([, v]) => v !== '' && v != null)
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
    .join('&');

  return q ? `?${q}` : '';
};

const formatTime = (t) => {

  if (!t) return '';

  const [h, m] = t.split(':');

  const nh = Number(h);

  const dh =
    nh > 12
      ? nh - 12
      : nh === 0
        ? 12
        : nh;

  return `${dh}:${m} ${nh >= 12 ? 'PM' : 'AM'}`;
};

const cardClass = (color) => {

  const map = {
    success: 'card-success',
    warning: 'card-warning',
    danger: 'card-danger',
  };

  return map[color] || 'card-primary';
};

// ───────────────── component ─────────────────
export default function Timetable({ userRole }) {

  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);

  // classroom filter
  const [selectedClassroom, setSelectedClassroom] = useState('');

  // dropdowns
  const [departments, setDepartments] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [classes, setClasses] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [batches, setBatches] = useState([]);
  const [courses, setCourses] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [classrooms, setClassrooms] = useState([]);
  const [labs, setLabs] = useState([]);
  const [semesters, setSemesters] = useState([]);

  const [form, setForm] = useState(EMPTY_FORM);

  // ───────────────── load timetable ─────────────────
  const loadTimetable = useCallback(async () => {

    if (!selectedClassroom) {
      setEntries([]);
      return;
    }

    setLoading(true);

    try {

      const data = await api(
        '/weekly' + qs({ classroom_id: selectedClassroom })
      );

      setEntries(data);

    } catch (e) {

      console.error(e);

    } finally {

      setLoading(false);
    }

  }, [selectedClassroom]);

  useEffect(() => {
    loadTimetable();
  }, [loadTimetable]);

  // ───────────────── static dropdowns ─────────────────
  useEffect(() => {

    Promise.all([
      api('/dropdown/departments'),
      api('/dropdown/classrooms'),
      api('/dropdown/faculty'),
      api('/dropdown/labs'),
      api('/dropdown/semesters'),
    ])
      .then(([deps, cls, fac, lbs, sem]) => {

        setDepartments(deps);
        setClassrooms(cls);
        setFaculty(fac);
        setLabs(lbs);
        setSemesters(sem);

      })
      .catch(console.error);

  }, []);

  // ───────────────── cascade: department ─────────────────
  useEffect(() => {

    setPrograms([]);
    setClasses([]);
    setDivisions([]);
    setBatches([]);
    setCourses([]);

    setForm(f => ({
      ...f,
      program_id: '',
      class_id: '',
      division_id: '',
      batch_id: '',
      sub_id: '',
      faculty_id: '',
    }));

    if (!form.department_id) return;

    Promise.all([
      api('/dropdown/programs' + qs({
        department_id: form.department_id
      })),

      api('/dropdown/faculty' + qs({
        department_id: form.department_id
      })),

      api('/dropdown/labs' + qs({
        department_id: form.department_id
      })),
    ])
      .then(([progs, fac, lbs]) => {

        setPrograms(progs);
        setFaculty(fac);
        setLabs(lbs);

      })
      .catch(console.error);

  }, [form.department_id]);

  // ───────────────── cascade: program ─────────────────
  useEffect(() => {

    setClasses([]);
    setDivisions([]);
    setBatches([]);
    setCourses([]);

    setForm(f => ({
      ...f,
      class_id: '',
      division_id: '',
      batch_id: '',
      sub_id: '',
    }));

    if (!form.program_id) return;

    Promise.all([
      api('/dropdown/classes' + qs({
        program_id: form.program_id,
        department_id: form.department_id,
      })),

      api('/dropdown/courses' + qs({
        program_id: form.program_id,
        department_id: form.department_id,
      })),

      api('/dropdown/semesters' + qs({
        program_id: form.program_id,
      })),
    ])
      .then(([cls, crs, sem]) => {

        setClasses(cls);
        setCourses(crs);
        setSemesters(sem);

      })
      .catch(console.error);

  }, [form.program_id]);

  // ───────────────── cascade: class ─────────────────
  useEffect(() => {

    setDivisions([]);
    setBatches([]);

    setForm(f => ({
      ...f,
      division_id: '',
      batch_id: '',
    }));

    if (!form.class_id) return;

    api('/dropdown/divisions' + qs({
      class_id: form.class_id,
    }))
      .then(setDivisions)
      .catch(console.error);

  }, [form.class_id]);

  // ───────────────── cascade: division ─────────────────
  useEffect(() => {

    setBatches([]);

    setForm(f => ({
      ...f,
      batch_id: '',
    }));

    if (!form.division_id) return;

    api('/dropdown/batches' + qs({
      div_id: form.division_id,
      class_id: form.class_id,
    }))
      .then(setBatches)
      .catch(console.error);

  }, [form.division_id]);

  // ───────────────── form helpers ─────────────────
  const set = (key, val) => {

    setForm(f => ({
      ...f,
      [key]: val,
    }));
  };

  const availableEndTimes =
    TIME_SLOTS.filter(s => s.value > form.start_time);

  const openModal = (day, slot) => {

    setForm(f => ({
      ...f,
      day,
      start_time: slot.value,
      end_time: slot.end,
      classroom_id: selectedClassroom,
    }));

    setShowModal(true);
  };

  const closeModal = () => {

    setForm(EMPTY_FORM);
    setShowModal(false);
  };

  // ───────────────── save ─────────────────
  const save = async () => {

    setSaving(true);

    try {

      const payload = {
        day: form.day,
        start_time: form.start_time,
        end_time: form.end_time,
        academic_year: form.academic_year,
        session_type: form.session_type,
        is_break: form.is_break,

        sub_id: form.sub_id
          ? Number(form.sub_id)
          : null,

        faculty_id: form.faculty_id
          ? Number(form.faculty_id)
          : null,

        classroom_id: selectedClassroom
          ? Number(selectedClassroom)
          : null,

        lab_id: form.lab_id
          ? Number(form.lab_id)
          : null,

        semester_id: form.semester_id
          ? Number(form.semester_id)
          : null,

        division_id: form.division_id
          ? Number(form.division_id)
          : null,

        batch_id: form.batch_id
          ? Number(form.batch_id)
          : null,
      };

      const res = await fetch(`${BASE}/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {

        const err = await res.json();

        alert(err.detail || 'Failed to save');

        return;
      }

      closeModal();

      loadTimetable();

    } catch (e) {

      alert('Network error: ' + e.message);

    } finally {

      setSaving(false);
    }
  };

  // ───────────────── lookup ─────────────────
  const getEntry = (dayIdx, slot) =>
    entries.find(
      e =>
        e.j === dayIdx &&
        e.start_time.slice(0, 5) === slot.value
    );

  // ───────────────── loading ─────────────────
  if (loading) {
    return (
      <div className="tt-loading">
        <span className="tt-spinner" />
        Loading timetable…
      </div>
    );
  }

  // ───────────────── render ─────────────────
  return (
    <div className="tt-page">

      {/* HEADER */}
      <header className="tt-header">

        <div>
          <h1 className="tt-title">
            Weekly Timetable
          </h1>

          <p className="tt-sub">
            Manage and schedule all academic sessions
          </p>
        </div>

        {userRole !== 'student' && (
          <button
            className="btn-primary"
            onClick={() => setShowModal(true)}
            disabled={!selectedClassroom}
          >
            + Schedule Class
          </button>
        )}

      </header>

      {/* CLASSROOM FILTER */}
      <div className="tt-filter-bar">

        <div className="filter-item">

          <label className="fld-label">
            Select Classroom
          </label>

          <select
            className="fld"
            value={selectedClassroom}
            onChange={(e) =>
              setSelectedClassroom(e.target.value)
            }
          >
            <option value="">
              — Select Classroom —
            </option>

            {classrooms.map(c => (
              <option
                key={c.id}
                value={c.id}
              >
                {c.name}
              </option>
            ))}
          </select>

        </div>

      </div>

      {/* EMPTY STATE */}
      {!selectedClassroom ? (

        <div className="empty-state">
          Please select a classroom to view timetable
        </div>

      ) : (

        <div className="tt-scroll">

          <table className="tt-table">

            <thead>
              <tr>

                <th className="col-time">
                  Time
                </th>

                {DAYS.map(d => (
                  <th key={d}>
                    {d}
                  </th>
                ))}

              </tr>
            </thead>

            <tbody>

              {TIME_SLOTS.map(slot => (

                <tr key={slot.value}>

                  <td className="cell-time">
                    {slot.label}
                  </td>

                  {DAYS.map((day, di) => {

                    const entry =
                      getEntry(di, slot);

                    return (
                      <td
                        key={day + slot.value}
                        className="cell-grid"
                      >

                        {entry ? (

                          <div className={`class-card ${cardClass(entry.color)}`}>

                            <div className="cc-title">
                              {entry.title}
                            </div>

                            <div className="cc-row">
                              👨‍🏫 {entry.meta || '—'}
                            </div>

                            {entry.division && (
                              <div className="cc-row">
                                🏫 Div: {entry.division}
                              </div>
                            )}

                            {entry.batch && (
                              <div className="cc-row">
                                👥 Batch: {entry.batch}
                              </div>
                            )}

                            {entry.semester && (
                              <div className="cc-row">
                                📘 Sem: {entry.semester}
                              </div>
                            )}

                            <div className="cc-time">
                              ⏰ {formatTime(entry.start_time)} – {formatTime(entry.end_time)}
                            </div>

                          </div>

                        ) : (

                          <div className="empty-cell">
                            {userRole !== 'student' && (
                              <button
                                className="btn-plus"
                                onClick={() => openModal(day, slot)}
                              >
                                +
                              </button>
                            )}
                          </div>

                        )}

                      </td>
                    );
                  })}

                </tr>

              ))}

            </tbody>

          </table>

        </div>

      )}

      {/* MODAL */}
      {showModal && (

        <div
          className="overlay"
          onClick={(e) =>
            e.target === e.currentTarget && closeModal()
          }
        >

          <div className="modal">

            {/* HEADER */}
            <div className="modal-head">

              <div>

                <h2>
                  Schedule a Class
                </h2>

                <p>
                  Fill in details below
                </p>

              </div>

              <button
                className="btn-close"
                onClick={closeModal}
              >
                ✕
              </button>

            </div>

            {/* BODY */}
            <div className="modal-body">

              <div className="form-grid">

                {/* Department */}
                <Field label="Department" required>

                  <select
                    className="fld"
                    value={form.department_id}
                    onChange={(e) =>
                      set('department_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Department —
                    </option>

                    {departments.map(d => (
                      <option
                        key={d.id}
                        value={d.id}
                      >
                        {d.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Program */}
                <Field label="Program" required>

                  <select
                    className="fld"
                    value={form.program_id}
                    disabled={!form.department_id}
                    onChange={(e) =>
                      set('program_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Program —
                    </option>

                    {programs.map(p => (
                      <option
                        key={p.id}
                        value={p.id}
                      >
                        {p.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Class */}
                <Field label="Class">

                  <select
                    className="fld"
                    value={form.class_id}
                    disabled={!form.program_id}
                    onChange={(e) =>
                      set('class_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Class —
                    </option>

                    {classes.map(c => (
                      <option
                        key={c.id}
                        value={c.id}
                      >
                        {c.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Division */}
                <Field label="Division">

                  <select
                    className="fld"
                    value={form.division_id}
                    disabled={!form.class_id}
                    onChange={(e) =>
                      set('division_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Division —
                    </option>

                    {divisions.map(d => (
                      <option
                        key={d.id}
                        value={d.id}
                      >
                        {d.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Batch */}
                <Field label="Batch">

                  <select
                    className="fld"
                    value={form.batch_id}
                    disabled={!form.division_id}
                    onChange={(e) =>
                      set('batch_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Batch —
                    </option>

                    {batches.map(b => (
                      <option
                        key={b.id}
                        value={b.id}
                      >
                        {b.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Semester */}
                <Field label="Semester">

                  <select
                    className="fld"
                    value={form.semester_id}
                    onChange={(e) =>
                      set('semester_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Semester —
                    </option>

                    {semesters.map(s => (
                      <option
                        key={s.id}
                        value={s.id}
                      >
                        {s.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Course */}
                <Field label="Course" required>

                  <select
                    className="fld"
                    value={form.sub_id}
                    disabled={!form.program_id}
                    onChange={(e) =>
                      set('sub_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Course —
                    </option>

                    {courses.map(c => (
                      <option
                        key={c.id}
                        value={c.id}
                      >
                        {c.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Faculty */}
                <Field label="Faculty">

                  <select
                    className="fld"
                    value={form.faculty_id}
                    onChange={(e) =>
                      set('faculty_id', e.target.value)
                    }
                  >

                    <option value="">
                      — Select Faculty —
                    </option>

                    {faculty.map(f => (
                      <option
                        key={f.id}
                        value={f.id}
                      >
                        {f.name}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Session Type */}
                <Field label="Session Type">

                  <select
                    className="fld"
                    value={form.session_type}
                    onChange={(e) =>
                      set('session_type', e.target.value)
                    }
                  >

                    <option value="Theory">
                      Theory
                    </option>

                    <option value="practical">
                      Practical
                    </option>

                    <option value="Project">
                      Project
                    </option>

                  </select>

                </Field>

                {/* Day */}
                <Field label="Day">

                  <select
                    className="fld"
                    value={form.day}
                    onChange={(e) =>
                      set('day', e.target.value)
                    }
                  >

                    {DAYS.map(d => (
                      <option
                        key={d}
                        value={d}
                      >
                        {d}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* Start Time */}
                <Field label="Start Time">

                  <select
                    className="fld"
                    value={form.start_time}
                    onChange={(e) =>
                      set('start_time', e.target.value)
                    }
                  >

                    {TIME_SLOTS.map(s => (
                      <option
                        key={s.value}
                        value={s.value}
                      >
                        {s.label}
                      </option>
                    ))}

                  </select>

                </Field>

                {/* End Time */}
                <Field label="End Time">

                  <select
                    className="fld"
                    value={form.end_time}
                    onChange={(e) =>
                      set('end_time', e.target.value)
                    }
                  >

                    {availableEndTimes.map(s => (
                      <option
                        key={s.end}
                        value={s.end}
                      >
                        {formatTime(s.end)}
                      </option>
                    ))}

                  </select>

                </Field>

              </div>

            </div>

            {/* FOOTER */}
            <div className="modal-foot">

              <button
                className="btn-ghost"
                onClick={closeModal}
              >
                Cancel
              </button>

              <button
                className="btn-primary"
                onClick={save}
                disabled={
                  saving ||
                  !form.department_id ||
                  !form.program_id ||
                  !form.sub_id
                }
              >
                {saving ? 'Saving...' : 'Create Entry'}
              </button>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}

// ───────────────── helper ─────────────────
function Field({
  label,
  hint,
  required,
  children
}) {

  return (
    <div className="form-field">

      <label className="fld-label">

        {label}

        {required && (
          <span className="req">*</span>
        )}

        {hint && (
          <span className="hint">
            {hint}
          </span>
        )}

      </label>

      {children}

    </div>
  );
}

