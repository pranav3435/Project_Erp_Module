// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'

// // https://vitejs.dev/config/
// export default defineConfig({
//   plugins: [react()],
// })


import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    allowedHosts: true,
    proxy: {
      // Equivalent to your team member's proxy to Backend API
      "/api/v1": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
        secure: false,
      },
      // Equivalent to proxy to Swagger UI
      "/docs": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
        secure: false,
      },
      // Required for Swagger UI
      "/openapi.json": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
        secure: false,
      },
      // Your existing Backend API (localhost) proxy
      "/api": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '/api/v1'),
        secure: false,
      },
      // Authentication module backend
      "/auth": {
        target: "https://automatic-certify-appointee.ngrok-free.dev",
        changeOrigin: true,
        secure: false,
      },
      // Admission Module backend
      "/admission": {
        target: "https://impotence-synthetic-ambition.ngrok-free.dev",
        changeOrigin: true,
        secure: false,
      },
      // Fee Module
      "/fee": {
        target: "https://exploring-ageless-thigh.ngrok-free.dev",
        changeOrigin: true,
        secure: false,
      },
      // SIS Module
      "/sis": {
        target: "https://enactment-commode-configure.ngrok-free.dev",
        changeOrigin: true,
        secure: false,
      },
      // Notification Module
      "/notification": {
        target: "https://tapering-gradation-quickness.ngrok-free.dev",
        changeOrigin: true,
        secure: false,
      },
    },
  },
});






